# config-bb-providers-ng

Joint Retail/Business/Wealth/Entitlements config providers for CX6 collection version.

A customizable module that can be used to configure Angular providers.

The module shall export an array of Angular "injection functions" - functions annotated with injection meta-data - that are run as part of the config phase of the widget(s) initialization process.
