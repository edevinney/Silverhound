#!/bin/bash

FILE=process_pid.txt
if test -f "$FILE"; then
  kill -9 `cat $FILE`
  rm $FILE
fi


nohup mvn spring-boot:run &
echo $! > $FILE

