package com.backbase.training.dto.bb;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@NoArgsConstructor
@Data
@Builder
@AllArgsConstructor
public class GetAllProductsResponse {

    private List<ProductBean> products;

    @NoArgsConstructor
    @Data
    @Builder
    @AllArgsConstructor
    public static class ProductBean {
        private String internalId;
        private String id;
        private String productKindId;
        private String productKindName;
        private String productTypeId;
        private String productTypeName;
    }
}
