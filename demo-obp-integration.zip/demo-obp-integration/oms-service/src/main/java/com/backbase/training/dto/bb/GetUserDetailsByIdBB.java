package com.backbase.training.dto.bb;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@NoArgsConstructor
@Data
@Builder
@AllArgsConstructor
public class GetUserDetailsByIdBB {

    private String externalId;
    private String legalEntityId;
    private String id;
    private String fullName;
    private List<?> phone;
}
