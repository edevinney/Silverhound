package com.backbase.training.dto.fx;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@NoArgsConstructor
@Data
@Builder
@AllArgsConstructor
public class CreateCustomerRequestBodyFX {

    private PartyPersonBean party_person;
    private CustomerBean customer;
    private List<AddressesBean> addresses;

    @NoArgsConstructor
    @Data
    @Builder
    @AllArgsConstructor
    public static class PartyPersonBean {
        private String ageBracket;
        private String birthDate;
        private String citizenCntry;
        private String contactPref;
        private String cntry;
        private String education;
        private String employmentStatus;
        private String firstName;
        private String lastName;
        private String tin;
        private PartyUSBankInfoBean partyUSBankInfo;
        private PartyPersonUSSvcMemberBean party_personUSSvcMember;
        private List<String> aliases;
        private List<GovtIdsBean> govtIds;
        private List<EmailsBean> emails;
        private List<PhonesBean> phones;

        @NoArgsConstructor
        @Data
        @Builder
        @AllArgsConstructor
        public static class PartyUSBankInfoBean {
            private boolean isWthFed;
            private boolean isWthState;
            private boolean isFiledW9;
        }

        @NoArgsConstructor
        @Data
        @Builder
        @AllArgsConstructor
        public static class PartyPersonUSSvcMemberBean {
            private int svcBranch;
            private int rank;
            private int payGrade;
            private int status;
        }

        @NoArgsConstructor
        @Data
        @Builder
        @AllArgsConstructor
        public static class GovtIdsBean {
            private String cntry;
            private String docType;
            private String verifyDtm;
        }

        @NoArgsConstructor
        @Data
        @Builder
        @AllArgsConstructor
        public static class EmailsBean {
            private int emailType;
            private String data;
        }

        @NoArgsConstructor
        @Data
        @Builder
        @AllArgsConstructor
        public static class PhonesBean {
            private String data;
            private int phoneType;
            private String verifyDtm;
        }
    }

    @NoArgsConstructor
    @Data
    @Builder
    @AllArgsConstructor
    public static class CustomerBean {
        private String customerGroup;
        private String customerId;
        private String startDate;
        private String loginId;
    }

    @NoArgsConstructor
    @Data
    @Builder
    @AllArgsConstructor
    public static class AddressesBean {
        private int addrType;
        private String label;
        private String city;
        private String cntry;
        private String postCode;
        private String region;
        private String street;
    }
}
