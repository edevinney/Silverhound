package com.backbase.training.multicore;

import java.util.List;

public interface IBankCoreApiService{
    List<IBankCoreAccountInformation> GetUserAccounts(IBankCoreUserAccount user);
}