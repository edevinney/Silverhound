package com.backbase.training.multicore;

public interface IBankCoreAccountInformation{
    String getName();
    String getId();
    Float getBalance();
    String getCurrency();
    String getAccountNumber();
    String getIBAN();
    String getBranchCode();
}
