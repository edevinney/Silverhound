package com.backbase.training.sockets;

import com.backbase.training.utils.Helper;
import com.google.gson.Gson;
import org.apache.http.util.TextUtils;

public class FxEventBase {
    public String id;
    public String event;
    public FxEventClient client;
    public Object message;

    public static FxEventBase fromJson(String json){
        try {
            FxEventBase eventOverview = Helper.Gson.fromJson(json, FxEventBase.class);
            return eventOverview;
        } catch (Exception ex) {
            return null;
        }
    }
}

