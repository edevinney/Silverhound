
package com.backbase.training.obp.models;

@lombok.Data
public class Balance {
    private String currency;
    private String amount;
}
