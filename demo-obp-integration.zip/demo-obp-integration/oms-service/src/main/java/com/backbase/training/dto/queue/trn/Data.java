package com.backbase.training.dto.queue.trn;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Data {

    @SerializedName("_Id")
    @Expose
    private String id;
    @SerializedName("_cDtm")
    @Expose
    private String cDtm;
    @SerializedName("_cLogRef")
    @Expose
    private String cLogRef;
    @SerializedName("_flags")
    @Expose
    private int flags;
    @SerializedName("_schVn")
    @Expose
    private int schVn;
    @SerializedName("_vn")
    @Expose
    private int vn;
    @SerializedName("entries")
    @Expose
    private List<TrnEntry> entries = null;
    @SerializedName("glJrnlDate")
    @Expose
    private String glJrnlDate;
    @SerializedName("mode")
    @Expose
    private int mode;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCDtm() {
        return cDtm;
    }

    public void setCDtm(String cDtm) {
        this.cDtm = cDtm;
    }

    public String getCLogRef() {
        return cLogRef;
    }

    public void setCLogRef(String cLogRef) {
        this.cLogRef = cLogRef;
    }

    public int getFlags() {
        return flags;
    }

    public void setFlags(int flags) {
        this.flags = flags;
    }

    public int getSchVn() {
        return schVn;
    }

    public void setSchVn(int schVn) {
        this.schVn = schVn;
    }

    public int getVn() {
        return vn;
    }

    public void setVn(int vn) {
        this.vn = vn;
    }

    public List<TrnEntry> getEntries() {
        return entries;
    }

    public void setEntries(List<TrnEntry> entries) {
        this.entries = entries;
    }

    public String getGlJrnlDate() {
        return glJrnlDate;
    }

    public void setGlJrnlDate(String glJrnlDate) {
        this.glJrnlDate = glJrnlDate;
    }

    public int getMode() {
        return mode;
    }

    public void setMode(int mode) {
        this.mode = mode;
    }

}