package com.backbase.training.sockets;

public interface IQueueMessageProcessor {
    void onNewJsonMessage(String json);
}
