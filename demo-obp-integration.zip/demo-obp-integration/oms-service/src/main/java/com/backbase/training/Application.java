package com.backbase.training;

import com.backbase.training.multicore.SecondCoreConnector;
import com.backbase.training.obp.OBPApiService;
import com.backbase.training.obp.OBPUserMapper;
import com.backbase.training.services.BalanceService;
import com.backbase.training.services.TransactionService;
import com.backbase.training.sockets.FinxactEventManager;
import com.backbase.training.sockets.FinxactQueueProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.ApplicationListener;
import org.springframework.context.annotation.Bean;

import java.io.IOException;
import java.net.URISyntaxException;

@SpringBootApplication
@EnableDiscoveryClient
public class Application extends SpringBootServletInitializer implements ApplicationListener<ApplicationReadyEvent> {

    private final FinxactEventManager finxactEventManager;
    private final BalanceService balanceService;
    private final TransactionService transactionService;
    private final FinxactQueueProcessor finxactQueueProcessor;

    public Application(
            FinxactEventManager finxactEventManager,
            BalanceService balanceService,
            TransactionService transactionService,
            FinxactQueueProcessor finxactQueueProcessor) {
        this.finxactEventManager = finxactEventManager;
        this.balanceService = balanceService;
        this.transactionService = transactionService;
        this.finxactQueueProcessor = finxactQueueProcessor;
    }

    public static void main(final String[] args) {
        SpringApplication.run(Application.class, args);
    }

   @Bean
   public FinxactEventManager eventListenerForSockets() throws URISyntaxException, IOException {
       finxactEventManager.startup();
       return finxactEventManager;
   }

   @Bean
   public FinxactQueueProcessor queueProcessorForEvents() {
       return finxactQueueProcessor;
   }

    @Override
    public void onApplicationEvent(ApplicationReadyEvent event) {
        // the app has finally started and all BB clients are ready and can be used
       balanceService.updateAllBalances();
       transactionService.retrieveTransaction();
       finxactQueueProcessor.startup();
    }
}