package com.backbase.training.sockets;

import com.backbase.training.utils.Configurator;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpHeaders;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.methods.RequestBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Slf4j
@Component
public class SocketAuthApiClient {
    private final Configurator config;
    @Value("${finxact.sockets.auth_endpoint}")
    private String finxactAuthEndpoint = "";
    @Value("${finxact.headers.client_id}")
    private String fxHeaderClientId = "";
    @Value("${finxact.headers.secret}")
    private String fxHeaderSecret = "";
    @Value("${finxact.headers.fnx_header}")
    private String fxHeaderFinxact = "";

    @Autowired
    public SocketAuthApiClient(Configurator config) {
        this.config = config;
    }

    public String getFinxactWebSocketAuthToken() throws IllegalStateException, IOException {

        HttpClientBuilder builder = HttpClientBuilder.create();
        if (config.useProxyForFinxact) {
            log.debug("Using proxy for SocketAuthApiClient to get token from Finxact");
            builder.setProxy(new HttpHost(config.finxactProxyHost, config.finxactProxyPortInt));
        }
        CloseableHttpClient httpClient = builder.build();
        HttpUriRequest request = RequestBuilder.get()
                .setUri(finxactAuthEndpoint)
                .setHeader(HttpHeaders.CONTENT_TYPE, "application/json")
                .setHeader("client_id", fxHeaderClientId)
                .setHeader("secret", fxHeaderSecret)
                .setHeader("Fnx-Header", fxHeaderFinxact)
                .build();

        HttpResponse response = httpClient.execute(request);
        int statusCode = response.getStatusLine().getStatusCode();
        if (statusCode == 200) {
            String responseBody = EntityUtils.toString(response.getEntity());
            log.debug("Finxact auth token is " + responseBody);
            return responseBody;
        } else {
            log.error("Request to Finxact failed with status " + statusCode);
        }

        throw new IllegalStateException("Finxact did not provide authentication token, events subscription cannot proceed");
    }
}
