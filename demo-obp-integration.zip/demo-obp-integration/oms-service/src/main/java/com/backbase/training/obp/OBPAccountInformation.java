package com.backbase.training.obp;

import com.backbase.training.multicore.IBankCoreAccountInformation;
import com.backbase.training.multicore.IBankCoreUserAccount;

public class OBPAccountInformation implements IBankCoreAccountInformation {

    private String name;
    private String id;
    private String accountNumber;
    private float balance;
    private String currency;
    private String iban;
    private String branchCode;

    @Override
    public String getName() { return name; }
    public void setName(String value) { this.name = value; }

    @Override
    public String getId() { return id; }
    public void setId(String value) { this.id = value; }

    @Override
    public String getAccountNumber() { return accountNumber; }
    public void setAccountNumber(String value) { this.accountNumber = value; }

    @Override
    public Float getBalance() { return balance; }
    public void setBalance(float value) { this.balance = value; }

    @Override
    public String getCurrency() { return currency; }
    public void setCurrency(String value) { this.currency = value; }

    @Override
    public String getIBAN() { return iban; }
    public void setIBAN(String value) { this.iban = value; }

    @Override
    public String getBranchCode() {
        return this.branchCode;
    }
    public void setBranchCode(String value) { this.branchCode = value; }
}