
package com.backbase.training.dto.queue.depupdate;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class PosnDepLimit {

    @SerializedName("_Id")
    @Expose
    private String id;
    @SerializedName("_cDtm")
    @Expose
    private String cDtm;
    @SerializedName("_cLogRef")
    @Expose
    private String cLogRef;
    @SerializedName("_flags")
    @Expose
    private int flags;
    @SerializedName("_schVn")
    @Expose
    private int schVn;
    @SerializedName("_vn")
    @Expose
    private int vn;
    @SerializedName("accumTrnLimits")
    @Expose
    private List<AccumTrnLimit> accumTrnLimits = null;
    @SerializedName("componentName")
    @Expose
    private String componentName;
    @SerializedName("perTrnLimits")
    @Expose
    private List<PerTrnLimit> perTrnLimits = null;
    @SerializedName("restrictCr")
    @Expose
    private boolean restrictCr;
    @SerializedName("restrictCrFundExp")
    @Expose
    private boolean restrictCrFundExp;
    @SerializedName("restrictDr")
    @Expose
    private boolean restrictDr;
    @SerializedName("version")
    @Expose
    private int version;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCDtm() {
        return cDtm;
    }

    public void setCDtm(String cDtm) {
        this.cDtm = cDtm;
    }

    public String getCLogRef() {
        return cLogRef;
    }

    public void setCLogRef(String cLogRef) {
        this.cLogRef = cLogRef;
    }

    public int getFlags() {
        return flags;
    }

    public void setFlags(int flags) {
        this.flags = flags;
    }

    public int getSchVn() {
        return schVn;
    }

    public void setSchVn(int schVn) {
        this.schVn = schVn;
    }

    public int getVn() {
        return vn;
    }

    public void setVn(int vn) {
        this.vn = vn;
    }

    public List<AccumTrnLimit> getAccumTrnLimits() {
        return accumTrnLimits;
    }

    public void setAccumTrnLimits(List<AccumTrnLimit> accumTrnLimits) {
        this.accumTrnLimits = accumTrnLimits;
    }

    public String getComponentName() {
        return componentName;
    }

    public void setComponentName(String componentName) {
        this.componentName = componentName;
    }

    public List<PerTrnLimit> getPerTrnLimits() {
        return perTrnLimits;
    }

    public void setPerTrnLimits(List<PerTrnLimit> perTrnLimits) {
        this.perTrnLimits = perTrnLimits;
    }

    public boolean isRestrictCr() {
        return restrictCr;
    }

    public void setRestrictCr(boolean restrictCr) {
        this.restrictCr = restrictCr;
    }

    public boolean isRestrictCrFundExp() {
        return restrictCrFundExp;
    }

    public void setRestrictCrFundExp(boolean restrictCrFundExp) {
        this.restrictCrFundExp = restrictCrFundExp;
    }

    public boolean isRestrictDr() {
        return restrictDr;
    }

    public void setRestrictDr(boolean restrictDr) {
        this.restrictDr = restrictDr;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

}