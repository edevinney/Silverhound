package com.backbase.training.dto.bb;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
@Builder
@AllArgsConstructor
public class GetServiceAgreementDetailsForLegalEntityResponseBodyBB {

    private String id;
    private String externalId = "";
    private String name;
    private String description;
    private String creatorLegalEntity;
    private boolean isMaster;
    private String status;
}
