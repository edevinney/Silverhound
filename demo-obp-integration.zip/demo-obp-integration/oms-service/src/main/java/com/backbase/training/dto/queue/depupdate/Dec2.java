
package com.backbase.training.dto.queue.depupdate;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Dec2 {

    @SerializedName("avlInt")
    @Expose
    private double avlInt;
    @SerializedName("depFee")
    @Expose
    private double depFee;
    @SerializedName("negBal")
    @Expose
    private double negBal;
    @SerializedName("penalty")
    @Expose
    private double penalty;
    @SerializedName("recurInc")
    @Expose
    private double recurInc;
    @SerializedName("wthFed")
    @Expose
    private double wthFed;
    @SerializedName("wthNra")
    @Expose
    private double wthNra;
    @SerializedName("wthState")
    @Expose
    private double wthState;

    public double getAvlInt() {
        return avlInt;
    }

    public void setAvlInt(double avlInt) {
        this.avlInt = avlInt;
    }

    public double getDepFee() {
        return depFee;
    }

    public void setDepFee(double depFee) {
        this.depFee = depFee;
    }

    public double getNegBal() {
        return negBal;
    }

    public void setNegBal(double negBal) {
        this.negBal = negBal;
    }

    public double getPenalty() {
        return penalty;
    }

    public void setPenalty(double penalty) {
        this.penalty = penalty;
    }

    public double getRecurInc() {
        return recurInc;
    }

    public void setRecurInc(double recurInc) {
        this.recurInc = recurInc;
    }

    public double getWthFed() {
        return wthFed;
    }

    public void setWthFed(double wthFed) {
        this.wthFed = wthFed;
    }

    public double getWthNra() {
        return wthNra;
    }

    public void setWthNra(double wthNra) {
        this.wthNra = wthNra;
    }

    public double getWthState() {
        return wthState;
    }

    public void setWthState(double wthState) {
        this.wthState = wthState;
    }

}