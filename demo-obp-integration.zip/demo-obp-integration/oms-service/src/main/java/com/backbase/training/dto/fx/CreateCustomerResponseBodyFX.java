package com.backbase.training.dto.fx;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@NoArgsConstructor
@Data
@Builder
@AllArgsConstructor
public class CreateCustomerResponseBodyFX {

    private CustomerBean customer;
    private PartyPersonBean party_person;
    private List<AddressesBean> addresses;

    @NoArgsConstructor
    @Data
    @Builder
    @AllArgsConstructor
    public static class CustomerBean {
        private String customerGroup;
        private String customerId;
        private String domainName;
        private String endDtm;
        private String loginId;
        private String memberId;
        private String partyGroupId;
        private String partyId;
        private String startDtm;
    }

    @NoArgsConstructor
    @Data
    @Builder
    @AllArgsConstructor
    public static class PartyPersonBean {
        private String _Id;
        private String _asOfDtm;
        private String _attch;
        private String _cDtm;
        private String _class;
        private int _schVn;
        private String _uDtm;
        private String _uLog;
        private int _vn;
        private String ageBracket;
        private String alternateLanguage;
        private String birthDate;
        private String cntry;
        private String contactPref;
        private String deathDate;
        private String education;
        private String employmentStatus;
        private String ethnicity;
        private ExtRefBean extRef;
        private String familiarName;
        private String firstName;
        private String gender;
        private String incBracket;
        private String lastName;
        private String lstContactDate;
        private String maidenName;
        private String maritalStatus;
        private String middleName;
        private String militaryStatus;
        private double moGrossInc;
        private String mothersMaidenName;
        private String name;
        private double nbrInHhold;
        private String occupation;
        private PartyUSBankInfoBean partyUSBankInfo;
        private PartyPersonDueDiligenceBean party_personDueDiligence;
        private String preferredLanguage;
        private String prefix;
        private String primaryEmployerId;
        private String residencyStatus;
        private String spouse;
        private String studentType;
        private String suffix;
        private String taxAddressId;
        private String tin;
        private String tinType;
        private String webAddr;
        private List<AddrsBean> addrs;
        private List<String> aliases;
        private List<EmailsBean> emails;
        private List<GovtIdsBean> govtIds;
        private List<PhonesBeanX> phones;

        @NoArgsConstructor
        @Data
        @Builder
        @AllArgsConstructor
        public static class ExtRefBean {
            private AdditionalProp1Bean additionalProp1;
            private AdditionalProp2Bean additionalProp2;
            private AdditionalProp3Bean additionalProp3;

            @NoArgsConstructor
            @Data
            @Builder
            @AllArgsConstructor
            public static class AdditionalProp1Bean {
                private int _schVn;
                private int _vn;
                private String name;
                private String path;
                private String ref;
            }

            @NoArgsConstructor
            @Data
            @Builder
            @AllArgsConstructor
            public static class AdditionalProp2Bean {
                private int _schVn;
                private int _vn;
                private String name;
                private String path;
                private String ref;
            }

            @NoArgsConstructor
            @Data
            @Builder
            @AllArgsConstructor
            public static class AdditionalProp3Bean {
                private int _schVn;
                private int _vn;
                private String name;
                private String path;
                private String ref;
            }
        }

        @NoArgsConstructor
        @Data
        @Builder
        @AllArgsConstructor
        public static class PartyUSBankInfoBean {
            private String _Id;
            private String _asOfDtm;
            private String _cDtm;
            private int _schVn;
            private String _uDtm;
            private String _uLog;
            private int _vn;
            private String bNotice1stDt;
            private String bNotice2ndDt;
            private boolean isElectronicStmt;
            private boolean isFiledW8;
            private boolean isFiledW9;
            private boolean isPaperStmt;
            private boolean isRepeatOverdrafter;
            private boolean isWthFed;
            private boolean isWthNra;
            private boolean isWthState;
            private String w8Dt;
            private String w9Dt;
        }

        @NoArgsConstructor
        @Data
        @Builder
        @AllArgsConstructor
        public static class PartyPersonDueDiligenceBean {
            private String _Id;
            private String _asOfDtm;
            private String _cDtm;
            private int _schVn;
            private String _uDtm;
            private String _uLog;
            private int _vn;
            private String assocFrgnSrPolFig;
            private String cntry;
            private boolean frgnSrPolFig;
            private IdVerifyBean idVerify;
            private OtherPropertiesBean otherProperties;

            @NoArgsConstructor
            @Data
            @Builder
            @AllArgsConstructor
            public static class IdVerifyBean {
                private int _schVn;
                private int _vn;
                private String verifyDtm;
                private String verifyScore;
                private String verifyScoreDesc;
                private String verifySrc;
            }

            @NoArgsConstructor
            @Data
            @Builder
            @AllArgsConstructor
            public static class OtherPropertiesBean {
                private String additionalProp1;
                private String additionalProp2;
                private String additionalProp3;
            }
        }

        @NoArgsConstructor
        @Data
        @Builder
        @AllArgsConstructor
        public static class AddrsBean {
            private String _Id;
            private int _Ix;
            private String _asOfDtm;
            private String _cDtm;
            private int _schVn;
            private String _uDtm;
            private String _uLog;
            private int _vn;
            private String addrId;
            private String addrType;
            private String label;
            private int priority;
            private String validFromDtm;
            private String validToDtm;
            private String verifyDtm;
            private String yrsAddr;
        }

        @NoArgsConstructor
        @Data
        @Builder
        @AllArgsConstructor
        public static class EmailsBean {
            private String _Id;
            private int _Ix;
            private String _asOfDtm;
            private String _cDtm;
            private int _schVn;
            private String _uDtm;
            private String _uLog;
            private int _vn;
            private String data;
            private String emailType;
            private boolean isPreferred;
            private String label;
            private String validFromDtm;
            private String validToDtm;
            private String verifyDtm;
        }

        @NoArgsConstructor
        @Data
        @Builder
        @AllArgsConstructor
        public static class GovtIdsBean {
            private String _Id;
            private int _Ix;
            private String _asOfDtm;
            private String _cDtm;
            private int _schVn;
            private String _uDtm;
            private String _uLog;
            private int _vn;
            private AttachBean attach;
            private String cntry;
            private String docType;
            private String expDate;
            private String fullName;
            private String idNbr;
            private String issueDate;
            private String region;
            private String verifyDtm;

            @NoArgsConstructor
            @Data
            @Builder
            @AllArgsConstructor
            public static class AttachBean {
                private String _Id;
                private int _Ix;
                private String _asOfDtm;
                private String _cDtm;
                private int _schVn;
                private String _uDtm;
                private String _uLog;
                private int _vn;
                private CreateByBean createBy;
                private String createDtm;
                private String desc;
                private String encoding;
                private String itemType;
                private String name;
                private String val;
                private String valType;

                @NoArgsConstructor
                @Data
                @Builder
                @AllArgsConstructor
                public static class CreateByBean {
                    private String _Id;
                    private String _asOfDtm;
                    private String _attch;
                    private String _class;
                    private int _schVn;
                    private String _uLog;
                    private int _vn;
                    private String cntry;
                    private String contactPref;
                    private ExtRefBeanX extRef;
                    private String lstContactDate;
                    private String name;
                    private PartyUSBankInfoBeanX partyUSBankInfo;
                    private String taxAddressId;
                    private String tin;
                    private String tinType;
                    private List<AddrsBeanX> addrs;
                    private List<EmailsBeanX> emails;
                    private List<PhonesBean> phones;

                    @NoArgsConstructor
                    @Data
                    @Builder
                    @AllArgsConstructor
                    public static class ExtRefBeanX {
                        private AdditionalProp1BeanX additionalProp1;
                        private AdditionalProp2BeanX additionalProp2;
                        private AdditionalProp3BeanX additionalProp3;

                        @NoArgsConstructor
                        @Data
                        @Builder
                        @AllArgsConstructor
                        public static class AdditionalProp1BeanX {
                            private int _schVn;
                            private int _vn;
                            private String name;
                            private String path;
                            private String ref;
                        }

                        @NoArgsConstructor
                        @Data
                        @Builder
                        @AllArgsConstructor
                        public static class AdditionalProp2BeanX {
                            private int _schVn;
                            private int _vn;
                            private String name;
                            private String path;
                            private String ref;
                        }

                        @NoArgsConstructor
                        @Data
                        @Builder
                        @AllArgsConstructor
                        public static class AdditionalProp3BeanX {
                            private int _schVn;
                            private int _vn;
                            private String name;
                            private String path;
                            private String ref;
                        }
                    }

                    @NoArgsConstructor
                    @Data
                    @Builder
                    @AllArgsConstructor
                    public static class PartyUSBankInfoBeanX {
                        private String _Id;
                        private String _asOfDtm;
                        private String _cDtm;
                        private int _schVn;
                        private String _uDtm;
                        private String _uLog;
                        private int _vn;
                        private String bNotice1stDt;
                        private String bNotice2ndDt;
                        private boolean isElectronicStmt;
                        private boolean isFiledW8;
                        private boolean isFiledW9;
                        private boolean isPaperStmt;
                        private boolean isRepeatOverdrafter;
                        private boolean isWthFed;
                        private boolean isWthNra;
                        private boolean isWthState;
                        private String w8Dt;
                        private String w9Dt;
                    }

                    @NoArgsConstructor
                    @Data
                    @Builder
                    @AllArgsConstructor
                    public static class AddrsBeanX {
                        private String _Id;
                        private int _Ix;
                        private String _asOfDtm;
                        private String _cDtm;
                        private int _schVn;
                        private String _uDtm;
                        private String _uLog;
                        private int _vn;
                        private String addrId;
                        private String addrType;
                        private String label;
                        private int priority;
                        private String validFromDtm;
                        private String validToDtm;
                        private String verifyDtm;
                        private String yrsAddr;
                    }

                    @NoArgsConstructor
                    @Data
                    @Builder
                    @AllArgsConstructor
                    public static class EmailsBeanX {
                        private String _Id;
                        private int _Ix;
                        private String _asOfDtm;
                        private String _cDtm;
                        private int _schVn;
                        private String _uDtm;
                        private String _uLog;
                        private int _vn;
                        private String data;
                        private String emailType;
                        private boolean isPreferred;
                        private String label;
                        private String validFromDtm;
                        private String validToDtm;
                        private String verifyDtm;
                    }

                    @NoArgsConstructor
                    @Data
                    @Builder
                    @AllArgsConstructor
                    public static class PhonesBean {
                        private String _Id;
                        private int _Ix;
                        private String _asOfDtm;
                        private String _cDtm;
                        private int _schVn;
                        private String _uDtm;
                        private String _uLog;
                        private int _vn;
                        private String data;
                        private boolean isPreferred;
                        private String label;
                        private String phoneType;
                        private String validFromDtm;
                        private String validToDtm;
                        private String verifyDtm;
                    }
                }
            }
        }

        @NoArgsConstructor
        @Data
        @Builder
        @AllArgsConstructor
        public static class PhonesBeanX {
            private String _Id;
            private int _Ix;
            private String _asOfDtm;
            private String _cDtm;
            private int _schVn;
            private String _uDtm;
            private String _uLog;
            private int _vn;
            private String data;
            private boolean isPreferred;
            private String label;
            private String phoneType;
            private String validFromDtm;
            private String validToDtm;
            private String verifyDtm;
        }
    }

    @NoArgsConstructor
    @Data
    @Builder
    @AllArgsConstructor
    public static class AddressesBean {
        private String _Id;
        private int _Ix;
        private String _asOfDtm;
        private int _schVn;
        private String _uLog;
        private int _vn;
        private String addrId;
        private String addrType;
        private String city;
        private String cntry;
        private GeoLocBean geoLoc;
        private String label;
        private String postCode;
        private String premise;
        private int priority;
        private String region;
        private String street;
        private String validFromDtm;
        private String validToDtm;
        private String verifyDtm;
        private String yrsAddr;

        @NoArgsConstructor
        @Data
        @Builder
        @AllArgsConstructor
        public static class GeoLocBean {
            private int _schVn;
            private int _vn;
            private int alt;
            private String geoplace;
            private int lat;
            private int lon;
        }
    }
}
