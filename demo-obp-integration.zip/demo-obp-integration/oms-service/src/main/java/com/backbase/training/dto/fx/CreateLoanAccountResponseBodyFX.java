package com.backbase.training.dto.fx;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@NoArgsConstructor
@Data
@Builder
@AllArgsConstructor
public class CreateLoanAccountResponseBodyFX {

    private List<AcctPartyRelsBean> acctPartyRels;
    private List<CreatedAccountsBean> createdAccounts;

    @NoArgsConstructor
    @Data
    public static class AcctPartyRelsBean {
        private int acctGroup;
        private String acctNbr;
        private String custId;
        private String groupId;
        private String partyId;
        private String partyRelDesc;
        private String relType;
        private String _cLog;
        private String _cDtm;
        private int _vn;
        private int _schVn;
    }

    @NoArgsConstructor
    @Data
    public static class CreatedAccountsBean {
        private String prodName;
        private AcctBkBean acct_bk;
        private List<PosnLnDtlBean> posn_lnDtl;

        @NoArgsConstructor
        @Data
        public static class AcctBkBean {
            private int acctGroup;
            private String acctNbr;
            private String acctTitle;
            private String desc;
            private String openDtm;
            private String _cLog;
            private int _vn;
            private int _schVn;
            private String _class;
            private String baseCcy;
            private boolean isBrokered;
            private boolean isElectronicStmt;
            private boolean isPaperStmt;
            private String tmZoneCode;
            private double aggBalCDA;
            private double aggBalDDA;
            private double aggBalSDA;
            private double aggBalMMA;
            private double aggBalCMA;
            private double aggBalCCA;
            private double aggBalEQU;
            private double aggBalILA;
            private double aggBalCLA;
            private double aggBalLOC;
            private double aggBalAsset;
            private double aggBalLiability;
            private String _cDtm;
        }

        @NoArgsConstructor
        @Data
        public static class PosnLnDtlBean {
            private String prodName;
            private PosnLnBean posn_ln;

            @NoArgsConstructor
            @Data
            public static class PosnLnBean {
                private String _Id;
                private int acctGroup;
                private String acctNbr;
                private double bal;
                private String nextPosnCalDtm;
                private String openDtm;
                private String posnAcctNbr;
                private String posnName;
                private int posnNbr;
                private String tmZoneCode;
                private String _uLog;
                private String _uDtm;
                private int _vn;
                private int _schVn;
                private String _class;
                private AcctgSegBean acctgSeg;
                private String ccyCode;
                private double crLimit;
                private int glCat;
                private String glSetCode;
                private String maturityDtm;
                private String prodName;
                private SubBalsBean subBals;
                private String _cDtm;
                private PosnLnRepayBean posn_lnRepay;
                private PosnLnFeeBean posn_lnFee;
                private PosnLnIntBean posn_lnInt;
                private String _attch;

                @NoArgsConstructor
                @Data
                public static class AcctgSegBean {
                    private String deptId;
                    private String vertical;
                }

                @NoArgsConstructor
                @Data
                public static class SubBalsBean {
                    private Dec2Bean dec2;
                    private Dec5Bean dec5;

                    @NoArgsConstructor
                    @Data
                    public static class Dec2Bean {
                        private double lateChrg;
                        private double lnFee;
                    }

                    @NoArgsConstructor
                    @Data
                    public static class Dec5Bean {
                        private double accrInt;
                        private double negAccr;
                    }
                }

                @NoArgsConstructor
                @Data
                public static class PosnLnRepayBean {
                    private String _Id;
                    private String amortizeDur;
                    private String componentName;
                    private String dueDate;
                    private double fixPmtAmt;
                    private String gracePeriod;
                    private double intMthd;
                    private boolean isFixAmortize;
                    private boolean isRevolving;
                    private double minPmt;
                    private String nextReceivableDtm;
                    private double pmtApplAdvance;
                    private PmtApplMthdBean pmtApplMthd;
                    private String pmtDur;
                    private String pmtFreq;
                    private String pmtOffset;
                    private double prinBalBase;
                    private double prinMthd;
                    private String startDtm;
                    private double toleranceAmt;
                    private int version;
                    private String _uLog;
                    private String _cDtm;
                    private String _uDtm;
                    private int _vn;
                    private int _schVn;
                    private List<PastDueBean> pastDue;

                    @NoArgsConstructor
                    @Data
                    public static class PmtApplMthdBean {
                        private CurrentBean Current;
                        private PastBean Past;
                        private PriorityBean Priority;

                        @NoArgsConstructor
                        @Data
                        public static class CurrentBean {
                            private String direction;
                            private List<String> dueItemOrder;
                        }

                        @NoArgsConstructor
                        @Data
                        public static class PastBean {
                            private String direction;
                            private List<String> dueItemOrder;
                        }

                        @NoArgsConstructor
                        @Data
                        public static class PriorityBean {
                            private String direction;
                            private List<String> dueItemOrder;
                        }
                    }

                    @NoArgsConstructor
                    @Data
                    public static class PastDueBean {
                        private String pastDueTerm;
                    }
                }

                @NoArgsConstructor
                @Data
                public static class PosnLnFeeBean {
                    private String _Id;
                    private String componentName;
                    private FeeDtlBean feeDtl;
                    private int version;
                    private String _cDtm;
                    private int _vn;
                    private int _schVn;

                    @NoArgsConstructor
                    @Data
                    public static class FeeDtlBean {
                        private LateChargeBean late_charge;

                        @NoArgsConstructor
                        @Data
                        public static class LateChargeBean {
                        }
                    }
                }

                @NoArgsConstructor
                @Data
                public static class PosnLnIntBean {
                    private String _Id;
                    private String accrCalcTm;
                    private String accumToDtm;
                    private double apr;
                    private double balOpt;
                    private double calcMthd;
                    private String componentName;
                    private IndexBean index;
                    private double nomRate;
                    private int version;
                    private String _uLog;
                    private String _cDtm;
                    private String _uDtm;
                    private int _vn;
                    private int _schVn;

                    @NoArgsConstructor
                    @Data
                    public static class IndexBean {
                        private String indexName;
                        private String nextReviewDtm;
                        private String reviewFreq;
                    }
                }
            }
        }
    }
}
