
package com.backbase.training.dto.queue.depupdate;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class AcctgSeg {

    @SerializedName("deptId")
    @Expose
    private String deptId;
    @SerializedName("vertical")
    @Expose
    private String vertical;

    public String getDeptId() {
        return deptId;
    }

    public void setDeptId(String deptId) {
        this.deptId = deptId;
    }

    public String getVertical() {
        return vertical;
    }

    public void setVertical(String vertical) {
        this.vertical = vertical;
    }

}
