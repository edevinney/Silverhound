package com.backbase.training.utils;

import org.apache.camel.Exchange;
import org.springframework.stereotype.Component;

@Component
public class BodyAndHeadersRequestSupplier {

    public void setHeadersFX(Exchange exchange, String method) {
        exchange.getOut().setHeader(Exchange.CONTENT_TYPE, "application/json");
        exchange.getOut().setHeader("client_id", "b77dffd5aa0824ebbff7c83a8b57f51d891b03b903c8b21f5660ff7147f9d1ea2d36");
        exchange.getOut().setHeader("secret", "06083c4870db2964266c83fc");
        exchange.getOut().setHeader("Fnx-Header", "{\"identity\":{\"userRoles\":[\"developer\"]}}");
        exchange.getOut().setHeader(Exchange.HTTP_METHOD, method);
    }
}
