package com.backbase.training.api.controllers;

import com.backbase.loan_type.rest.spec.v1.loan.types.LoantypesApi;
import com.backbase.loan_type.rest.spec.v1.loan.types.LoantypesGetResponseBody;
import com.backbase.training.routes.LoanTypeRoute;
import org.apache.camel.EndpointInject;
import org.apache.camel.ProducerTemplate;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

@RestController
public class LoanTypeRestController implements LoantypesApi {

    @EndpointInject(uri = LoanTypeRoute.DIRECT_POST)
    private ProducerTemplate loanRoute;

    @Override
    public List<LoantypesGetResponseBody> getLoantypes(
            HttpServletRequest httpServletRequest,
            HttpServletResponse httpServletResponse) {
        return (List<LoantypesGetResponseBody>) loanRoute.requestBody(null);
    }
}
