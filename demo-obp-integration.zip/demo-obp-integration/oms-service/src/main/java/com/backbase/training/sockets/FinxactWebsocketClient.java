package com.backbase.training.sockets;

import java.net.URI;
import java.nio.ByteBuffer;

import com.backbase.training.utils.Helper;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.util.TextUtils;
import org.java_websocket.client.WebSocketClient;
import org.java_websocket.drafts.Draft;
import org.java_websocket.handshake.ServerHandshake;

@Slf4j
public class FinxactWebsocketClient extends WebSocketClient {
    private FxEventsProducer eventsProducer;
    private IWebSocketEventsListener socketEventsListener;
    private int numberOfKeepAlivesReceived = 0;

    public FinxactWebsocketClient(URI serverUri, Draft draft) {
        super(serverUri, draft);
    }

    public FinxactWebsocketClient(URI serverURI, FxEventsProducer eventsProducer, IWebSocketEventsListener socketEventsListener) {
        super(serverURI);
        this.eventsProducer = eventsProducer;
        this.socketEventsListener = socketEventsListener;
    }

    @Override
    public void onOpen(ServerHandshake handshakedata) {
        log.info("New connection opened with FX Event hub");
        this.eventsProducer.start();
    }

    @Override
    public void onClose(int code, String reason, boolean remote) {
        log.info("Connection closed with exit code " + code + " with reason [" + reason + "] and remote=" + remote + ". KeepAlive messages #: " + numberOfKeepAlivesReceived);
        numberOfKeepAlivesReceived = 0;
        this.eventsProducer.stop();
        if (this.socketEventsListener != null) {
            this.socketEventsListener.onDisconnected(code, reason, remote);
        }
    }

    @Override
    public void onMessage(String message) {
        try {
            FxEventBase eventOverview = Helper.Gson.fromJson(message, FxEventBase.class);
            if (eventOverview != null && !TextUtils.isEmpty(eventOverview.event)) {
                boolean processed = this.processEventFromFinxact(eventOverview, message);
                if (needsAck(eventOverview)) {
                    this.ackMessage(eventOverview, processed);
                }
            }
        } catch (Exception ex) {
            log.error("Error during message parsing new message {}. Details {}", ex, message);
        }
    }

    @Override
    public void onMessage(ByteBuffer message) {
        log.debug("New bytebuffer message received from FX");
    }

    @Override
    public void onError(Exception ex) {
        log.error("Error happened", ex);
    }

    private boolean needsAck(FxEventBase eventOverview) {
        if ("/keepalive".equals(eventOverview.event)) {
            return false;
        }
        if ("/connected:".equals(eventOverview.event)) {
            return true;
        }
        return true;
    }

    private boolean processEventFromFinxact(FxEventBase eventOverview, String message) {
        if ("/keepalive".equals(eventOverview.event)) {
            this.numberOfKeepAlivesReceived++;
            return true;
        }
        if ("/connected:".equals(eventOverview.event)) {
            log.debug("Connection hello received");
            socketEventsListener.onConnected();
            return true;
        }
        boolean success = this.eventsProducer.dispatch(message);
        return success;
    }

    private void ackMessage(FxEventBase eventOverview, boolean success) {
        String responseType = success ? "ack" : "nack";
        String response = "{\"event\":\"" + responseType + "\",\"msg\": \"" + eventOverview.id + "\"}";
        log.debug("Sending {} message back: '{}'", responseType, response);
        this.send(response);
    }
}