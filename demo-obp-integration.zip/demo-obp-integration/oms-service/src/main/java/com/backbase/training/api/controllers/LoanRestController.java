package com.backbase.training.api.controllers;

import com.backbase.loan.rest.spec.v1.loan.LoanApi;
import com.backbase.loan.rest.spec.v1.loan.LoanPostRequestBody;
import com.backbase.loan.rest.spec.v1.loan.LoanPostResponseBody;
import org.apache.camel.EndpointInject;
import org.apache.camel.ProducerTemplate;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import static com.backbase.training.utils.Constants.DIRECT_POST;

@RestController
public class LoanRestController implements LoanApi {

    @EndpointInject(uri = DIRECT_POST)
    private ProducerTemplate loanRoute;

    @Override
    public LoanPostResponseBody postLoan(
            @Valid LoanPostRequestBody loanPostRequestBody,
            HttpServletRequest httpServletRequest,
            HttpServletResponse httpServletResponse) {
        return (LoanPostResponseBody) loanRoute.requestBody(loanPostRequestBody);
    }

}