
package com.backbase.training.dto.queue.depupdate;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class PosnDepInt {

    @SerializedName("_Id")
    @Expose
    private String id;
    @SerializedName("_cDtm")
    @Expose
    private String cDtm;
    @SerializedName("_cLogRef")
    @Expose
    private String cLogRef;
    @SerializedName("_flags")
    @Expose
    private int flags;
    @SerializedName("_schVn")
    @Expose
    private int schVn;
    @SerializedName("_uDtm")
    @Expose
    private String uDtm;
    @SerializedName("_uLog")
    @Expose
    private String uLog;
    @SerializedName("_uLogRef")
    @Expose
    private String uLogRef;
    @SerializedName("_vn")
    @Expose
    private int vn;
    @SerializedName("accrCalcTm")
    @Expose
    private String accrCalcTm;
    @SerializedName("accrIntBal")
    @Expose
    private double accrIntBal;
    @SerializedName("accumToDtm")
    @Expose
    private String accumToDtm;
    @SerializedName("apy")
    @Expose
    private double apy;
    @SerializedName("apye")
    @Expose
    private double apye;
    @SerializedName("balOpt")
    @Expose
    private double balOpt;
    @SerializedName("calcMthd")
    @Expose
    private double calcMthd;
    @SerializedName("componentName")
    @Expose
    private String componentName;
    @SerializedName("daysNxtPost")
    @Expose
    private double daysNxtPost;
    @SerializedName("disbmtOpt")
    @Expose
    private double disbmtOpt;
    @SerializedName("index")
    @Expose
    private Index index;
    @SerializedName("is1099Exempt")
    @Expose
    private boolean is1099Exempt;
    @SerializedName("isCompoundDly")
    @Expose
    private boolean isCompoundDly;
    @SerializedName("isWthFed")
    @Expose
    private boolean isWthFed;
    @SerializedName("isWthNra")
    @Expose
    private boolean isWthNra;
    @SerializedName("isWthState")
    @Expose
    private boolean isWthState;
    @SerializedName("negAccrIntBal")
    @Expose
    private double negAccrIntBal;
    @SerializedName("nextPostDtm")
    @Expose
    private String nextPostDtm;
    @SerializedName("nomRate")
    @Expose
    private double nomRate;
    @SerializedName("postFreq")
    @Expose
    private String postFreq;
    @SerializedName("sumIntPd")
    @Expose
    private double sumIntPd;
    @SerializedName("version")
    @Expose
    private int version;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCDtm() {
        return cDtm;
    }

    public void setCDtm(String cDtm) {
        this.cDtm = cDtm;
    }

    public String getCLogRef() {
        return cLogRef;
    }

    public void setCLogRef(String cLogRef) {
        this.cLogRef = cLogRef;
    }

    public int getFlags() {
        return flags;
    }

    public void setFlags(int flags) {
        this.flags = flags;
    }

    public int getSchVn() {
        return schVn;
    }

    public void setSchVn(int schVn) {
        this.schVn = schVn;
    }

    public String getUDtm() {
        return uDtm;
    }

    public void setUDtm(String uDtm) {
        this.uDtm = uDtm;
    }

    public String getULog() {
        return uLog;
    }

    public void setULog(String uLog) {
        this.uLog = uLog;
    }

    public String getULogRef() {
        return uLogRef;
    }

    public void setULogRef(String uLogRef) {
        this.uLogRef = uLogRef;
    }

    public int getVn() {
        return vn;
    }

    public void setVn(int vn) {
        this.vn = vn;
    }

    public String getAccrCalcTm() {
        return accrCalcTm;
    }

    public void setAccrCalcTm(String accrCalcTm) {
        this.accrCalcTm = accrCalcTm;
    }

    public double getAccrIntBal() {
        return accrIntBal;
    }

    public void setAccrIntBal(double accrIntBal) {
        this.accrIntBal = accrIntBal;
    }

    public String getAccumToDtm() {
        return accumToDtm;
    }

    public void setAccumToDtm(String accumToDtm) {
        this.accumToDtm = accumToDtm;
    }

    public double getApy() {
        return apy;
    }

    public void setApy(double apy) {
        this.apy = apy;
    }

    public double getApye() {
        return apye;
    }

    public void setApye(double apye) {
        this.apye = apye;
    }

    public double getBalOpt() {
        return balOpt;
    }

    public void setBalOpt(double balOpt) {
        this.balOpt = balOpt;
    }

    public double getCalcMthd() {
        return calcMthd;
    }

    public void setCalcMthd(double calcMthd) {
        this.calcMthd = calcMthd;
    }

    public String getComponentName() {
        return componentName;
    }

    public void setComponentName(String componentName) {
        this.componentName = componentName;
    }

    public double getDaysNxtPost() {
        return daysNxtPost;
    }

    public void setDaysNxtPost(double daysNxtPost) {
        this.daysNxtPost = daysNxtPost;
    }

    public double getDisbmtOpt() {
        return disbmtOpt;
    }

    public void setDisbmtOpt(double disbmtOpt) {
        this.disbmtOpt = disbmtOpt;
    }

    public Index getIndex() {
        return index;
    }

    public void setIndex(Index index) {
        this.index = index;
    }

    public boolean isIs1099Exempt() {
        return is1099Exempt;
    }

    public void setIs1099Exempt(boolean is1099Exempt) {
        this.is1099Exempt = is1099Exempt;
    }

    public boolean isIsCompoundDly() {
        return isCompoundDly;
    }

    public void setIsCompoundDly(boolean isCompoundDly) {
        this.isCompoundDly = isCompoundDly;
    }

    public boolean isIsWthFed() {
        return isWthFed;
    }

    public void setIsWthFed(boolean isWthFed) {
        this.isWthFed = isWthFed;
    }

    public boolean isIsWthNra() {
        return isWthNra;
    }

    public void setIsWthNra(boolean isWthNra) {
        this.isWthNra = isWthNra;
    }

    public boolean isIsWthState() {
        return isWthState;
    }

    public void setIsWthState(boolean isWthState) {
        this.isWthState = isWthState;
    }

    public double getNegAccrIntBal() {
        return negAccrIntBal;
    }

    public void setNegAccrIntBal(double negAccrIntBal) {
        this.negAccrIntBal = negAccrIntBal;
    }

    public String getNextPostDtm() {
        return nextPostDtm;
    }

    public void setNextPostDtm(String nextPostDtm) {
        this.nextPostDtm = nextPostDtm;
    }

    public double getNomRate() {
        return nomRate;
    }

    public void setNomRate(double nomRate) {
        this.nomRate = nomRate;
    }

    public String getPostFreq() {
        return postFreq;
    }

    public void setPostFreq(String postFreq) {
        this.postFreq = postFreq;
    }

    public double getSumIntPd() {
        return sumIntPd;
    }

    public void setSumIntPd(double sumIntPd) {
        this.sumIntPd = sumIntPd;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

}
