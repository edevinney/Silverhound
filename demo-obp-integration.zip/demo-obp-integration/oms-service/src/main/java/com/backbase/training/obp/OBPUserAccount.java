package com.backbase.training.obp;

import com.backbase.training.multicore.IBankCoreUserAccount;
import com.backbase.training.utils.Helper;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.Collections;

public class OBPUserAccount implements IBankCoreUserAccount {

    private String _userName;
    private String _password;

    public OBPUserAccount(String userName, String password) {

        _userName = userName;
        _password = password;
    }

    @Override
    public String getUserName() {
        return _userName;
    }

    @Override
    public String getAuthenticationToken() {
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Collections.singletonList(MediaType.TEXT_PLAIN));
        headers.set("Authorization", "DirectLogin username=\"" + this._userName + "\", password=\"" + this._password + "\", consumer_key=\"vqlfkbau1cogismpzl1g0fsiqq32l4hnnyswoipu\"");
        HttpEntity<String> entity = new HttpEntity<>("", headers);
        try {
            String response = restTemplate.postForObject("https://apisandbox.openbankproject.com/my/logins/direct", entity, String.class);
            DirectLoginTokenResponse tokenResponse = Helper.Gson.fromJson(response, DirectLoginTokenResponse.class);
            if (tokenResponse != null)
                return tokenResponse.token;
            else
                return "";
        } catch (HttpClientErrorException e) {
            System.out.println("OBP DirectLogin error for " + this._userName);
            System.out.println(e.getMessage());
            return null;
        }

    }
}
