package com.backbase.training.utils;

import org.apache.camel.Exchange;
import org.apache.http.client.methods.RequestBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

import java.util.Collections;

@Component
public class RequestDataSupplier {

    @Value("${finxact.headers.client_id}")
    private String client_id;
    @Value("${finxact.headers.secret}")
    private String secret;
    @Value("${finxact.headers.fnx_header}")
    private String fnxHeader;
    @Value("${finxact.path.root}")
    private String rootUrl;
    @Value("${finxact.path.create.account}")
    private String accountUrl;
    @Value("${finxact.path.create.account_number}")
    private String accountNumberGeneration;
    @Value("${finxact.path.create.customer}")
    private String customerUrl;
    @Value("${finxact.path.get.party_group}")
    private String partyGroupUrl;
    @Value("${finxact.path.create.transaction}")
    private String transactionUrl;
    @Value("${finxact.path.get.balance}")
    private String balanceUrl;
    @Value("${finxact.path.get.transactions}")
    private String transactionsUrl;
    @Value("${finxact.path.get.product_type}")
    private String productTypeUrl;
    @Value("${finxact.account.group}")
    private Integer accountGroup;

    public void setHeadersFxRoute(Exchange exchange, String method) {
        exchange.getOut().setHeader(Exchange.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
        exchange.getOut().setHeader("client_id", client_id);
        exchange.getOut().setHeader("secret", secret);
        exchange.getOut().setHeader("Fnx-Header", fnxHeader);
        exchange.getOut().setHeader(Exchange.HTTP_METHOD, method);
    }

    public HttpHeaders setHeadersFxRest() {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        headers.set("client_id", client_id);
        headers.set("secret", secret);
        headers.set("Fnx-Header", fnxHeader);
        return headers;
    }

    public RequestBuilder setHeadersFxRequestBuilder(RequestBuilder builder) {
        return builder.setHeader(org.apache.http.HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON.toString())
                .setHeader("client_id", client_id)
                .setHeader("secret", secret)
                .setHeader("Fnx-Header", fnxHeader)
                .setHeader("Accept", MediaType.APPLICATION_JSON.toString());
    }

    public String getCustomerUrl() {
        return rootUrl.concat(customerUrl);
    }

    public String getAccountUrl() {
        return rootUrl.concat(accountUrl);
    }

    public String getAccountNumberGenerationUrl() {
        return rootUrl.concat(accountNumberGeneration);
    }

    public String getPartyGroupUrl() {
        return rootUrl.concat(partyGroupUrl);
    }

    public String getCreateTransactionUrl() {
        return rootUrl.concat(transactionUrl);
    }

    public String getBalanceUrl() {
        return rootUrl.concat(balanceUrl);
    }

    public String getTransactionsFromFxUrl() {
        return rootUrl.concat(transactionsUrl);
    }

    public String getProductTypes() {
        return rootUrl.concat(productTypeUrl);
    }

    public Integer getAccountGroup() {
        return accountGroup;
    }
}
