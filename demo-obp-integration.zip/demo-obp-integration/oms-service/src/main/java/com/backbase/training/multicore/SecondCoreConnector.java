package com.backbase.training.multicore;

import com.backbase.training.obp.OBPAccountInformation;
import com.backbase.training.obp.OBPApiService;
import com.backbase.training.obp.OBPUserAccount;
import com.backbase.training.obp.OBPUserMapper;
import com.backbase.training.obp.models.SandboxAccount;
import com.backbase.training.obp.models.SandboxAccounts;
import com.backbase.training.utils.Helper;

import java.util.List;

public class SecondCoreConnector {

    private IBankCoreUserMapper _mapper;
    private IBankCoreApiService _apiService;

    public SecondCoreConnector(IBankCoreUserMapper mapper, IBankCoreApiService apiService) {
        _mapper = mapper;
        _apiService = apiService;
    }

    public void TestTryAllSandboxAccounts() {
        List<SandboxAccount> accounts = ((OBPUserMapper) _mapper).GetSandboxAccounts();
        accounts.forEach(testAccount -> {
            OBPUserAccount acc = new OBPUserAccount(testAccount.getUser_name(), testAccount.getPassword());
            try {
                _apiService.GetUserAccounts(acc);
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        });

    }

    public void TestMapUsers(int start, int stop) {
        for (int userId = start; userId < stop; userId++) {
            String userName = "U000" + userId;
            IBankCoreUserAccount user = ((OBPUserMapper) _mapper).MapUserByKey("", userName);
            System.out.println("USER " + userName + " would be mapped to sandbox user with name " + user.getUserName());
        }
    }

    public List<IBankCoreAccountInformation> FetchCoreAccountsForUserWithKey(String key, String userName) {
        IBankCoreUserAccount userLogin = _mapper.MapUserByKey(key, userName);
        return _apiService.GetUserAccounts(userLogin);
    }

}
