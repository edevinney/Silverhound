
package com.backbase.training.obp.models;

import java.util.List;

@lombok.Data
public class AccountDetailsResponse {
    private String id;
    private String bank_id;
    private String label;
    private String number;
    private String type;
    private Balance balance;
    private List<AccountRouting> account_routings;
}