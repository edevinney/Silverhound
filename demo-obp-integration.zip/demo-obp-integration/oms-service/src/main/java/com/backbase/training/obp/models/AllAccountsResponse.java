
package com.backbase.training.obp.models;

import java.util.List;

@lombok.Data
public class AllAccountsResponse {
    private List<Account> accounts;
}