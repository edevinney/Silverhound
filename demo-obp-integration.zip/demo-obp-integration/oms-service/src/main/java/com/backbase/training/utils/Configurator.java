package com.backbase.training.utils;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.net.InetSocketAddress;
import java.net.Proxy;

@Component
public class Configurator {

    @Value("${finxact.use_proxy}")
    public Boolean useProxyForFinxact = false;

    @Value("${finxact.proxy.host}")
    public String finxactProxyHost = "127.0.0.1";

    @Value("${finxact.proxy.port}")
    public Integer finxactProxyPortInt = 8888;

    public String finxactProxyPort = Integer.toString(this.finxactProxyPortInt);

    public RestTemplate getRestTemplate() {
        if (useProxyForFinxact) {
            SimpleClientHttpRequestFactory clientHttpReq = new SimpleClientHttpRequestFactory();
            Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(finxactProxyHost, finxactProxyPortInt));
            clientHttpReq.setProxy(proxy);
            return new RestTemplate(clientHttpReq);
        } else {
            return new RestTemplate();
        }
    }
}
