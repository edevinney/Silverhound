package com.backbase.training.utils;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.LinkedList;
import java.util.stream.Stream;

@Component
public class UserExternalIdSupplier {
    @Value("${resources.users}")
    private String usersFileName;

    private LinkedList<String> linkedList = new LinkedList<>();

    public String getUserExternalId() {
        if (linkedList.isEmpty()) getIdsFromFileAndWriteThemToQueue();
        String newUserId = getFirstLineFromQueueAndWriteItToVariable();
        rewriteFileWithQueueContent();
        return newUserId;
    }

    private Path getFilePath() {
        String absolutePath = new File("").getAbsolutePath();
        String path = absolutePath.concat(usersFileName);
        Path fullPath = Paths.get(path);
        return fullPath;
    }

    private void getIdsFromFileAndWriteThemToQueue() {
        try (Stream<String> lines = Files.lines(getFilePath())) {
            lines.forEach(linkedList::add);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private String getFirstLineFromQueueAndWriteItToVariable() {
        if (!linkedList.isEmpty()) {
            return linkedList.removeFirst();
        }
        return "";
    }

    private void rewriteFileWithQueueContent() {
        try {
            Files.write(getFilePath(), linkedList);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
