package com.backbase.training.dto.fx;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class AccountGenerationDto {
    @SerializedName("AcctNbr")
    @Expose
    private String acctNbr;

    public String getAcctNbr() {
        return acctNbr;
    }

    public void setAcctNbr(String acctNbr) {
        this.acctNbr = acctNbr;
    }
}
