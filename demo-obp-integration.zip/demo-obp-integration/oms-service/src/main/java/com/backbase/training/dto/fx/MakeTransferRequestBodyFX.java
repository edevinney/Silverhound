package com.backbase.training.dto.fx;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@NoArgsConstructor
@Data
@Builder
@AllArgsConstructor
public class MakeTransferRequestBodyFX {

    /**
     * mode : 2
     * entries : [{"acctGroup":1,"acctNbr":"229950391436","trnAmt":200,"isDr":true},{"acctGroup":1,"acctNbr":"830104468185","trnAmt":200,"isDr":false,"comment":"Transfer"}]
     */

    private int mode;
    private List<Entries> entries;

    @NoArgsConstructor
    @Data
    @Builder
    @AllArgsConstructor
    public static class Entries {
        /**
         * acctGroup : 1
         * acctNbr : 229950391436
         * trnAmt : 200
         * isDr : true
         * comment : Transfer
         */

        private int acctGroup;
        private String acctNbr;
        private double trnAmt;
        private boolean isDr;
        private String comment;
    }
}
