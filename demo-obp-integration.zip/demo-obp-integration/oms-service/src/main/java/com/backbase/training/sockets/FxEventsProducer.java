package com.backbase.training.sockets;

import lombok.extern.slf4j.Slf4j;
import org.apache.activemq.ActiveMQConnectionFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.jms.*;

@Component
@Slf4j
public class FxEventsProducer {

    @Value("${finxact.activemq.address}")
    private String activeMqAddress = "";
    @Value("${finxact.activemq.topic}")
    private String activeMqTopic = "";
    Connection connection;
    Session session;
    MessageProducer producer;

    public void start() {
        try {
            ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory(activeMqAddress);
            connection = connectionFactory.createConnection();
            connection.start();
            session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
            Destination destination = session.createQueue(activeMqTopic);
            producer = session.createProducer(destination);
            producer.setDeliveryMode(DeliveryMode.NON_PERSISTENT);
        } catch (Exception e) {
            log.debug("Exception when starting up Fx Queue: " + e);
            e.printStackTrace();
        }
    }

    public void stop() {
        try {
            if (session != null)
                session.close();
            if (connection != null)
                connection.close();
            if (producer != null)
                producer = null;
        } catch (Exception e) {
            log.debug("Exception when shutting down Fx Queue: " + e);
            e.printStackTrace();
        }
    }

    public boolean dispatch(String jsonMessage) {
        try {
            TextMessage message = session.createTextMessage(jsonMessage);
            producer.send(message);
            return true;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }
}
