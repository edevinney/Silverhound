package com.backbase.training.multicore;

public interface  IBankCoreUserMapper{
    IBankCoreUserAccount MapUserByKey(String key, String userName);
}