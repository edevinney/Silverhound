
package com.backbase.training.dto.queue.depupdate;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Dec5 {

    @SerializedName("accrInt")
    @Expose
    private double accrInt;
    @SerializedName("negAccr")
    @Expose
    private double negAccr;

    public double getAccrInt() {
        return accrInt;
    }

    public void setAccrInt(double accrInt) {
        this.accrInt = accrInt;
    }

    public double getNegAccr() {
        return negAccr;
    }

    public void setNegAccr(double negAccr) {
        this.negAccr = negAccr;
    }

}