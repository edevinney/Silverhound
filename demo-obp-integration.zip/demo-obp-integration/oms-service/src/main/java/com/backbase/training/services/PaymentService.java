package com.backbase.training.services;

import com.backbase.buildingblocks.backend.api.utils.ApiUtils;
import com.backbase.buildingblocks.backend.communication.event.proxy.RequestProxyWrapper;
import com.backbase.buildingblocks.backend.internalrequest.InternalRequest;
import com.backbase.buildingblocks.presentation.errors.BadRequestException;
import com.backbase.buildingblocks.presentation.errors.InternalServerErrorException;
import com.backbase.buildingblocks.presentation.errors.NotFoundException;
import com.backbase.dbs.integration.paymentorder.listener.spec.v2.paymentorders.PaymentOrdersListener;
import com.backbase.dbs.integration.paymentorder.rest.spec.v2.paymentorders.CancelResponse;
import com.backbase.dbs.integration.paymentorder.rest.spec.v2.paymentorders.Identification;
import com.backbase.dbs.integration.paymentorder.rest.spec.v2.paymentorders.PaymentOrdersPostRequestBody;
import com.backbase.dbs.integration.paymentorder.rest.spec.v2.paymentorders.PaymentOrdersPostResponseBody;
import com.backbase.pandp.arrangement.query.listener.client.v2.arrangements.GetArrangementsQueryParameters;
import com.backbase.pandp.arrangement.query.listener.client.v2.arrangements.PandpArrangementQueryArrangementsClient;
import com.backbase.pandp.arrangement.query.rest.spec.v2.arrangements.ArrangementsPageQ;
import com.backbase.training.dto.fx.MakeTransferRequestBodyFX;
import com.backbase.training.dto.fx.PaymentResponseFX;
import com.backbase.training.utils.Configurator;
import com.backbase.training.utils.Helper;
import com.backbase.training.utils.RequestDataSupplier;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import javax.annotation.PostConstruct;
import java.util.Arrays;

@Slf4j
@Service
public class PaymentService implements PaymentOrdersListener {

    private RestTemplate template;

    private final Configurator config;
    private final PandpArrangementQueryArrangementsClient queryArrangementsClient;
    private final RequestDataSupplier requestDataSupplier;

    @Autowired
    public PaymentService(
            PandpArrangementQueryArrangementsClient queryArrangementsClient,
            RequestDataSupplier requestDataSupplier,
            Configurator config) {
        this.queryArrangementsClient = queryArrangementsClient;
        this.requestDataSupplier = requestDataSupplier;
        this.config = config;
    }

    @PostConstruct
    private void init() {
        template = config.getRestTemplate();
    }

    @Override
    public RequestProxyWrapper<PaymentOrdersPostResponseBody> postPaymentOrders(RequestProxyWrapper<PaymentOrdersPostRequestBody> requestProxyWrapper, Exchange exchange) throws BadRequestException, InternalServerErrorException {

        PaymentOrdersPostRequestBody data = requestProxyWrapper.getRequest().getData();

        HttpHeaders headers = requestDataSupplier.setHeadersFxRest();
        String body = Helper.Gson.toJson(buildTransferRequestBody(data));
        HttpEntity<String> entity = new HttpEntity<>(body, headers);

        ResponseEntity<PaymentResponseFX> response = template.exchange(requestDataSupplier.getCreateTransactionUrl(), HttpMethod.POST, entity, PaymentResponseFX.class);

        log.info("===> Response from FX {}", response.getBody());

        PaymentOrdersPostResponseBody responseBody = new PaymentOrdersPostResponseBody();
        responseBody.setStatus(PaymentOrdersPostResponseBody.Status.PROCESSED);
        responseBody.setBankReferenceId(response.getBody().getData().get(0).getTrnId());
        responseBody.setBankStatus("PROCESSED");

        return wrapResponse(requestProxyWrapper, responseBody);
    }

    private MakeTransferRequestBodyFX buildTransferRequestBody(PaymentOrdersPostRequestBody data) {
        MakeTransferRequestBodyFX.Entries from = new MakeTransferRequestBodyFX.Entries();

        String comment = (data.getTransferTransactionInformation().getRemittanceInformation() == null) ? "Transfer between accounts" : data.getTransferTransactionInformation().getRemittanceInformation().getContent();
        from.setAcctGroup(requestDataSupplier.getAccountGroup());
        from.setAcctNbr(data.getOriginatorAccount().getExternalArrangementId());
        double trnAmt = data.getTransferTransactionInformation().getInstructedAmount().getAmount().doubleValue();
        from.setTrnAmt(trnAmt);
        from.setDr(true);
        from.setComment(comment.isEmpty() ? "Transfer between accounts" : comment);

        MakeTransferRequestBodyFX.Entries to = new MakeTransferRequestBodyFX.Entries();
        String savingAccExtID = "";

        Identification identification = data.getTransferTransactionInformation().getCounterpartyAccount().getIdentification();
        String identificationString = identification.getIdentification();

        if (Identification.SchemeName.IBAN.equals(identification.getSchemeName())) {
            log.info("===> Change scheme to BBAN at cxp-manager console");
        } else {
            ArrangementsPageQ body =
                    queryArrangementsClient.getArrangements(
                            new GetArrangementsQueryParameters().withExternalArrangementIds(new String[]{identificationString})).getBody();

            if (body != null) {
                savingAccExtID = body.getArrangements().get(0).getExternalArrangementId();
            } else {
                throw new NotFoundException("===> Can't find arrangement with this BBAN " + identificationString);
            }
        }
        // TODO: account group should be constant (always 1)
        to.setAcctGroup(requestDataSupplier.getAccountGroup());
        to.setAcctNbr(savingAccExtID);
        to.setTrnAmt(trnAmt);
        to.setDr(false);
        to.setComment(comment.isEmpty() ? "Transfer between accounts" : comment);

        MakeTransferRequestBodyFX body = new MakeTransferRequestBodyFX();
        body.setMode(2);
        body.setEntries(Arrays.asList(from, to));
        return body;
    }

    private <T> RequestProxyWrapper<T> wrapResponse(RequestProxyWrapper request, T serviceResponse) {
        RequestProxyWrapper<T> response = new RequestProxyWrapper<>();
        ApiUtils.copyRequestProxyWrapperValues(request, response);
        response.setRequest(new InternalRequest(serviceResponse, request.getRequest().getInternalRequestContext()));
        return response;
    }

    @Override
    public RequestProxyWrapper<CancelResponse> postCancelPaymentOrder(
            RequestProxyWrapper<Void> requestProxyWrapper, Exchange exchange, String s)
            throws BadRequestException, InternalServerErrorException, NotFoundException {
        return null;
    }
}
