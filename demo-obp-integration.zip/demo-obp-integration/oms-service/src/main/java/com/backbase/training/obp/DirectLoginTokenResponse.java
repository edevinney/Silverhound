package com.backbase.training.obp;

public class DirectLoginTokenResponse {
    protected String token;

    public DirectLoginTokenResponse(String token) {
        this.token = token;
    }
}