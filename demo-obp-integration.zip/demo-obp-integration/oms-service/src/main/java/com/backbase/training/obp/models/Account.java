package com.backbase.training.obp.models;

import java.util.List;

@lombok.Data
public class Account {
    private String id;
    private String label;
    private String bank_id;
    private String account_type;
    private List<AccountRouting> account_routings;
}