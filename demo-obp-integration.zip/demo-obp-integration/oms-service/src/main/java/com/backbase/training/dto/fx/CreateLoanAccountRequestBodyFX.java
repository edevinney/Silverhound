package com.backbase.training.dto.fx;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@NoArgsConstructor
@Data
@Builder
@AllArgsConstructor
public class CreateLoanAccountRequestBodyFX {

    private CustomerBean customer;
    private List<NewAccountsBean> newAccounts;

    @NoArgsConstructor
    @Data
    @Builder
    @AllArgsConstructor
    public static class CustomerBean {
        private String customerId;
        private String customerGroup;
    }

    @NoArgsConstructor
    @Data
    @Builder
    @AllArgsConstructor
    public static class NewAccountsBean {
        private AcctBean Acct;
        private AcctPartyRelBean acctPartyRel;

        @NoArgsConstructor
        @Data
        @Builder
        @AllArgsConstructor
        public static class AcctBean {
            private String prodName;
            private AcctBkBean acct_bk;
            private List<PosnLnDtlBean> posn_lnDtl;

            @NoArgsConstructor
            @Data
            @Builder
            @AllArgsConstructor
            public static class AcctBkBean {
                private String acctNbr;
                private String name;
                private int acctGroup;
                private String acctTitle;
                private boolean isBrokered;
                private String tmZoneCode;
                private List<TcDtlBean> tcDtl;
                private String acctType;

                @NoArgsConstructor
                @Data
                @Builder
                @AllArgsConstructor
                public static class TcDtlBean {
                    private String version;
                    private String signDt;
                    private SignedByBean signedBy;

                    @NoArgsConstructor
                    @Data
                    @Builder
                    @AllArgsConstructor
                    public static class SignedByBean {
                        private String name;
                    }
                }
            }

            @NoArgsConstructor
            @Data
            @Builder
            @AllArgsConstructor
            public static class PosnLnDtlBean {
                private PosnLnBean posn_ln;

                @NoArgsConstructor
                @Data
                @Builder
                @AllArgsConstructor
                public static class PosnLnBean {
                    private String tmZoneCode;
                    private String ccyCode;
                    private int glCat;
                    private AcctgSegBean acctgSeg;
                    private double crLimit;
                    private PosnLnRepayBean posn_lnRepay;

                    @NoArgsConstructor
                    @Data
                    @Builder
                    @AllArgsConstructor
                    public static class AcctgSegBean {
                        private String deptId;
                        private String vertical;
                    }

                    @NoArgsConstructor
                    @Data
                    @Builder
                    @AllArgsConstructor
                    public static class PosnLnRepayBean {
                        private String pmtOffset;
                        private String amortizeDur;
                        private String pmtDur;
                    }
                }
            }
        }

        @NoArgsConstructor
        @Data
        @Builder
        @AllArgsConstructor
        public static class AcctPartyRelBean {
            private String relType;
            private String partyRelDesc;
        }
    }
}
