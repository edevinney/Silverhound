package com.backbase.training.multicore;

public interface IBankCoreUserAccount{
    String getUserName();
    String getAuthenticationToken();
}