package com.backbase.training.utils;

import com.backbase.pandp.arrangement.query.listener.client.v2.products.PandpArrangementQueryProductsClient;
import com.backbase.pandp.arrangement.query.rest.spec.v2.products.ProductItemQ;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;

@Component
public class ProductSupplier {

    public String getProductId(PandpArrangementQueryProductsClient pandpArrangementQueryProductsClient, String externalProductKindId) {
        ResponseEntity<? extends List<ProductItemQ>> products = pandpArrangementQueryProductsClient.getProducts();
        String productId = "";
        for (ProductItemQ productItemQ : Objects.requireNonNull(products.getBody())) {
            if (productItemQ.getExternalProductKindId().equals(externalProductKindId)) {
                productId = productItemQ.getId();
                break;
            }
        }
        return productId;
    }

}
