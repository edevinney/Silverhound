package com.backbase.training.obp;

import com.backbase.training.multicore.IBankCoreAccountInformation;
import com.backbase.training.multicore.IBankCoreApiService;
import com.backbase.training.multicore.IBankCoreUserAccount;
import com.backbase.training.obp.models.Account;
import com.backbase.training.obp.models.AccountDetailsResponse;
import com.backbase.training.obp.models.AccountRouting;
import com.backbase.training.obp.models.AllAccountsResponse;
import com.backbase.training.utils.Helper;
import org.apache.http.util.TextUtils;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;

import javax.xml.soap.Text;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class OBPApiService implements IBankCoreApiService {

    private AccountDetailsResponse GetAccountDetails(String directLoginToken, String bankId, String accountId) {
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        headers.set("Authorization", "DirectLogin token=" + directLoginToken);
        HttpEntity request = new HttpEntity(headers);
        ResponseEntity<String> response = restTemplate.exchange(
                "https://apisandbox.openbankproject.com/obp/v3.1.0/my/banks/" + bankId + "/accounts/" + accountId + "/account",
                HttpMethod.GET,
                request,
                String.class);

        if (response.getStatusCode() == HttpStatus.OK) {
            AccountDetailsResponse detailsResponse = Helper.Gson.fromJson(response.getBody(), AccountDetailsResponse.class);
            return detailsResponse;
        } else {
            System.out.println("Request Failed");
            System.out.println(response.getStatusCode());
            return null;
        }
    }

    private AllAccountsResponse GetAllAccountsForUser(String directLoginToken) {
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        headers.set("Authorization", "DirectLogin token=" + directLoginToken);
        HttpEntity request = new HttpEntity(headers);
        ResponseEntity<String> response = restTemplate.exchange(
                "https://apisandbox.openbankproject.com/obp/v3.1.0/my/accounts",
                HttpMethod.GET,
                request,
                String.class);

        if (response.getStatusCode() == HttpStatus.OK) {
            AllAccountsResponse allAccounts = Helper.Gson.fromJson(response.getBody(), AllAccountsResponse.class);
            return allAccounts;
        } else {
            System.out.println("Request Failed");
            System.out.println(response.getStatusCode());
            return null;
        }
    }


    @Override
    public List<IBankCoreAccountInformation> GetUserAccounts(IBankCoreUserAccount user) {
        List<IBankCoreAccountInformation> genericAccounts = new ArrayList<IBankCoreAccountInformation>();
        String directLoginToken = user.getAuthenticationToken();
        if (directLoginToken == null) {
            System.out.println("OBP user " + user.getUserName() + " cannot be used");
            return null;
        }
        AllAccountsResponse accounts = this.GetAllAccountsForUser(directLoginToken);
        if (accounts != null && accounts.getAccounts() != null) {
            accounts.getAccounts().forEach(c -> {
                if (!TextUtils.isEmpty(c.getLabel()) && !TextUtils.isBlank(c.getLabel())
                        && c.getAccount_routings() != null && c.getAccount_routings().size() > 0) {

                    AccountDetailsResponse details = this.GetAccountDetails(directLoginToken, c.getBank_id(), c.getId());
                    if (details != null) {
                        OBPAccountInformation generic = new OBPAccountInformation();
                        generic.setName(c.getLabel());
                        generic.setId(c.getId());
                        generic.setBranchCode(c.getBank_id());
                        generic.setCurrency("USD");
                        Float balance = Float.valueOf(details.getBalance().getAmount());
                        generic.setBalance(balance);
                        generic.setAccountNumber(details.getNumber());
                        AccountRouting ibanRouting = c.getAccount_routings().get(0);
                        generic.setIBAN(ibanRouting.getAddress());
                        genericAccounts.add(generic);
                    }
                }
            });
        }
        if (genericAccounts.size()>1){
            System.out.println("OBP Found " + genericAccounts.size() + " accounts for user " + user.getUserName());
        }
        return genericAccounts;
    }
}
