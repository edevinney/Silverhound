package com.backbase.training.services;

import com.backbase.pandp.arrangement.listener.client.v2.arrangement.PandpArrangementArrangementsClient;
import com.backbase.pandp.arrangement.query.listener.client.v2.arrangements.PandpArrangementQueryArrangementsClient;
import com.backbase.pandp.arrangement.query.rest.spec.v2.arrangements.ArrangementItemQ;
import com.backbase.pandp.arrangement.query.rest.spec.v2.arrangements.ArrangementsPageQ;
import com.backbase.pandp.arrangement.rest.spec.v2.arrangement.ArrangementsPutRequestBody;
import com.backbase.training.dto.fx.BalanceRespLoanFX;
import com.backbase.training.dto.fx.BalanceRespSavingFX;
import com.backbase.training.utils.Configurator;
import com.backbase.training.utils.Constants;
import com.backbase.training.utils.RequestDataSupplier;
import lombok.extern.slf4j.Slf4j;
import lombok.var;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import javax.annotation.PostConstruct;
import java.math.BigDecimal;
import java.math.MathContext;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
@Service
public class BalanceService {
    private RestTemplate template;
    private ConcurrentHashMap<String, String> ignoredArrangements = new ConcurrentHashMap<>();

    private final Configurator config;
    private final PandpArrangementQueryArrangementsClient queryArrangementsClient;
    private final PandpArrangementArrangementsClient arrangementsClient;
    private final RequestDataSupplier requestDataSupplier;

    @Autowired
    public BalanceService(
            PandpArrangementQueryArrangementsClient queryArrangementsClient,
            PandpArrangementArrangementsClient arrangementsClient,
            RequestDataSupplier requestDataSupplier, Configurator config) {
        this.queryArrangementsClient = queryArrangementsClient;
        this.arrangementsClient = arrangementsClient;
        this.requestDataSupplier = requestDataSupplier;
        this.config = config;
    }

    @PostConstruct
    private void init() {
        template = config.getRestTemplate();
    }

    public void updateAllBalances() {
        ArrangementsPageQ arrangementsBody = queryArrangementsClient.getArrangements().getBody();

        List<ArrangementItemQ> arrangements;
        if (arrangementsBody != null && (arrangements = arrangementsBody.getArrangements()) != null) {
            updateBalancesFromArrangementListWithCondition(arrangements, true);
        }
    }

    @Deprecated
    public void updateBalancesAfterTransfer(List<ArrangementItemQ> arrangements) {
        updateBalancesFromArrangementListWithCondition(arrangements, false);
    }

    private void updateBalancesFromArrangementListWithCondition(List<ArrangementItemQ> arrangements, boolean isUpdateAllBalances) {
        for (ArrangementItemQ arrangementItemQ : arrangements) {

            if (isUpdateAllBalances) {
                if (!ignoredArrangements.containsKey(arrangementItemQ.getExternalArrangementId())) {
                    updateBalancesFromArrangementList(arrangementItemQ);
                }
            } else {
                updateBalancesFromArrangementList(arrangementItemQ);
            }
        }
    }

    private void updateBalancesFromArrangementList(ArrangementItemQ arrangementItemQ) {
        String externalArrangementId = arrangementItemQ.getExternalArrangementId();
        if (externalArrangementId.startsWith(Constants.CORE_PREFIX_OBP)) {
            log.warn("Skipping balance sync OpenBank ACCOUNT " + externalArrangementId);
            return;
        }
        try {
            HttpHeaders headers = requestDataSupplier.setHeadersFxRest();
            String url = requestDataSupplier.getBalanceUrl().concat(arrangementItemQ.getExternalArrangementId());
            HttpEntity<String> entity = new HttpEntity<>(headers);

            double availBal = 0D;
            if (arrangementItemQ.getAlias() != null && arrangementItemQ.getAlias().equals("SA")) {
                ResponseEntity<BalanceRespSavingFX> exchange = template.exchange(url, HttpMethod.GET, entity, BalanceRespSavingFX.class);
                BalanceRespSavingFX body = exchange.getBody();
                List<BalanceRespSavingFX.PosnDepDtl> posn_depDtl;
                if (body != null && (posn_depDtl = body.getPosn_depDtl()) != null && !posn_depDtl.isEmpty()) {
                    availBal = posn_depDtl.get(0) == null ? 0D : body.getPosn_depDtl().get(0).getPosn_dep().getAvailBal();
                }
            } else {
                ResponseEntity<BalanceRespLoanFX> exchange = template.exchange(url, HttpMethod.GET, entity, BalanceRespLoanFX.class);
                BalanceRespLoanFX body = exchange.getBody();
                List<BalanceRespLoanFX.PosnLnDtlBean> posn_lnDtl;
                if (body != null && (posn_lnDtl = body.getPosn_lnDtl()) != null && !posn_lnDtl.isEmpty()) {
                    availBal = posn_lnDtl.get(0) == null ? 0D : posn_lnDtl.get(0).getPosn_ln().getBal();
                }
            }
            BigDecimal newBalance = new BigDecimal(availBal, MathContext.DECIMAL64);

            if (newBalance.compareTo(arrangementItemQ.getAvailableBalance()) == 0) {
                log.warn("Skipping balance sync for " + arrangementItemQ.getExternalArrangementId() + ", reason: same balance " + newBalance.toString());
            } else {
                mapArrangement(arrangementItemQ, newBalance);
            }
        } catch (Exception e) {
            log.error("Error when updating a balance for {}. {}", arrangementItemQ.getExternalArrangementId(), e);
        }
    }

    private void mapArrangement(ArrangementItemQ arrangementItemQ, BigDecimal newBalance) {
        BigDecimal currentBalance = arrangementItemQ.getAvailableBalance();
        ArrangementsPutRequestBody arrangement = new ArrangementsPutRequestBody();
        arrangement.setId(arrangementItemQ.getId());
        arrangement.setBookedBalance(newBalance);
        arrangement.setAvailableBalance(newBalance);
        arrangement.setProductId(arrangementItemQ.getProduct().getId());
        arrangement.setCurrency("USD");
        arrangement.setAlias(arrangementItemQ.getAlias());
        arrangement.setName(arrangementItemQ.getName());
        arrangement.setBankAlias(arrangementItemQ.getBankAlias());
        arrangement.setBBAN(arrangementItemQ.getBBAN());
        String existingIBAN = arrangementItemQ.getIBAN();
        if (existingIBAN != null && !existingIBAN.isEmpty())
            arrangement.setIBAN(existingIBAN);
        arrangement.setExternalTransferAllowed(arrangementItemQ.getExternalTransferAllowed());
        arrangement.setUrgentTransferAllowed(arrangementItemQ.getUrgentTransferAllowed());
        arrangement.setAccruedInterest(arrangementItemQ.getAccruedInterest());
        arrangement.setPrincipalAmount(arrangementItemQ.getPrincipalAmount());
        arrangement.setCurrentInvestmentValue(arrangementItemQ.getCurrentInvestmentValue());
        arrangement.setCreditAccount(arrangementItemQ.getCreditAccount());
        arrangement.setDebitAccount(arrangementItemQ.getDebitAccount());
        log.info("===> Balance for this arrangement " + arrangementItemQ.getExternalArrangementId() + " was updated from " + currentBalance.toString() + " to " + newBalance);
        var response = arrangementsClient.putArrangements(arrangement, arrangementItemQ.getId());
    }

    public ConcurrentHashMap<String, String> getIgnoredArrangements() {
        return ignoredArrangements;
    }
}