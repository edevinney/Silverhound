package com.backbase.training.utils;

import com.backbase.onboarding.rest.spec.v1.onboarding.Address;
import com.backbase.onboarding.rest.spec.v1.onboarding.OnboardingPostRequestBody;
import org.springframework.stereotype.Component;

@Component
public class LogMessageHandler {

    private static final String QUOTE_COMMA_SPACE = "', ";
    /**
     * This method can be used to get information about class fields by adding another conditions to if block
     */
    public String toStringClassInSignature(Object body) {
        if (body instanceof OnboardingPostRequestBody) {
            OnboardingPostRequestBody tempBody = (OnboardingPostRequestBody) body;
            Address address = tempBody.getAddress();

            return tempBody.getClass().getName()
                    .concat("{firstName='").concat(tempBody.getFirstName()).concat(QUOTE_COMMA_SPACE)
                    .concat("lastName='").concat(tempBody.getLastName()).concat(QUOTE_COMMA_SPACE)
                    .concat("dateOfBirth='").concat(tempBody.getDateOfBirth()).concat(QUOTE_COMMA_SPACE)
                    .concat("email='").concat(tempBody.getEmail()).concat(QUOTE_COMMA_SPACE)
                    .concat("address={")
                        .concat("address='").concat(address.getAddress()).concat(QUOTE_COMMA_SPACE)
                        .concat("state='").concat(address.getState()).concat(QUOTE_COMMA_SPACE)
                        .concat("city='").concat(address.getCity()).concat(QUOTE_COMMA_SPACE)
                        .concat("zip='").concat(address.getZip()).concat("'}, ")
                    .concat("statusId='").concat(String.valueOf(tempBody.getStatusId())).concat(QUOTE_COMMA_SPACE)
                    .concat("serviceBranchId='").concat(String.valueOf(tempBody.getServiceBranchId())).concat(QUOTE_COMMA_SPACE)
                    .concat("rankId='").concat(String.valueOf(tempBody.getRankId())).concat(QUOTE_COMMA_SPACE)
                    .concat("payGradeId='").concat(String.valueOf(tempBody.getPayGradeId())).concat("'}");
        } else {
            return "";
        }
    }
}
