package com.backbase.training.obp.models;

@lombok.Data
public class SandboxAccount {
    private String email;
    private String password;
    private String user_name;
}
