package com.backbase.training.dto.queue.trn;

import com.backbase.training.dto.queue.Client;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class TrnCreateMsg {

    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("event")
    @Expose
    private String event;
    @SerializedName("client")
    @Expose
    private Client client;
    @SerializedName("msg")
    @Expose
    private Msg msg;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getEvent() {
        return event;
    }

    public void setEvent(String event) {
        this.event = event;
    }

    public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        this.client = client;
    }

    public Msg getMsg() {
        return msg;
    }

    public void setMsg(Msg msg) {
        this.msg = msg;
    }

}