package com.backbase.training.dto.fx;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@NoArgsConstructor
@Data
@Builder
@AllArgsConstructor
public class GetPartyGroupListFromFX {

    private int limit;
    private int page;
    private int totalCount;
    private int numPages;
    private List<DataBean> data;

    @NoArgsConstructor
    @Data
    @Builder
    @AllArgsConstructor
    public static class DataBean {
        private String groupId;
        private String groupOwnerId;
        private int groupType;
        private String name;
        private String _cLog;
        private String _cDtm;
        private int _vn;
        private int _schVn;
        private List<MembersBean> members;

        @NoArgsConstructor
        @Data
        @Builder
        @AllArgsConstructor
        public static class MembersBean {
            private String groupId;
            private String memberId;
            private String partyId;
            private String partyTitle;
            private String _cLog;
            private String _cDtm;
            private int _vn;
            private int _schVn;
        }
    }
}
