package com.backbase.training.routes;

import com.backbase.loan.rest.spec.v1.loan.LoanPostRequestBody;
import com.backbase.loan.rest.spec.v1.loan.LoanPostResponseBody;
import com.backbase.pandp.arrangement.listener.client.v2.arrangement.PandpArrangementArrangementsClient;
import com.backbase.pandp.arrangement.listener.client.v2.products.PandpArrangementProductsClient;
import com.backbase.pandp.arrangement.query.listener.client.v2.arrangements.PandpArrangementQueryArrangementsClient;
import com.backbase.pandp.arrangement.query.listener.client.v2.products.PandpArrangementQueryProductsClient;
import com.backbase.pandp.arrangement.query.rest.spec.v2.arrangements.ArrangementItemQ;
import com.backbase.pandp.arrangement.query.rest.spec.v2.products.ProductItemQ;
import com.backbase.pandp.arrangement.rest.spec.v2.arrangement.ArrangementsPostRequestBody;
import com.backbase.pandp.arrangement.rest.spec.v2.arrangement.ArrangementsPostResponseBody;
import com.backbase.pandp.arrangement.rest.spec.v2.products.ProductsPostRequestBody;
import com.backbase.presentation.accessgroup.listener.client.v2.accessgroups.datagroups.GetDataGroupsQueryParameters;
import com.backbase.presentation.accessgroup.listener.client.v2.accessgroups.datagroups.PresentationAccessgroupDataGroupsClient;
import com.backbase.presentation.accessgroup.listener.client.v2.accessgroups.functiongroups.GetFunctionGroupsQueryParameters;
import com.backbase.presentation.accessgroup.listener.client.v2.accessgroups.functiongroups.PresentationAccessgroupFunctionGroupsClient;
import com.backbase.presentation.accessgroup.listener.client.v2.accessgroups.users.PresentationAccessgroupUsersClient;
import com.backbase.presentation.accessgroup.rest.spec.v2.accessgroups.PresentationIdentifier;
import com.backbase.presentation.accessgroup.rest.spec.v2.accessgroups.datagroups.DataGroupByIdPutRequestBody;
import com.backbase.presentation.accessgroup.rest.spec.v2.accessgroups.datagroups.DataGroupsGetResponseBody;
import com.backbase.presentation.accessgroup.rest.spec.v2.accessgroups.functiongroups.FunctionGroupByIdPutRequestBody;
import com.backbase.presentation.accessgroup.rest.spec.v2.accessgroups.functiongroups.FunctionGroupsGetResponseBody;
import com.backbase.presentation.accessgroup.rest.spec.v2.accessgroups.users.PresentationAssignUserPermissions;
import com.backbase.presentation.accessgroup.rest.spec.v2.accessgroups.users.PresentationFunctionGroupDataGroup;
import com.backbase.presentation.legalentity.listener.client.v2.legalentities.PresentationLegalentityLegalEntitiesClient;
import com.backbase.presentation.legalentity.rest.spec.v2.legalentities.LegalEntityByIdGetResponseBody;
import com.backbase.presentation.legalentity.rest.spec.v2.legalentities.MasterServiceAgreementGetResponseBody;
import com.backbase.presentation.user.listener.client.v2.users.PresentationUserUsersClient;
import com.backbase.presentation.user.rest.spec.v2.users.UserByExternalIdGetResponseBody;
import com.backbase.training.dto.bb.SetExternalIdToUserServiceAgreementRequestBodyBB;
import com.backbase.training.dto.fx.CreateLoanAccountRequestBodyFX;
import com.backbase.training.dto.fx.CreateLoanAccountResponseBodyFX;
import com.backbase.training.dto.fx.GetPartyGroupListFromFX;
import com.backbase.training.dto.fx.MakeTransferRequestBodyFX;
import com.backbase.training.services.BalanceService;
import com.backbase.training.utils.*;
import groovy.util.logging.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.http.common.HttpOperationFailedException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import javax.ws.rs.HttpMethod;
import java.io.IOException;
import java.math.BigDecimal;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.text.SimpleDateFormat;
import java.util.*;

import static com.backbase.training.utils.Constants.DIRECT_POST;
import static com.backbase.training.utils.Constants.PRODUCER_COMPONENT;

@Slf4j
@Component
public class LoanRoute extends RouteBuilder {

    private String externalServiceAgreementId = "";
    private String memberGroupIdFX;
    private String userExternalId;
    private BigDecimal creditLimit;
    private BigDecimal creditTerm;
    private String arrangementExternalID_accNmbr;
    private String loanTypeId = "";
    private String arrangementID;
    private String acctNbr;
    private RestTemplate template;


    private CreateLoanAccountRequestBodyFX createLoanAccountRequestBodyFX;
    private CreateLoanAccountResponseBodyFX createLoanAccountResponseBodyFX;
    private LoanPostRequestBody loanPostRequestBody = new LoanPostRequestBody();
    private ResponseEntity<LegalEntityByIdGetResponseBody> legalEntity;
    private UserByExternalIdGetResponseBody userByExternalIdGetResponseBody;
    private GetPartyGroupListFromFX getPartyGroupListFromFX;
    private ResponseEntity<ArrangementsPostResponseBody> arrangementsResponseBody;
    private ResponseEntity<MasterServiceAgreementGetResponseBody> masterServiceAgreement;

    private ResponseEntity<? extends List<FunctionGroupsGetResponseBody>> functionGroups;
    private ResponseEntity<? extends List<DataGroupsGetResponseBody>> dataGroups;

    private final Configurator config;
    private final AccountNumberGenerator accountNumberGenerator;
    private final PresentationLegalentityLegalEntitiesClient legalEntityClient;
    private final PresentationUserUsersClient usersClient;
    private final PandpArrangementArrangementsClient arrangementsClient;
    private final PresentationAccessgroupUsersClient accessGroupUsersClient;
    private final PresentationAccessgroupFunctionGroupsClient functionGroupsClient;
    private final PandpArrangementQueryProductsClient productsClient;
    private final PandpArrangementProductsClient pandpArrangementProductsClient;
    private final PresentationAccessgroupDataGroupsClient dataGroupsClient;
    private final PandpArrangementQueryArrangementsClient queryArrangementsClient;
    private final ProductSupplier productSupplier;
    private final RandomNumbersGenerator randomNumbersGenerator;
    private final PermissionSupplier permissionSupplier;
    private final BalanceService balanceService;
    private final RequestDataSupplier requestDataSupplier;

    @Autowired
    public LoanRoute(
            PresentationLegalentityLegalEntitiesClient legalEntityClient,
            PresentationUserUsersClient usersClient,
            PandpArrangementArrangementsClient arrangementsClient,
            PresentationAccessgroupUsersClient accessGroupUsersClient,
            PresentationAccessgroupFunctionGroupsClient functionGroupsClient,
            PandpArrangementQueryProductsClient productsClient,
            PandpArrangementProductsClient pandpArrangementProductsClient,
            PresentationAccessgroupDataGroupsClient dataGroupsClient,
            PandpArrangementQueryArrangementsClient queryArrangementsClient,
            ProductSupplier productSupplier,
            RandomNumbersGenerator randomNumbersGenerator,
            PermissionSupplier permissionSupplier,
            BalanceService balanceService,
            RequestDataSupplier requestDataSupplier,
            Configurator config,
            AccountNumberGenerator accountNumberGenerator) {
        this.legalEntityClient = legalEntityClient;
        this.usersClient = usersClient;
        this.arrangementsClient = arrangementsClient;
        this.accessGroupUsersClient = accessGroupUsersClient;
        this.functionGroupsClient = functionGroupsClient;
        this.dataGroupsClient = dataGroupsClient;
        this.productsClient = productsClient;
        this.pandpArrangementProductsClient = pandpArrangementProductsClient;
        this.queryArrangementsClient = queryArrangementsClient;
        this.productSupplier = productSupplier;
        this.randomNumbersGenerator = randomNumbersGenerator;
        this.permissionSupplier = permissionSupplier;
        this.balanceService = balanceService;
        this.requestDataSupplier = requestDataSupplier;
        this.config = config;
        this.accountNumberGenerator = accountNumberGenerator;
    }

    @Override
    public void configure() {
        restConfiguration().producerComponent(PRODUCER_COMPONENT);
        if (config.useProxyForFinxact) {
            getContext().setGlobalOptions(new HashMap<String, String>() {{
                put("http.proxyHost", config.finxactProxyHost);
                put("http.proxyPort", config.finxactProxyPort);
            }});

            SimpleClientHttpRequestFactory clientHttpReq = new SimpleClientHttpRequestFactory();
            Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(config.finxactProxyHost, config.finxactProxyPortInt));
            clientHttpReq.setProxy(proxy);
            template = new RestTemplate(clientHttpReq);
        } else {
            template = new RestTemplate();
        }

        onException(HttpOperationFailedException.class)
                .process(exchange -> {
                    final HttpOperationFailedException e = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, HttpOperationFailedException.class);
                    final String responseBody = e.getResponseBody();
                    log.info(responseBody);
                });


        from(DIRECT_POST)
                .id("get_user_details_by_id_from_fx")
                .process(exchange -> {
                    loanPostRequestBody = exchange.getIn().getBody(LoanPostRequestBody.class);
                    creditLimit = loanPostRequestBody.getAmount();
                    creditTerm = loanPostRequestBody.getTerm();
                    loanTypeId = loanPostRequestBody.getLoanTypeId();
                    userExternalId = loanPostRequestBody.getUserExternalId();
                    userByExternalIdGetResponseBody = usersClient.getUserByExternalId(userExternalId).getBody();
                    exchange.getOut().setBody(null);
                    requestDataSupplier.setHeadersFxRoute(exchange, HttpMethod.GET);
                    log.info("===> calling this url " + requestDataSupplier.getPartyGroupUrl());
                })
                .to("log:INFO?showBody=true&showHeaders=true")
                .to(requestDataSupplier.getPartyGroupUrl())
                .process(exchange -> {
                    getPartyGroupListFromFX = Helper.Gson.fromJson(exchange.getIn().getBody(String.class), GetPartyGroupListFromFX.class);
                    legalEntity = legalEntityClient.getLegalEntityById(userByExternalIdGetResponseBody.getLegalEntityId());

                    List<GetPartyGroupListFromFX.DataBean.MembersBean> membersBeanList = getPartyGroupListFromFX.getData().get(0).getMembers();
                    // TODO: use another API to get user account directly without walking over records
                    for (GetPartyGroupListFromFX.DataBean.MembersBean membersBean : membersBeanList) {

                        if (membersBean.getMemberId().equals(Objects.requireNonNull(legalEntity.getBody(), "The body must be not null").getExternalId())) {
                            memberGroupIdFX = membersBean.getGroupId();
                        }
                    }
                })
                .to("direct:create_loan_account_in_fx");


        from("direct:create_loan_account_in_fx")
                .id("create_loan_account_in_fx")
                .process(exchange -> {
                    requestDataSupplier.setHeadersFxRoute(exchange, HttpMethod.POST);
                    createLoanAccountRequestBodyFX = buildRequestBody(Objects.requireNonNull(legalEntity.getBody(), "The body must be not null").getExternalId(), memberGroupIdFX);
                    exchange.getOut().setBody(Helper.Gson.toJson(createLoanAccountRequestBodyFX));
                    log.info("===> calling this url " + requestDataSupplier.getAccountUrl());
                })
                .to("log:INFO?showBody=true&showHeaders=true")
                .to(requestDataSupplier.getAccountUrl())
                .process(exchange -> {
                    String json = exchange.getIn().getBody(String.class);
                    createLoanAccountResponseBodyFX = Helper.Gson.fromJson(json, CreateLoanAccountResponseBodyFX.class);
                    acctNbr = createLoanAccountResponseBodyFX.getCreatedAccounts().get(0).getAcct_bk().getAcctNbr();
                    balanceService.getIgnoredArrangements().put(acctNbr, acctNbr);
                    log.info(json);
                })
                .to("direct:create_loan_product_bb");


        from("direct:create_loan_product_bb")
                .id("create_loan_product_bb")
                .process(exchange -> {

                    ResponseEntity<? extends List<ProductItemQ>> products = productsClient.getProducts();
                    String acctNumber = createLoanAccountResponseBodyFX.getAcctPartyRels().get(0).getAcctNbr();

                    if (products.getBody() != null) {
                        List<ProductItemQ> body = products.getBody();

                        boolean onceCreated = false;

                        if (body.isEmpty()) {
                            createProduct(acctNumber);
                            onceCreated = true;
                        }
                        for (ProductItemQ productItemQ : body) {
                            if (productItemQ.getExternalProductKindId().equals("kind5")) {
                                onceCreated = true;
                                break;
                            }
                        }
                        if (!onceCreated) {
                            createProduct(acctNumber);
                        }
                    }
                })
                .to("direct:create_loan_arrangement_bb");


        from("direct:create_loan_arrangement_bb")
                .id("create_loan_arrangement_bb")
                .process(exchange -> {
                    ArrangementsPostRequestBody body = buildArrangementsPostRequestBody(createLoanAccountResponseBodyFX);
                    arrangementsResponseBody = arrangementsClient.postArrangements(body);
                })
                .to("direct:get_loan_service_agreement_details_bb");


        from("direct:get_loan_service_agreement_details_bb")
                .id("get_loan_service_agreement_details_bb")
                .process(exchange -> masterServiceAgreement = legalEntityClient.getMasterServiceAgreementByExternalLegalEntity(Objects.requireNonNull(legalEntity.getBody(), "The body must be not null").getExternalId()))
                .to("direct:set_loan_master_service_agreement_bb");


        from("direct:set_loan_master_service_agreement_bb")
                .id("set_loan_master_service_agreement_bb")
                .process(exchange -> {
                    exchange.getOut().setHeader(Exchange.HTTP_METHOD, HttpMethod.PUT);
                    exchange.getOut().setHeader(Exchange.CONTENT_TYPE, "application/json");
                    exchange.getOut().setHeader("externalId", Objects.requireNonNull(masterServiceAgreement.getBody(), "The body must be not null").getId());
                    externalServiceAgreementId = "externalId_" + randomNumbersGenerator.getTenDigitRandomNumberFromUUID();
                    SetExternalIdToUserServiceAgreementRequestBodyBB body = SetExternalIdToUserServiceAgreementRequestBodyBB.builder().externalId(externalServiceAgreementId).build();
                    exchange.getOut().setBody(Helper.Gson.toJson(body));
                    log.info("===> calling this url " + "http://localhost:8086/accessgroup-integration-service/v2/accessgroups/serviceagreements/" + masterServiceAgreement.getBody().getId());
                })
                .to("log:INFO?showBody=true&showHeaders=true")
                .routingSlip(simple("http://localhost:8086/accessgroup-integration-service/v2/accessgroups/serviceagreements/${header.externalId}"))
                .to("direct:create_loan_data_group_for_msa_bb");


        from("direct:create_loan_data_group_for_msa_bb")
                .id("create_loan_data_group_for_msa_bb")
                .process(exchange -> {
                    GetDataGroupsQueryParameters parameters = getDataGroupQueryParameters();
                    dataGroups = dataGroupsClient.getDataGroups(parameters);

                    findSavingAccID(dataGroups);

                    DataGroupByIdPutRequestBody requestBody = buildDataGroupRequestBody(dataGroups);

                    dataGroupsClient.putDataGroupById(requestBody, Objects.requireNonNull(dataGroups.getBody(), "The body must be not null").get(0).getId());
                })
                .to("direct:update_loan_function_group_for_msa_bb");


        from("direct:update_loan_function_group_for_msa_bb")
                .id("update_loan_function_group_for_msa_bb")
                .process(exchange -> {
                    GetFunctionGroupsQueryParameters parameters = getFunctionGroupQueryParameters();
                    functionGroups = functionGroupsClient.getFunctionGroups(parameters);

                    FunctionGroupByIdPutRequestBody requestBody = buildFunctionGroupByIdPutRequestBody();
                    functionGroupsClient.putFunctionGroupById(requestBody, Objects.requireNonNull(functionGroups.getBody(), "The body must be not null").get(0).getId()
                    );
                })
                .to("direct:assign_loan_permission_bb");


        from("direct:assign_loan_permission_bb")
                .id("assign_loan_permission_bb")
                .process(exchange -> accessGroupUsersClient.putAssignUserPermissions(getPresentationAssignUserPermissions()))
                .to("direct:transfer_to_saving");


        from("direct:transfer_to_saving")
                .process(exchange -> {
                    requestDataSupplier.setHeadersFxRoute(exchange, HttpMethod.POST);
                    MakeTransferRequestBodyFX body = buildTransferRequestBody();
                    exchange.getOut().setBody(Helper.Gson.toJson(body));
                })
                .to("log:INFO?showBody=true&showHeaders=true")
                .to(requestDataSupplier.getCreateTransactionUrl())
                .process(exchange -> {
                    ArrangementItemQ arrangementSavingAccount = queryArrangementsClient.getArrangementById(arrangementID).getBody();
                    ArrangementsPostResponseBody body;
                    ArrangementItemQ arrangementLoanAccount = queryArrangementsClient.getArrangementById((body = arrangementsResponseBody.getBody()) != null ? body.getId() : "").getBody();

                    List<ArrangementItemQ> arrangements = new ArrayList<>();
                    arrangements.add(arrangementSavingAccount);
                    arrangements.add(arrangementLoanAccount);
                    balanceService.updateBalancesAfterTransfer(arrangements);
                })
                .to("direct:response_to_front_loan");


        from("direct:response_to_front_loan")
                .id("response_to_front_loan")
                .process(exchange -> {
                    exchange.getOut().setBody(new LoanPostResponseBody().withStatus("ok"));
                    balanceService.getIgnoredArrangements().remove(acctNbr);
                });
    }

    private void findSavingAccID(ResponseEntity<? extends List<DataGroupsGetResponseBody>> dataGroups) {
        List<DataGroupsGetResponseBody> body = dataGroups.getBody();

        for (String item : Objects.requireNonNull(body, "The body must be not null").get(0).getItems()) {

            if (Objects.requireNonNull(queryArrangementsClient.getArrangementById(item).getBody(), "The body must be not null").getAlias().equals("SA")) {
                arrangementID = item;
                break;
            }
        }
    }

    private MakeTransferRequestBodyFX buildTransferRequestBody() {
        MakeTransferRequestBodyFX.Entries from = new MakeTransferRequestBodyFX.Entries();
        from.setAcctGroup(1);
        from.setAcctNbr(arrangementExternalID_accNmbr);
        from.setTrnAmt(creditLimit.doubleValue());
        from.setDr(true);
        from.setComment("Initial disbursement");

        ResponseEntity<ArrangementItemQ> arrangementById = queryArrangementsClient.getArrangementById(arrangementID);
        String savingAccExtID = Objects.requireNonNull(arrangementById.getBody()).getExternalArrangementId();
        MakeTransferRequestBodyFX.Entries to = new MakeTransferRequestBodyFX.Entries();
        to.setAcctGroup(requestDataSupplier.getAccountGroup());
        to.setAcctNbr(savingAccExtID);
        to.setTrnAmt(creditLimit.doubleValue());
        to.setDr(false);
        to.setComment("Initial disbursement");

        MakeTransferRequestBodyFX body = new MakeTransferRequestBodyFX();
        body.setMode(2);
        body.setEntries(Arrays.asList(from, to));
        return body;
    }

    private GetFunctionGroupsQueryParameters getFunctionGroupQueryParameters() {
        return new GetFunctionGroupsQueryParameters()
                .withServiceAgreementId(Objects.requireNonNull(masterServiceAgreement.getBody(), "The body must be not null").getId());
    }

    private GetDataGroupsQueryParameters getDataGroupQueryParameters() {
        return new GetDataGroupsQueryParameters()
                .withServiceAgreementId(Objects.requireNonNull(masterServiceAgreement.getBody(), "The body must be not null").getId())
                .withType("ARRANGEMENTS");
    }

    private void createProduct(String acctNumber) {
        pandpArrangementProductsClient.postProducts(new ProductsPostRequestBody()
                .withExternalProductId(acctNumber)
                .withExternalProductTypeId(acctNumber)
                .withExternalProductKindId("kind5")
                .withProductKindName("Loan")
                .withProductTypeName("Loan Account"));
    }

    private CreateLoanAccountRequestBodyFX buildRequestBody(String customerId, String customerGroup) throws IOException {
        String pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
        String date = simpleDateFormat.format(new Date());
        arrangementExternalID_accNmbr = accountNumberGenerator.generateNewAccountNumber();

        return CreateLoanAccountRequestBodyFX
                .builder()
                .customer(
                        CreateLoanAccountRequestBodyFX
                                .CustomerBean.builder()
                                .customerId(customerId)
                                .customerGroup(customerGroup)
                                .build()
                )
                .newAccounts(
                        Collections.singletonList(
                                CreateLoanAccountRequestBodyFX
                                        .NewAccountsBean
                                        .builder()
                                        .Acct(
                                                CreateLoanAccountRequestBodyFX
                                                        .NewAccountsBean
                                                        .AcctBean
                                                        .builder()
                                                        .prodName(loanTypeId)
                                                        .acct_bk(
                                                                CreateLoanAccountRequestBodyFX
                                                                        .NewAccountsBean
                                                                        .AcctBean
                                                                        .AcctBkBean
                                                                        .builder()
                                                                        .acctNbr(arrangementExternalID_accNmbr)
                                                                        .name("LOAN ACCOUNT NAME")
                                                                        .acctGroup(requestDataSupplier.getAccountGroup())
                                                                        .acctTitle(userByExternalIdGetResponseBody.getFullName())
                                                                        .isBrokered(false)
                                                                        .tmZoneCode("usnyc")
                                                                        .acctType("Single")
                                                                        .tcDtl(
                                                                                Collections.singletonList(
                                                                                        CreateLoanAccountRequestBodyFX
                                                                                                .NewAccountsBean
                                                                                                .AcctBean
                                                                                                .AcctBkBean
                                                                                                .TcDtlBean
                                                                                                .builder()
                                                                                                .version("1.0.0")
                                                                                                .signDt(date)
                                                                                                .signedBy(
                                                                                                        CreateLoanAccountRequestBodyFX
                                                                                                                .NewAccountsBean
                                                                                                                .AcctBean
                                                                                                                .AcctBkBean
                                                                                                                .TcDtlBean
                                                                                                                .SignedByBean
                                                                                                                .builder()
                                                                                                                .name("LOAN ACCOUNT NAME TC DTL")
                                                                                                                .build()
                                                                                                )
                                                                                                .build()
                                                                                )
                                                                        )
                                                                        .build()
                                                        )
                                                        .posn_lnDtl(
                                                                Collections.singletonList(
                                                                        CreateLoanAccountRequestBodyFX.NewAccountsBean.AcctBean.PosnLnDtlBean
                                                                                .builder()
                                                                                .posn_ln(
                                                                                        CreateLoanAccountRequestBodyFX
                                                                                                .NewAccountsBean
                                                                                                .AcctBean
                                                                                                .PosnLnDtlBean
                                                                                                .PosnLnBean
                                                                                                .builder()
                                                                                                .tmZoneCode("usnyc")
                                                                                                .ccyCode("USD")
                                                                                                .glCat(1)
                                                                                                .acctgSeg(
                                                                                                        CreateLoanAccountRequestBodyFX
                                                                                                                .NewAccountsBean
                                                                                                                .AcctBean
                                                                                                                .PosnLnDtlBean
                                                                                                                .PosnLnBean
                                                                                                                .AcctgSegBean
                                                                                                                .builder()
                                                                                                                .deptId("350")
                                                                                                                .vertical("01")
                                                                                                                .build()
                                                                                                )
                                                                                                .crLimit(creditLimit.intValue())
                                                                                                .posn_lnRepay(
                                                                                                        CreateLoanAccountRequestBodyFX
                                                                                                                .NewAccountsBean
                                                                                                                .AcctBean
                                                                                                                .PosnLnDtlBean
                                                                                                                .PosnLnBean
                                                                                                                .PosnLnRepayBean
                                                                                                                .builder()
                                                                                                                .pmtOffset("1D")
                                                                                                                .amortizeDur(creditTerm + "M")
                                                                                                                .pmtDur(creditTerm + "M")
                                                                                                                .build()
                                                                                                )
                                                                                                .build()
                                                                                )
                                                                                .build()
                                                                )
                                                        )
                                                        .build()
                                        )
                                        .acctPartyRel(
                                                CreateLoanAccountRequestBodyFX
                                                        .NewAccountsBean
                                                        .AcctPartyRelBean
                                                        .builder()
                                                        .relType("1")
                                                        .partyRelDesc("Primary")
                                                        .build()
                                        )
                                        .build()
                        )
                )
                .build();
    }

    private ArrangementsPostRequestBody buildArrangementsPostRequestBody(CreateLoanAccountResponseBodyFX createLoanAccountResponseBodyFX) {
        String productId = productSupplier.getProductId(productsClient, "kind5");
        String newLoanNumber = createLoanAccountResponseBodyFX.getCreatedAccounts().get(0).getAcct_bk().getAcctNbr();
        String BBAN = newLoanNumber;
        double loanCreditLimit = createLoanAccountResponseBodyFX.getCreatedAccounts().get(0).getPosn_lnDtl().get(0).getPosn_ln().getCrLimit();

        return new ArrangementsPostRequestBody()
                .withExternalArrangementId(newLoanNumber)
                .withLegalEntityIds(Collections.singleton(createLoanAccountResponseBodyFX.getAcctPartyRels().get(0).getCustId()))
                .withProductId(productId)
                .withExternalProductId(createLoanAccountResponseBodyFX.getAcctPartyRels().get(0).getAcctNbr())
                .withName("Loan Account")
                .withAlias("LA")
                .withBookedBalance(BigDecimal.valueOf(loanCreditLimit))
                .withAvailableBalance(BigDecimal.valueOf(loanCreditLimit))
                .withCreditLimit(BigDecimal.valueOf(loanCreditLimit))
                .withBBAN(BBAN)
                .withIBAN(null)
                .withCurrency("USD")
                .withDebitAccount(true)
                .withCreditAccount(true)
                .withExternalTransferAllowed(true)
                .withUrgentTransferAllowed(false)
                .withAccruedInterest(BigDecimal.valueOf(0))
                .withPrincipalAmount(BigDecimal.valueOf(loanCreditLimit))
                .withCurrentInvestmentValue(BigDecimal.valueOf(0));
    }

    private DataGroupByIdPutRequestBody buildDataGroupRequestBody(ResponseEntity<? extends List<DataGroupsGetResponseBody>> dataGroups) {

        List<String> items = Objects.requireNonNull(dataGroups.getBody(), "The body must be not null").get(0).getItems();
        items.add(Objects.requireNonNull(arrangementsResponseBody.getBody(), "The body must be not null").getId());

        return new DataGroupByIdPutRequestBody()
                .withDescription(dataGroups.getBody().get(0).getDescription())
                .withId(dataGroups.getBody().get(0).getId())
                .withItems(items)
                .withName(dataGroups.getBody().get(0).getName())
                .withServiceAgreementId(dataGroups.getBody().get(0).getServiceAgreementId())
                .withType("ARRANGEMENTS");
    }

    private FunctionGroupByIdPutRequestBody buildFunctionGroupByIdPutRequestBody() {
        return new FunctionGroupByIdPutRequestBody()
                .withDescription("This profile will control viewing")
                .withLegalEntityId(Objects.requireNonNull(legalEntity.getBody(), "The body must be not null").getId())
                .withName("Viewer_" + externalServiceAgreementId)
                .withPermissions(permissionSupplier.getPermissionList())
                .withServiceAgreementId(Objects.requireNonNull(masterServiceAgreement.getBody(), "The body must be not null").getId());
    }

    private List<PresentationAssignUserPermissions> getPresentationAssignUserPermissions() {
        return Collections.singletonList(
                new PresentationAssignUserPermissions()
                        .withExternalServiceAgreementId(externalServiceAgreementId)
                        .withExternalUserId(userExternalId)
                        .withFunctionGroupDataGroups(
                                Collections.singletonList(
                                        new PresentationFunctionGroupDataGroup()
                                                .withDataGroupIdentifiers(
                                                        Collections.singletonList(
                                                                new PresentationIdentifier()
                                                                        .withIdIdentifier(Objects.requireNonNull(dataGroups.getBody(), "The body must be not null").get(0).getId())
                                                        )
                                                )
                                                .withFunctionGroupIdentifier(
                                                        new PresentationIdentifier()
                                                                .withIdIdentifier(Objects.requireNonNull(functionGroups.getBody(), "The body must be not null").get(0).getId()))
                                )
                        )
        );
    }
}
