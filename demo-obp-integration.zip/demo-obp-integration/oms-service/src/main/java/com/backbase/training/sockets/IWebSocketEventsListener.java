package com.backbase.training.sockets;

public interface IWebSocketEventsListener {
    void onDisconnected(int code, String reason, boolean remote);
    void onConnected();
}
