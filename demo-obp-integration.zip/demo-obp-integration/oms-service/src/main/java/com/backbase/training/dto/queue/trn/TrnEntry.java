
package com.backbase.training.dto.queue.trn;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class TrnEntry {

    @SerializedName("_Id")
    @Expose
    private String id;
    @SerializedName("_Ix")
    @Expose
    private int ix;
    @SerializedName("_cDtm")
    @Expose
    private String cDtm;
    @SerializedName("_cLogRef")
    @Expose
    private String cLogRef;
    @SerializedName("_flags")
    @Expose
    private int flags;
    @SerializedName("_schVn")
    @Expose
    private int schVn;
    @SerializedName("_vn")
    @Expose
    private int vn;
    @SerializedName("acctGroup")
    @Expose
    private int acctGroup;
    @SerializedName("acctNbr")
    @Expose
    private String acctNbr;
    @SerializedName("acctgSeg")
    @Expose
    private AcctgSeg acctgSeg;
    @SerializedName("assetClass")
    @Expose
    private int assetClass;
    @SerializedName("ccyCode")
    @Expose
    private String ccyCode;
    @SerializedName("comment")
    @Expose
    private String comment;
    @SerializedName("glSetCode")
    @Expose
    private String glSetCode;
    @SerializedName("isDr")
    @Expose
    private boolean isDr;
    @SerializedName("posnAcctNbr")
    @Expose
    private String posnAcctNbr;
    @SerializedName("posnId")
    @Expose
    private String posnId;
    @SerializedName("seqNbr")
    @Expose
    private int seqNbr;
    @SerializedName("trnAmt")
    @Expose
    private double trnAmt;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getIx() {
        return ix;
    }

    public void setIx(int ix) {
        this.ix = ix;
    }

    public String getCDtm() {
        return cDtm;
    }

    public void setCDtm(String cDtm) {
        this.cDtm = cDtm;
    }

    public String getCLogRef() {
        return cLogRef;
    }

    public void setCLogRef(String cLogRef) {
        this.cLogRef = cLogRef;
    }

    public int getFlags() {
        return flags;
    }

    public void setFlags(int flags) {
        this.flags = flags;
    }

    public int getSchVn() {
        return schVn;
    }

    public void setSchVn(int schVn) {
        this.schVn = schVn;
    }

    public int getVn() {
        return vn;
    }

    public void setVn(int vn) {
        this.vn = vn;
    }

    public int getAcctGroup() {
        return acctGroup;
    }

    public void setAcctGroup(int acctGroup) {
        this.acctGroup = acctGroup;
    }

    public String getAcctNbr() {
        return acctNbr;
    }

    public void setAcctNbr(String acctNbr) {
        this.acctNbr = acctNbr;
    }

    public AcctgSeg getAcctgSeg() {
        return acctgSeg;
    }

    public void setAcctgSeg(AcctgSeg acctgSeg) {
        this.acctgSeg = acctgSeg;
    }

    public int getAssetClass() {
        return assetClass;
    }

    public void setAssetClass(int assetClass) {
        this.assetClass = assetClass;
    }

    public String getCcyCode() {
        return ccyCode;
    }

    public void setCcyCode(String ccyCode) {
        this.ccyCode = ccyCode;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getGlSetCode() {
        return glSetCode;
    }

    public void setGlSetCode(String glSetCode) {
        this.glSetCode = glSetCode;
    }

    public boolean isIsDr() {
        return isDr;
    }

    public void setIsDr(boolean isDr) {
        this.isDr = isDr;
    }

    public String getPosnAcctNbr() {
        return posnAcctNbr;
    }

    public void setPosnAcctNbr(String posnAcctNbr) {
        this.posnAcctNbr = posnAcctNbr;
    }

    public String getPosnId() {
        return posnId;
    }

    public void setPosnId(String posnId) {
        this.posnId = posnId;
    }

    public int getSeqNbr() {
        return seqNbr;
    }

    public void setSeqNbr(int seqNbr) {
        this.seqNbr = seqNbr;
    }

    public double getTrnAmt() {
        return trnAmt;
    }

    public void setTrnAmt(double trnAmt) {
        this.trnAmt = trnAmt;
    }

}