
package com.backbase.training.dto.queue.acct;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Data {

    @SerializedName("_cDtm")
    @Expose
    private String cDtm;
    @SerializedName("_cLog")
    @Expose
    private String cLog;
    @SerializedName("_cLogRef")
    @Expose
    private String cLogRef;
    @SerializedName("_class")
    @Expose
    private String _class;
    @SerializedName("_flags")
    @Expose
    private int flags;
    @SerializedName("_schVn")
    @Expose
    private int schVn;
    @SerializedName("_vn")
    @Expose
    private int vn;
    @SerializedName("acctGroup")
    @Expose
    private int acctGroup;
    @SerializedName("acctNbr")
    @Expose
    private String acctNbr;
    @SerializedName("acctTitle")
    @Expose
    private String acctTitle;
    @SerializedName("baseCcy")
    @Expose
    private String baseCcy;
    @SerializedName("desc")
    @Expose
    private String desc;
    @SerializedName("isBrokered")
    @Expose
    private boolean isBrokered;
    @SerializedName("isElectronicStmt")
    @Expose
    private boolean isElectronicStmt;
    @SerializedName("isPaperStmt")
    @Expose
    private boolean isPaperStmt;
    @SerializedName("isWthFed")
    @Expose
    private boolean isWthFed;
    @SerializedName("isWthNra")
    @Expose
    private boolean isWthNra;
    @SerializedName("isWthState")
    @Expose
    private boolean isWthState;
    @SerializedName("openDtm")
    @Expose
    private String openDtm;
    @SerializedName("tmZoneCode")
    @Expose
    private String tmZoneCode;

    public String getCDtm() {
        return cDtm;
    }

    public void setCDtm(String cDtm) {
        this.cDtm = cDtm;
    }

    public String getCLog() {
        return cLog;
    }

    public void setCLog(String cLog) {
        this.cLog = cLog;
    }

    public String getCLogRef() {
        return cLogRef;
    }

    public void setCLogRef(String cLogRef) {
        this.cLogRef = cLogRef;
    }

    public String getClass_() {
        return _class;
    }

    public void setClass_(String _class) {
        this._class = _class;
    }

    public int getFlags() {
        return flags;
    }

    public void setFlags(int flags) {
        this.flags = flags;
    }

    public int getSchVn() {
        return schVn;
    }

    public void setSchVn(int schVn) {
        this.schVn = schVn;
    }

    public int getVn() {
        return vn;
    }

    public void setVn(int vn) {
        this.vn = vn;
    }

    public int getAcctGroup() {
        return acctGroup;
    }

    public void setAcctGroup(int acctGroup) {
        this.acctGroup = acctGroup;
    }

    public String getAcctNbr() {
        return acctNbr;
    }

    public void setAcctNbr(String acctNbr) {
        this.acctNbr = acctNbr;
    }

    public String getAcctTitle() {
        return acctTitle;
    }

    public void setAcctTitle(String acctTitle) {
        this.acctTitle = acctTitle;
    }

    public String getBaseCcy() {
        return baseCcy;
    }

    public void setBaseCcy(String baseCcy) {
        this.baseCcy = baseCcy;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public boolean isIsBrokered() {
        return isBrokered;
    }

    public void setIsBrokered(boolean isBrokered) {
        this.isBrokered = isBrokered;
    }

    public boolean isIsElectronicStmt() {
        return isElectronicStmt;
    }

    public void setIsElectronicStmt(boolean isElectronicStmt) {
        this.isElectronicStmt = isElectronicStmt;
    }

    public boolean isIsPaperStmt() {
        return isPaperStmt;
    }

    public void setIsPaperStmt(boolean isPaperStmt) {
        this.isPaperStmt = isPaperStmt;
    }

    public boolean isIsWthFed() {
        return isWthFed;
    }

    public void setIsWthFed(boolean isWthFed) {
        this.isWthFed = isWthFed;
    }

    public boolean isIsWthNra() {
        return isWthNra;
    }

    public void setIsWthNra(boolean isWthNra) {
        this.isWthNra = isWthNra;
    }

    public boolean isIsWthState() {
        return isWthState;
    }

    public void setIsWthState(boolean isWthState) {
        this.isWthState = isWthState;
    }

    public String getOpenDtm() {
        return openDtm;
    }

    public void setOpenDtm(String openDtm) {
        this.openDtm = openDtm;
    }

    public String getTmZoneCode() {
        return tmZoneCode;
    }

    public void setTmZoneCode(String tmZoneCode) {
        this.tmZoneCode = tmZoneCode;
    }

}