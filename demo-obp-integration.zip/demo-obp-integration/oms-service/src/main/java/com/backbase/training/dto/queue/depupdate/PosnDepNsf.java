package com.backbase.training.dto.queue.depupdate;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class PosnDepNsf {

    @SerializedName("_Id")
    @Expose
    private String id;
    @SerializedName("_cDtm")
    @Expose
    private String cDtm;
    @SerializedName("isOptIn")
    @Expose
    private boolean isOptIn;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCDtm() {
        return cDtm;
    }

    public void setCDtm(String cDtm) {
        this.cDtm = cDtm;
    }

    public boolean isIsOptIn() {
        return isOptIn;
    }

    public void setIsOptIn(boolean isOptIn) {
        this.isOptIn = isOptIn;
    }

}