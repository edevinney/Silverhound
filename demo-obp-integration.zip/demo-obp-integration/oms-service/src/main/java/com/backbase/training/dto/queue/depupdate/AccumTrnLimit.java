
package com.backbase.training.dto.queue.depupdate;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class AccumTrnLimit {

    @SerializedName("_Id")
    @Expose
    private String id;
    @SerializedName("_cDtm")
    @Expose
    private String cDtm;
    @SerializedName("_schVn")
    @Expose
    private int schVn;
    @SerializedName("_vn")
    @Expose
    private int vn;
    @SerializedName("crAmt")
    @Expose
    private int crAmt;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("period")
    @Expose
    private String period;
    @SerializedName("statGroup")
    @Expose
    private String statGroup;
    @SerializedName("violationAct")
    @Expose
    private int violationAct;
    @SerializedName("definedBy")
    @Expose
    private int definedBy;
    @SerializedName("drCnt")
    @Expose
    private int drCnt;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCDtm() {
        return cDtm;
    }

    public void setCDtm(String cDtm) {
        this.cDtm = cDtm;
    }

    public int getSchVn() {
        return schVn;
    }

    public void setSchVn(int schVn) {
        this.schVn = schVn;
    }

    public int getVn() {
        return vn;
    }

    public void setVn(int vn) {
        this.vn = vn;
    }

    public int getCrAmt() {
        return crAmt;
    }

    public void setCrAmt(int crAmt) {
        this.crAmt = crAmt;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPeriod() {
        return period;
    }

    public void setPeriod(String period) {
        this.period = period;
    }

    public String getStatGroup() {
        return statGroup;
    }

    public void setStatGroup(String statGroup) {
        this.statGroup = statGroup;
    }

    public int getViolationAct() {
        return violationAct;
    }

    public void setViolationAct(int violationAct) {
        this.violationAct = violationAct;
    }

    public int getDefinedBy() {
        return definedBy;
    }

    public void setDefinedBy(int definedBy) {
        this.definedBy = definedBy;
    }

    public int getDrCnt() {
        return drCnt;
    }

    public void setDrCnt(int drCnt) {
        this.drCnt = drCnt;
    }

}