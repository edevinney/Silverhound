package com.backbase.training.obp;

import com.backbase.training.multicore.IBankCoreUserAccount;
import com.backbase.training.multicore.IBankCoreUserMapper;
import com.backbase.training.obp.models.SandboxAccount;
import com.backbase.training.obp.models.SandboxAccounts;
import com.backbase.training.utils.Helper;

import java.util.List;

public class OBPUserMapper implements IBankCoreUserMapper {


    public List<SandboxAccount> GetSandboxAccounts() {
        // here to use the accounts that work from that list: https://github.com/OpenBankProject/OBP-API/wiki/Sandbox#example-customer-logins
        String json = "{\n" +
                "    \"accounts\": [\n" +
                "        {\n" +
                "            \"email\": \"anil.uk.29@example.com\",\n" +
                "            \"password\": \"588848\",\n" +
                "            \"user_name\": \"anil.uk.29@example.com\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"email\": \"ellie.uk.29@example.com\",\n" +
                "            \"password\": \"a81594\",\n" +
                "            \"user_name\": \"ellie.uk.29@example.com\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"email\": \"nathan.fr.29@example.com\",\n" +
                "            \"password\": \"bde179\",\n" +
                "            \"user_name\": \"nathan.fr.29@example.com\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"email\": \"roberto.it.29@example.com\",\n" +
                "            \"password\": \"6a463a\",\n" +
                "            \"user_name\": \"roberto.it.29@example.com\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"email\": \"alfio.it.29@example.com\",\n" +
                "            \"password\": \"69e8d6\",\n" +
                "            \"user_name\": \"alfio.it.29@example.com\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"email\": \"rob.us.29@example.com\",\n" +
                "            \"password\": \"a50eda\",\n" +
                "            \"user_name\": \"rob.us.29@example.com\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"email\": \"alf.us.29@example.com\",\n" +
                "            \"password\": \"9122a1\",\n" +
                "            \"user_name\": \"alf.us.29@example.com\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"email\": \"roby.tr.29@example.com\",\n" +
                "            \"password\": \"7deb47\",\n" +
                "            \"user_name\": \"roby.tr.29@example.com\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"email\": \"asil.tr.29@example.com\",\n" +
                "            \"password\": \"af2d2b\",\n" +
                "            \"user_name\": \"asil.tr.29@example.com\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"email\": \"robert.be.29@example.com\",\n" +
                "            \"password\": \"00f680\",\n" +
                "            \"user_name\": \"robert.be.29@example.com\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"email\": \"anil.be.29@example.com\",\n" +
                "            \"password\": \"9404f4\",\n" +
                "            \"user_name\": \"anil.be.29@example.com\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"email\": \"robert.de.29@example.com\",\n" +
                "            \"password\": \"ab4a83\",\n" +
                "            \"user_name\": \"robert.de.29@example.com\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"email\": \"anil.de.29@example.com\",\n" +
                "            \"password\": \"adfa28\",\n" +
                "            \"user_name\": \"anil.de.29@example.com\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"email\": \"jaakko.fi.29@example.com\",\n" +
                "            \"password\": \"8132cf\",\n" +
                "            \"user_name\": \"jaakko.fi.29@example.com\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"email\": \"timo.fi.29@example.com\",\n" +
                "            \"password\": \"6addcd\",\n" +
                "            \"user_name\": \"timo.fi.29@example.com\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"email\": \"katja.fi.29@example.com\",\n" +
                "            \"password\": \"ca0317\",\n" +
                "            \"user_name\": \"katja.fi.29@example.com\"\n" +
                "        }\n" +
                "    ]\n" +
                "}";

        SandboxAccounts accounts = Helper.Gson.fromJson(json, SandboxAccounts.class);
        return accounts.getAccounts();
    }

    public int ParseDemoUserName(String userName) {
        String number = userName.substring(1);
        int parsedNumber = Integer.parseInt(number);
        return parsedNumber;
    }

    @Override
    public IBankCoreUserAccount MapUserByKey(String key, String userName) {
        int userNameIndex = this.ParseDemoUserName(userName);
        List<SandboxAccount> accounts = this.GetSandboxAccounts();
        int howManySandboxUsers = accounts.size();
        int sandboxUserIndex = userNameIndex % howManySandboxUsers;
        SandboxAccount account = accounts.get(sandboxUserIndex);
        return new OBPUserAccount(account.getUser_name(), account.getPassword());
    }
}
