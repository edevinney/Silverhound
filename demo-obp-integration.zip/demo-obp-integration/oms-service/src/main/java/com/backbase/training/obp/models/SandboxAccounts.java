package com.backbase.training.obp.models;

import java.util.List;

@lombok.Data
public class SandboxAccounts {
    private List<SandboxAccount> accounts;
}