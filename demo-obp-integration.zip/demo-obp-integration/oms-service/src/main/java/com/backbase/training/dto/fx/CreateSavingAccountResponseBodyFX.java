package com.backbase.training.dto.fx;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@NoArgsConstructor
@Data
@Builder
@AllArgsConstructor
public class CreateSavingAccountResponseBodyFX {

    private List<AcctPartyRelsBean> acctPartyRels;
    private List<CreatedAccountsBean> createdAccounts;

    @NoArgsConstructor
    @Data
    @Builder
    @AllArgsConstructor
    public static class AcctPartyRelsBean {
        private int acctGroup;
        private String acctNbr;
        private String custId;
        private String groupId;
        private String partyId;
        private String partyRelDesc;
        private String relType;
        private String _cLog;
        private String _cDtm;
        private int _vn;
        private int _schVn;
    }

    @NoArgsConstructor
    @Data
    @Builder
    @AllArgsConstructor
    public static class CreatedAccountsBean {
        private AcctBkBean acct_bk;
        private List<PosnDepDtlBean> posn_depDtl;

        @NoArgsConstructor
        @Data
        @Builder
        @AllArgsConstructor
        public static class AcctBkBean {
            private int acctGroup;
            private String acctNbr;
            private String acctTitle;
            private String desc;
            private String openDtm;
            private String _cLog;
            private int _vn;
            private int _schVn;
            private String _class;
            private String baseCcy;
            private boolean isBrokered;
            private boolean isElectronicStmt;
            private boolean isPaperStmt;
            private String nextStmtDtm;
            private String stmtFreq;
            private String tmZoneCode;
            private double aggBalCDA;
            private double aggBalDDA;
            private double aggBalSDA;
            private double aggBalMMA;
            private double aggBalCMA;
            private double aggBalCCA;
            private double aggBalEQU;
            private double aggBalILA;
            private double aggBalCLA;
            private double aggBalLOC;
            private double aggBalAsset;
            private double aggBalLiability;
            private String _cDtm;
        }

        @NoArgsConstructor
        @Data
        @Builder
        @AllArgsConstructor
        public static class PosnDepDtlBean {
            private String prodName;
            private PosnDepBean posn_dep;

            @NoArgsConstructor
            @Data
            @Builder
            @AllArgsConstructor
            public static class PosnDepBean {
                private String _Id;
                private int acctGroup;
                private String acctNbr;
                private double bal;
                private String nextPosnCalDtm;
                private String openDtm;
                private String posnAcctNbr;
                private String posnName;
                private int posnNbr;
                private String tmZoneCode;
                private String _uLog;
                private String _uDtm;
                private int _vn;
                private int _schVn;
                private String _class;
                private AcctgSegBean acctgSeg;
                private String ccyCode;
                private String fundExpDtm;
                private int glCat;
                private String glSetCode;
                private String prodName;
                private SubBalsBean subBals;
                private String _cDtm;
                private PosnDepIntBean posn_depInt;
                private PosnDepLimitBean posn_depLimit;
                private String _attch;

                @NoArgsConstructor
                @Data
                @Builder
                @AllArgsConstructor
                public static class AcctgSegBean {
                    private String deptId;
                    private String vertical;
                }

                @NoArgsConstructor
                @Data
                @Builder
                @AllArgsConstructor
                public static class SubBalsBean {
                    private Dec2Bean dec2;
                    private Dec5Bean dec5;

                    @NoArgsConstructor
                    @Data
                    @Builder
                    @AllArgsConstructor
                    public static class Dec2Bean {
                        private double avlInt;
                        private double depFee;
                        private double penalty;
                        private double wthFed;
                        private double wthNra;
                        private double wthState;
                    }

                    @NoArgsConstructor
                    @Data
                    @Builder
                    @AllArgsConstructor
                    public static class Dec5Bean {
                        private double accrInt;
                        private double negAccr;
                    }
                }

                @NoArgsConstructor
                @Data
                @Builder
                @AllArgsConstructor
                public static class PosnDepIntBean {
                    private String _Id;
                    private String accrCalcTm;
                    private String accumToDtm;
                    private double balOpt;
                    private double calcMthd;
                    private String componentName;
                    private double disbmtOpt;
                    private IndexBean index;
                    private boolean isCompoundDly;
                    private boolean isWthFed;
                    private boolean isWthNra;
                    private boolean isWthState;
                    private String nextPostDtm;
                    private double nomRate;
                    private String postFreq;
                    private double sumIntPd;
                    private int version;
                    private String _uLog;
                    private double accrIntBal;
                    private double negAccrIntBal;
                    private double daysLstPost;
                    private double daysNxtPost;
                    private double apy;
                    private double apye;
                    private String _cDtm;
                    private String _uDtm;
                    private int _vn;
                    private int _schVn;

                    @NoArgsConstructor
                    @Data
                    @Builder
                    @AllArgsConstructor
                    public static class IndexBean {
                        private String indexName;
                        private boolean isReviewDly;
                    }
                }

                @NoArgsConstructor
                @Data
                @Builder
                @AllArgsConstructor
                public static class PosnDepLimitBean {
                    private String _Id;
                    private String componentName;
                    private boolean restrictCr;
                    private boolean restrictCrFundExp;
                    private boolean restrictDr;
                    private int version;
                    private String _cDtm;
                    private int _vn;
                    private int _schVn;
                    private List<AccumTrnLimitsBean> accumTrnLimits;
                    private List<PerTrnLimitsBean> perTrnLimits;

                    @NoArgsConstructor
                    @Data
                    @Builder
                    @AllArgsConstructor
                    public static class AccumTrnLimitsBean {
                        private String _Id;
                        private double crAmt;
                        private String name;
                        private String period;
                        private String statGroup;
                        private int violationAct;
                        private String _cDtm;
                        private int _vn;
                        private int _schVn;
                        private int crCnt;
                        private int drCnt;
                    }

                    @NoArgsConstructor
                    @Data
                    @Builder
                    @AllArgsConstructor
                    public static class PerTrnLimitsBean {
                        private String _Id;
                        private double maxDrAmt;
                        private String name;
                        private int violationAct;
                        private String _cDtm;
                        private int _vn;
                        private int _schVn;
                    }
                }
            }
        }
    }
}
