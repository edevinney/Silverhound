package com.backbase.training.services;

import com.backbase.pandp.arrangement.query.listener.client.v2.arrangements.PandpArrangementQueryArrangementsClient;
import com.backbase.pandp.arrangement.query.rest.spec.v2.arrangements.ArrangementItemQ;
import com.backbase.pandp.arrangement.query.rest.spec.v2.arrangements.ArrangementsPageQ;
import com.backbase.presentation.transaction.listener.client.v2.transactions.PresentationTransactionTransactionsClient;
import com.backbase.presentation.transaction.rest.spec.v2.transactions.TransactionsPostRequestBody;
import com.backbase.rest.spec.common.types.Currency;
import com.backbase.training.dto.fx.TransactionRespFX;
import com.backbase.training.utils.Configurator;
import com.backbase.training.utils.Constants;
import com.backbase.training.utils.RequestDataSupplier;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import javax.annotation.PostConstruct;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

@Slf4j
@Service
public class TransactionService {

    private RestTemplate template;

    private final Configurator config;
    private final PresentationTransactionTransactionsClient client;
    private final PandpArrangementQueryArrangementsClient queryArrangementsClient;
    private final RequestDataSupplier requestDataSupplier;

    @Autowired
    public TransactionService(
            PresentationTransactionTransactionsClient client,
            PandpArrangementQueryArrangementsClient queryArrangementsClient,
            RequestDataSupplier requestDataSupplier,
            Configurator config) {
        this.client = client;
        this.queryArrangementsClient = queryArrangementsClient;
        this.requestDataSupplier = requestDataSupplier;
        this.config = config;
    }

    @PostConstruct
    private void init() {
        template = config.getRestTemplate();
    }

    public void retrieveTransaction() {
        try {
            List<TransactionsPostRequestBody> transactions = getAndMapTransactionsFromFinxact();
            client.postTransactions(transactions);
        } catch (Exception ex) {
            this.log.error("Error synchronizing transactions", ex);
        }
    }

    private List<TransactionsPostRequestBody> getAndMapTransactionsFromFinxact() throws ParseException {
        List<TransactionsPostRequestBody> transactionsList = new ArrayList<>();
        ArrangementsPageQ arrangementsBody = queryArrangementsClient.getArrangements().getBody();

        List<ArrangementItemQ> allArrangements = arrangementsBody.getArrangements();
        for (ArrangementItemQ arrangement : allArrangements) {
            mapFinxactTransactionsForArrangement(transactionsList, arrangement);
        }
        return transactionsList;
    }

    private void mapFinxactTransactionsForArrangement(List<TransactionsPostRequestBody> transactionsList, ArrangementItemQ arrangement) throws ParseException {
        String externalArrangementId = arrangement.getExternalArrangementId();
        if (externalArrangementId.startsWith(Constants.CORE_PREFIX_OBP)) {
            log.warn("Skipping transaction sync OpenBank ACCOUNT " + externalArrangementId);
            return;
        }

        HttpHeaders headers = requestDataSupplier.setHeadersFxRest();

        String url = requestDataSupplier.getTransactionsFromFxUrl() + arrangement.getExternalArrangementId();
        HttpEntity<String> entity = new HttpEntity<>(headers);

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url)
                //TODO: remove these hardcoded dates. Instead do sync since from last run (=-24h)
                .queryParam("startDtm", "2018-01-29T15:04:05Z")
                .queryParam("endDtm", "2020-01-29T15:04:05Z")
                .queryParam("historyType", 1)
                .queryParam("desc", true);

        ResponseEntity<TransactionRespFX> exchange = template.exchange(builder.toUriString(), HttpMethod.GET, entity, TransactionRespFX.class);
        List<TransactionRespFX.Data> finxactTransactionHistory = exchange.getBody().getData();

        for (TransactionRespFX.Data entry : finxactTransactionHistory) {
            TransactionsPostRequestBody trn = mapFinxactTransactionToBackbase(arrangement, entry);
            transactionsList.add(trn);
        }
        log.info("===> Transactions for this arrangement " + arrangement.getExternalArrangementId() + " were mapped");
    }

    private TransactionsPostRequestBody mapFinxactTransactionToBackbase(ArrangementItemQ arrangement, TransactionRespFX.Data entry) throws ParseException {
        String dt = entry.getPosn().get_uDtm().substring(0, 19) + "Z";
        TimeZone tz = TimeZone.getTimeZone("UTC");
        //TODO: datetime formatting and parsing to move out to one class
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
        df.setTimeZone(tz);
        Date date = df.parse(dt);

        TransactionsPostRequestBody trn = new TransactionsPostRequestBody();

        BigDecimal amt = new BigDecimal(entry.getTrnEntry().getTrnAmt());
        Currency amount = new Currency();
        amount.setAmount(amt);
        amount.setCurrencyCode("USD");
        String description = entry.getTrnEntry().getComment();
        description = description == null ? "-" : description;

        trn.withArrangementId(arrangement.getId())
                .withExternalArrangementId(arrangement.getExternalArrangementId())
                .withExternalId(entry.getTrnEntry().get_Id().concat(arrangement.getExternalArrangementId()))
                .withDescription(description)
                .withType("SEPA CT")
                .withTypeGroup("Payment")
                .withTransactionAmountCurrency(amount)
                .withBookingDate(date)
                .withInstructedAmountCurrency(amount)
                .withCreditDebitIndicator(amountToCreditDebitIndicator(entry));
        return trn;
    }

    private TransactionsPostRequestBody.CreditDebitIndicator amountToCreditDebitIndicator(TransactionRespFX.Data entry) {
        if (entry.getTrnEntry().getIsDr()) {
            return TransactionsPostRequestBody.CreditDebitIndicator.DBIT;
        } else {
            return TransactionsPostRequestBody.CreditDebitIndicator.CRDT;
        }
    }
}





















