package com.backbase.training.dto.fx;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PaymentResponseFX {

    private List<DataBean> data;

    public List<DataBean> getData() {
        return data;
    }

    public void setData(List<DataBean> data) {
        this.data = data;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class DataBean {
        private String trnId;
        private String posnId;
        private String posnAcctNbr;
        private int acctGroup;
        private String acctNbr;
        private double beforeAvailBal;
        private double afterAvailBal;
        private double beforeLedgerBal;
        private double afterLedgerBal;
        private double beforeAuthAvailBal;
        private double afterAuthAvailBal;

        public String getTrnId() {
            return trnId;
        }

        public void setTrnId(String trnId) {
            this.trnId = trnId;
        }

        public String getPosnId() {
            return posnId;
        }

        public void setPosnId(String posnId) {
            this.posnId = posnId;
        }

        public String getPosnAcctNbr() {
            return posnAcctNbr;
        }

        public void setPosnAcctNbr(String posnAcctNbr) {
            this.posnAcctNbr = posnAcctNbr;
        }

        public int getAcctGroup() {
            return acctGroup;
        }

        public void setAcctGroup(int acctGroup) {
            this.acctGroup = acctGroup;
        }

        public String getAcctNbr() {
            return acctNbr;
        }

        public void setAcctNbr(String acctNbr) {
            this.acctNbr = acctNbr;
        }

        public double getBeforeAvailBal() {
            return beforeAvailBal;
        }

        public void setBeforeAvailBal(double beforeAvailBal) {
            this.beforeAvailBal = beforeAvailBal;
        }

        public double getAfterAvailBal() {
            return afterAvailBal;
        }

        public void setAfterAvailBal(double afterAvailBal) {
            this.afterAvailBal = afterAvailBal;
        }

        public double getBeforeLedgerBal() {
            return beforeLedgerBal;
        }

        public void setBeforeLedgerBal(double beforeLedgerBal) {
            this.beforeLedgerBal = beforeLedgerBal;
        }

        public double getAfterLedgerBal() {
            return afterLedgerBal;
        }

        public void setAfterLedgerBal(double afterLedgerBal) {
            this.afterLedgerBal = afterLedgerBal;
        }

        public double getBeforeAuthAvailBal() {
            return beforeAuthAvailBal;
        }

        public void setBeforeAuthAvailBal(double beforeAuthAvailBal) {
            this.beforeAuthAvailBal = beforeAuthAvailBal;
        }

        public double getAfterAuthAvailBal() {
            return afterAuthAvailBal;
        }

        public void setAfterAuthAvailBal(double afterAuthAvailBal) {
            this.afterAuthAvailBal = afterAuthAvailBal;
        }
    }
}
