package com.backbase.training.utils;

import org.springframework.stereotype.Component;

import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Component
public class RandomNumbersGenerator {
    public String getTenDigitRandomNumberFromUUID() {
        Pattern p = Pattern.compile("\\d+");
        Matcher m = p.matcher(UUID.randomUUID().toString());
        StringBuilder sb = new StringBuilder();
        while (m.find()) {
            sb.append(m.group());
        }
        return sb.toString().substring(0, 12);
    }

    public String getTenDigitRandomNumberFromMath() {
        return String.valueOf(Math.random() * 10_000_000).substring(0, 7);
    }
}
