package com.backbase.training.mapper.mapperIntf;

import com.backbase.presentation.transaction.rest.spec.v2.transactions.TransactionsPostRequestBody;
import com.backbase.training.dto.fx.TransactionRespFX;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import javax.inject.Named;
import java.math.BigDecimal;

@Mapper
public interface TransactionMapper {

    TransactionMapper MAPPER = Mappers.getMapper(TransactionMapper.class);

//    @Mapping(target = "arrangementId", source = "arrangementInternalID")
//    @Mapping(target = "externalArrangementId", source = "data.posn.acctNbr")
//    @Mapping(target = "externalId", source = "_Id")
//    @Mapping(target = "reference", source = "data.entries.get(0)._cLogRef")
//    @Mapping(target = "description", source = "data.entries.get(0).comment", defaultValue = "defaultValue")
//    @Mapping(target = "typeGroup", constant = "Payment")
//    @Mapping(target = "type", constant = "SEPA CT")
//    @Mapping(target = "category", source = "thisAccount.kind")
//    @Mapping(target = "bookingDate", dateFormat = "dd-MM-yyyy", source = "details.posted")
//    @Mapping(target = "valueDate", dateFormat = "dd-MM-yyyy", source = "details.completed")
//    @Mapping(target = "transactionAmountCurrency.amount", source = "details.newBalance.amount", qualifiedByName = "instructedAmountConverter", defaultValue = "0")
//    @Mapping(target = "transactionAmountCurrency.currencyCode", constant = "USD")
//    @Mapping(target = "instructedAmountCurrency.amount", source = "details.value.amount")
//    @Mapping(target = "instructedAmountCurrency.currencyCode", constant = "USD")
//    @Mapping(target = "currencyExchangeRate", defaultValue = "1")
//    @Mapping(target = "counterPartyName", source = "thisAccount.kind")
//    @Mapping(target = "counterPartyAccountNumber", source = "thisAccount.IBAN", qualifiedByName = "map", defaultValue = "NL86ABNA4461927814")
//    @Mapping(target = "counterPartyBIC", source = "thisAccount.bank.nationalIdentifier", defaultValue = "ING00000001")
//    @Mapping(target = "counterPartyCountry", constant = "NL")
//    @Mapping(target = "counterPartyBankName", source = "thisAccount.bank.name")
//    @Mapping(target = "creditorId", source = "otherAccount.holder.name")
//    @Mapping(target = "mandateReference", source = "details.type")
////    @Mapping(target = "billingStatus", defaultValue = "BILLED")
//    @Mapping(target = "checkSerialNumber", defaultValue = "1")
//    @Mapping(target = "runningBalance", defaultValue = "1")
//    @Mapping(target = "creditDebitIndicator", source = "details.value.amount", qualifiedByName = "creditDebitIndicator")
    TransactionsPostRequestBody toTransactionsPostRequestBody(TransactionRespFX.Data transaction);

    @Named("creditDebitIndicator")
    default TransactionsPostRequestBody.CreditDebitIndicator amountToCreditDebitIndicator(String amount) {
        BigDecimal value = new BigDecimal(amount);
        if (value.compareTo(BigDecimal.ZERO) < 0)
            return TransactionsPostRequestBody.CreditDebitIndicator.DBIT;
        return TransactionsPostRequestBody.CreditDebitIndicator.CRDT;
    }

    @Named("instructedAmountConverter")
    default BigDecimal convert(Object amount) {
        return new BigDecimal(amount.toString());
    }

    @Named("map")
    default String map(Object value) {
        return value == null ? "" : value.toString();
    }
}