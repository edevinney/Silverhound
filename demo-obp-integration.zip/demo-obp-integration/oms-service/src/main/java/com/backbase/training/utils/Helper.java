package com.backbase.training.utils;

import com.google.gson.Gson;

public class Helper {
    public static final com.google.gson.Gson Gson = new Gson();
}
