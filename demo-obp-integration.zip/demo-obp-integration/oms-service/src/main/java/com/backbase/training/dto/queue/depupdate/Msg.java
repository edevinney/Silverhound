
package com.backbase.training.dto.queue.depupdate;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Msg {

    @SerializedName("correlationID")
    @Expose
    private String correlationID;
    @SerializedName("eventKey")
    @Expose
    private String eventKey;
    @SerializedName("eventDtm")
    @Expose
    private String eventDtm;
    @SerializedName("resourceURI")
    @Expose
    private String resourceURI;
    @SerializedName("version")
    @Expose
    private int version;
    @SerializedName("data")
    @Expose
    private Data data;

    public String getCorrelationID() {
        return correlationID;
    }

    public void setCorrelationID(String correlationID) {
        this.correlationID = correlationID;
    }

    public String getEventKey() {
        return eventKey;
    }

    public void setEventKey(String eventKey) {
        this.eventKey = eventKey;
    }

    public String getEventDtm() {
        return eventDtm;
    }

    public void setEventDtm(String eventDtm) {
        this.eventDtm = eventDtm;
    }

    public String getResourceURI() {
        return resourceURI;
    }

    public void setResourceURI(String resourceURI) {
        this.resourceURI = resourceURI;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public Data getData() {
        return data;
    }

    public void setData(Data data) {
        this.data = data;
    }
}