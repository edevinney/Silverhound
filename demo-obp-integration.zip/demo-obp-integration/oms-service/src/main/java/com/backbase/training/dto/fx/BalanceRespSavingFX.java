package com.backbase.training.dto.fx;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class BalanceRespSavingFX {

    /**
     * acct_bk : {"acctGroup":1,"acctNbr":"172650084118","acctTitle":"Ragioveda Haqimzeju","desc":"Personal Education Savings","openDtm":"2019-11-15T12:33:29Z","_vn":0,"_flags":0,"_schVn":0,"_cLogRef":"4SSaQ1qEL2VkuV----1F----","_cLog":"4SSaQ1qHOhooT-----1F--V-","_class":"acct_bk","baseCcy":"USD","isBrokered":false,"isElectronicStmt":true,"isPaperStmt":false,"isWthFed":false,"isWthNra":false,"isWthState":false,"nextStmtDtm":"2019-12-01T04:59:59Z","stmtFreq":"0MAE","tmZoneCode":"usnyc","aggBalSDA":13500,"aggBalLiability":13500,"_cDtm":"2019-11-15T17:33:29.596348125Z"}
     * posn_depDtl : [{"posn_dep":{"_Id":"4SSaQ1qHOhooT----V1F-Co-","acctGroup":1,"acctNbr":"172650084118","assetClass":1,"bal":13500,"nextPosnCalDtm":"2019-12-01T04:59:59Z","posnAcctNbr":"172650084118","posnName":"P200101","posnNbr":1,"tmZoneCode":"usnyc","_uLog":"4SalxX2yPS3S7----V9F-Cs-","_uDtm":"2019-11-23T05:00:15.416314321Z","_vn":5,"_flags":0,"_schVn":0,"_cLogRef":"4SSaQ1qEL2VkuV----1F----","_uLogRef":"4SalxX2ySVond-----9F----","_class":"posn_dep","acctgSeg":{"deptId":"350","vertical":"01"},"ccyCode":"USD","fundExpDtm":"2019-12-16T04:59:59Z","glCat":2,"glSetCode":"PerSavless100k","openDtm":"2019-11-15T12:33:29Z","prodName":"P2001","subBals":{"dec2":{"avlInt":0,"depFee":0,"negBal":0,"penalty":0,"recurInc":0,"wthFed":0,"wthNra":0,"wthState":0},"dec5":{"accrInt":0.59178,"negAccr":0}},"availBal":13500,"authCrAmt":0,"sweepAvailBal":0,"authAvailBal":13500,"status":1,"collectedBal":0,"glBal":13500,"_cDtm":"2019-11-15T17:33:29.596348125Z","posn_depInt":{"_Id":"4SSaQ1qHOhooT----V1F-Co-","accrCalcTm":"23:59:59","accumToDtm":"2019-11-23T05:00:15.416314Z","balOpt":1,"calcMthd":1,"componentName":"Savings_Interest","disbmtOpt":1,"index":{"indexName":"Bank_Savings_Rate"},"is1099Exempt":false,"isCompoundDly":true,"isWthFed":false,"isWthNra":false,"isWthState":false,"nextPostDtm":"2019-12-01T04:59:59Z","nomRate":1.6,"postFreq":"0MAE","sumIntPd":0,"version":1,"_uLog":"4SalxX2yPS3S7---0F9F-DB-","accrIntBal":1.77542,"negAccrIntBal":0,"daysNxtPost":5,"apy":1.042,"apye":0,"_cDtm":"2019-11-15T17:33:29.596348125Z","_uDtm":"2019-11-23T05:00:15.416314321Z","_vn":2,"_flags":0,"_schVn":0,"_cLogRef":"4SSaQ1qEL2VkuV----1F----","_uLogRef":"4SalxX2ySVond-----9F----"},"posn_depLimit":{"_Id":"4SSaQ1qHOhooT----V1F-Co-","accumTrnLimits":[{"_Id":"4MNdNzNnZgZ------81F0k--","crAmt":10000,"name":"RDC Limits Personal","period":"P1M","statGroup":"RDC_Limits","violationAct":1,"_cDtm":"2019-01-02T22:43:51.357420233Z","_vn":0,"_schVn":0},{"_Id":"4MNdNzNnQu3------81F0k--","definedBy":1,"drCnt":6,"name":"Reg D Limits","period":"P1M","statGroup":"Reg_D_Counter","violationAct":1,"_cDtm":"2019-01-02T22:43:51.357411233Z","_vn":0,"_schVn":0}],"componentName":"Savings_Limits_Personal","perTrnLimits":[{"_Id":"4MNdNzNmfko------81F7F--","name":"ACH Limit","_cDtm":"2019-01-02T22:43:51.357361933Z","_vn":0,"_schVn":0}],"restrictCr":false,"restrictCrFundExp":false,"restrictDr":false,"version":1,"_cDtm":"2019-11-15T17:33:29.596348125Z","_vn":0,"_flags":0,"_schVn":0,"_cLogRef":"4SSaQ1qEL2VkuV----1F----"},"_attch":"posn_depLimit|posn_depInt|"}}]
     */

    private AcctBk acct_bk;
    private List<PosnDepDtl> posn_depDtl;

    public AcctBk getAcct_bk() {
        return acct_bk;
    }

    public void setAcct_bk(AcctBk acct_bk) {
        this.acct_bk = acct_bk;
    }

    public List<PosnDepDtl> getPosn_depDtl() {
        return posn_depDtl;
    }

    public void setPosn_depDtl(List<PosnDepDtl> posn_depDtl) {
        this.posn_depDtl = posn_depDtl;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class AcctBk {
        /**
         * acctGroup : 1
         * acctNbr : 172650084118
         * acctTitle : Ragioveda Haqimzeju
         * desc : Personal Education Savings
         * openDtm : 2019-11-15T12:33:29Z
         * _vn : 0
         * _flags : 0
         * _schVn : 0
         * _cLogRef : 4SSaQ1qEL2VkuV----1F----
         * _cLog : 4SSaQ1qHOhooT-----1F--V-
         * _class : acct_bk
         * baseCcy : USD
         * isBrokered : false
         * isElectronicStmt : true
         * isPaperStmt : false
         * isWthFed : false
         * isWthNra : false
         * isWthState : false
         * nextStmtDtm : 2019-12-01T04:59:59Z
         * stmtFreq : 0MAE
         * tmZoneCode : usnyc
         * aggBalSDA : 13500.0
         * aggBalLiability : 13500.0
         * _cDtm : 2019-11-15T17:33:29.596348125Z
         */

        private int acctGroup;
        private String acctNbr;
        private String acctTitle;
        private String desc;
        private String openDtm;
        private int _vn;
        private int _flags;
        private int _schVn;
        private String _cLogRef;
        private String _cLog;
        private String _class;
        private String baseCcy;
        private boolean isBrokered;
        private boolean isElectronicStmt;
        private boolean isPaperStmt;
        private boolean isWthFed;
        private boolean isWthNra;
        private boolean isWthState;
        private String nextStmtDtm;
        private String stmtFreq;
        private String tmZoneCode;
        private double aggBalSDA;
        private double aggBalLiability;
        private String _cDtm;

        public int getAcctGroup() {
            return acctGroup;
        }

        public void setAcctGroup(int acctGroup) {
            this.acctGroup = acctGroup;
        }

        public String getAcctNbr() {
            return acctNbr;
        }

        public void setAcctNbr(String acctNbr) {
            this.acctNbr = acctNbr;
        }

        public String getAcctTitle() {
            return acctTitle;
        }

        public void setAcctTitle(String acctTitle) {
            this.acctTitle = acctTitle;
        }

        public String getDesc() {
            return desc;
        }

        public void setDesc(String desc) {
            this.desc = desc;
        }

        public String getOpenDtm() {
            return openDtm;
        }

        public void setOpenDtm(String openDtm) {
            this.openDtm = openDtm;
        }

        public int get_vn() {
            return _vn;
        }

        public void set_vn(int _vn) {
            this._vn = _vn;
        }

        public int get_flags() {
            return _flags;
        }

        public void set_flags(int _flags) {
            this._flags = _flags;
        }

        public int get_schVn() {
            return _schVn;
        }

        public void set_schVn(int _schVn) {
            this._schVn = _schVn;
        }

        public String get_cLogRef() {
            return _cLogRef;
        }

        public void set_cLogRef(String _cLogRef) {
            this._cLogRef = _cLogRef;
        }

        public String get_cLog() {
            return _cLog;
        }

        public void set_cLog(String _cLog) {
            this._cLog = _cLog;
        }

        public String get_class() {
            return _class;
        }

        public void set_class(String _class) {
            this._class = _class;
        }

        public String getBaseCcy() {
            return baseCcy;
        }

        public void setBaseCcy(String baseCcy) {
            this.baseCcy = baseCcy;
        }

        public boolean isIsBrokered() {
            return isBrokered;
        }

        public void setIsBrokered(boolean isBrokered) {
            this.isBrokered = isBrokered;
        }

        public boolean isIsElectronicStmt() {
            return isElectronicStmt;
        }

        public void setIsElectronicStmt(boolean isElectronicStmt) {
            this.isElectronicStmt = isElectronicStmt;
        }

        public boolean isIsPaperStmt() {
            return isPaperStmt;
        }

        public void setIsPaperStmt(boolean isPaperStmt) {
            this.isPaperStmt = isPaperStmt;
        }

        public boolean isIsWthFed() {
            return isWthFed;
        }

        public void setIsWthFed(boolean isWthFed) {
            this.isWthFed = isWthFed;
        }

        public boolean isIsWthNra() {
            return isWthNra;
        }

        public void setIsWthNra(boolean isWthNra) {
            this.isWthNra = isWthNra;
        }

        public boolean isIsWthState() {
            return isWthState;
        }

        public void setIsWthState(boolean isWthState) {
            this.isWthState = isWthState;
        }

        public String getNextStmtDtm() {
            return nextStmtDtm;
        }

        public void setNextStmtDtm(String nextStmtDtm) {
            this.nextStmtDtm = nextStmtDtm;
        }

        public String getStmtFreq() {
            return stmtFreq;
        }

        public void setStmtFreq(String stmtFreq) {
            this.stmtFreq = stmtFreq;
        }

        public String getTmZoneCode() {
            return tmZoneCode;
        }

        public void setTmZoneCode(String tmZoneCode) {
            this.tmZoneCode = tmZoneCode;
        }

        public double getAggBalSDA() {
            return aggBalSDA;
        }

        public void setAggBalSDA(double aggBalSDA) {
            this.aggBalSDA = aggBalSDA;
        }

        public double getAggBalLiability() {
            return aggBalLiability;
        }

        public void setAggBalLiability(double aggBalLiability) {
            this.aggBalLiability = aggBalLiability;
        }

        public String get_cDtm() {
            return _cDtm;
        }

        public void set_cDtm(String _cDtm) {
            this._cDtm = _cDtm;
        }
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class PosnDepDtl {
        /**
         * posn_dep : {"_Id":"4SSaQ1qHOhooT----V1F-Co-","acctGroup":1,"acctNbr":"172650084118","assetClass":1,"bal":13500,"nextPosnCalDtm":"2019-12-01T04:59:59Z","posnAcctNbr":"172650084118","posnName":"P200101","posnNbr":1,"tmZoneCode":"usnyc","_uLog":"4SalxX2yPS3S7----V9F-Cs-","_uDtm":"2019-11-23T05:00:15.416314321Z","_vn":5,"_flags":0,"_schVn":0,"_cLogRef":"4SSaQ1qEL2VkuV----1F----","_uLogRef":"4SalxX2ySVond-----9F----","_class":"posn_dep","acctgSeg":{"deptId":"350","vertical":"01"},"ccyCode":"USD","fundExpDtm":"2019-12-16T04:59:59Z","glCat":2,"glSetCode":"PerSavless100k","openDtm":"2019-11-15T12:33:29Z","prodName":"P2001","subBals":{"dec2":{"avlInt":0,"depFee":0,"negBal":0,"penalty":0,"recurInc":0,"wthFed":0,"wthNra":0,"wthState":0},"dec5":{"accrInt":0.59178,"negAccr":0}},"availBal":13500,"authCrAmt":0,"sweepAvailBal":0,"authAvailBal":13500,"status":1,"collectedBal":0,"glBal":13500,"_cDtm":"2019-11-15T17:33:29.596348125Z","posn_depInt":{"_Id":"4SSaQ1qHOhooT----V1F-Co-","accrCalcTm":"23:59:59","accumToDtm":"2019-11-23T05:00:15.416314Z","balOpt":1,"calcMthd":1,"componentName":"Savings_Interest","disbmtOpt":1,"index":{"indexName":"Bank_Savings_Rate"},"is1099Exempt":false,"isCompoundDly":true,"isWthFed":false,"isWthNra":false,"isWthState":false,"nextPostDtm":"2019-12-01T04:59:59Z","nomRate":1.6,"postFreq":"0MAE","sumIntPd":0,"version":1,"_uLog":"4SalxX2yPS3S7---0F9F-DB-","accrIntBal":1.77542,"negAccrIntBal":0,"daysNxtPost":5,"apy":1.042,"apye":0,"_cDtm":"2019-11-15T17:33:29.596348125Z","_uDtm":"2019-11-23T05:00:15.416314321Z","_vn":2,"_flags":0,"_schVn":0,"_cLogRef":"4SSaQ1qEL2VkuV----1F----","_uLogRef":"4SalxX2ySVond-----9F----"},"posn_depLimit":{"_Id":"4SSaQ1qHOhooT----V1F-Co-","accumTrnLimits":[{"_Id":"4MNdNzNnZgZ------81F0k--","crAmt":10000,"name":"RDC Limits Personal","period":"P1M","statGroup":"RDC_Limits","violationAct":1,"_cDtm":"2019-01-02T22:43:51.357420233Z","_vn":0,"_schVn":0,"definedBy":1,"drCnt":6},{"_Id":"4MNdNzNnQu3------81F0k--","definedBy":1,"drCnt":6,"name":"Reg D Limits","period":"P1M","statGroup":"Reg_D_Counter","violationAct":1,"_cDtm":"2019-01-02T22:43:51.357411233Z","_vn":0,"_schVn":0}],"componentName":"Savings_Limits_Personal","perTrnLimits":[{"_Id":"4MNdNzNmfko------81F7F--","name":"ACH Limit","_cDtm":"2019-01-02T22:43:51.357361933Z","_vn":0,"_schVn":0}],"restrictCr":false,"restrictCrFundExp":false,"restrictDr":false,"version":1,"_cDtm":"2019-11-15T17:33:29.596348125Z","_vn":0,"_flags":0,"_schVn":0,"_cLogRef":"4SSaQ1qEL2VkuV----1F----"},"_attch":"posn_depLimit|posn_depInt|"}
         */

        private PosnDep posn_dep;

        public PosnDep getPosn_dep() {
            return posn_dep;
        }

        public void setPosn_dep(PosnDep posn_dep) {
            this.posn_dep = posn_dep;
        }

        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class PosnDep {
            /**
             * _Id : 4SSaQ1qHOhooT----V1F-Co-
             * acctGroup : 1
             * acctNbr : 172650084118
             * assetClass : 1
             * bal : 13500.0
             * nextPosnCalDtm : 2019-12-01T04:59:59Z
             * posnAcctNbr : 172650084118
             * posnName : P200101
             * posnNbr : 1
             * tmZoneCode : usnyc
             * _uLog : 4SalxX2yPS3S7----V9F-Cs-
             * _uDtm : 2019-11-23T05:00:15.416314321Z
             * _vn : 5
             * _flags : 0
             * _schVn : 0
             * _cLogRef : 4SSaQ1qEL2VkuV----1F----
             * _uLogRef : 4SalxX2ySVond-----9F----
             * _class : posn_dep
             * acctgSeg : {"deptId":"350","vertical":"01"}
             * ccyCode : USD
             * fundExpDtm : 2019-12-16T04:59:59Z
             * glCat : 2
             * glSetCode : PerSavless100k
             * openDtm : 2019-11-15T12:33:29Z
             * prodName : P2001
             * subBals : {"dec2":{"avlInt":0,"depFee":0,"negBal":0,"penalty":0,"recurInc":0,"wthFed":0,"wthNra":0,"wthState":0},"dec5":{"accrInt":0.59178,"negAccr":0}}
             * availBal : 13500.0
             * authCrAmt : 0.0
             * sweepAvailBal : 0.0
             * authAvailBal : 13500.0
             * status : 1
             * collectedBal : 0.0
             * glBal : 13500.0
             * _cDtm : 2019-11-15T17:33:29.596348125Z
             * posn_depInt : {"_Id":"4SSaQ1qHOhooT----V1F-Co-","accrCalcTm":"23:59:59","accumToDtm":"2019-11-23T05:00:15.416314Z","balOpt":1,"calcMthd":1,"componentName":"Savings_Interest","disbmtOpt":1,"index":{"indexName":"Bank_Savings_Rate"},"is1099Exempt":false,"isCompoundDly":true,"isWthFed":false,"isWthNra":false,"isWthState":false,"nextPostDtm":"2019-12-01T04:59:59Z","nomRate":1.6,"postFreq":"0MAE","sumIntPd":0,"version":1,"_uLog":"4SalxX2yPS3S7---0F9F-DB-","accrIntBal":1.77542,"negAccrIntBal":0,"daysNxtPost":5,"apy":1.042,"apye":0,"_cDtm":"2019-11-15T17:33:29.596348125Z","_uDtm":"2019-11-23T05:00:15.416314321Z","_vn":2,"_flags":0,"_schVn":0,"_cLogRef":"4SSaQ1qEL2VkuV----1F----","_uLogRef":"4SalxX2ySVond-----9F----"}
             * posn_depLimit : {"_Id":"4SSaQ1qHOhooT----V1F-Co-","accumTrnLimits":[{"_Id":"4MNdNzNnZgZ------81F0k--","crAmt":10000,"name":"RDC Limits Personal","period":"P1M","statGroup":"RDC_Limits","violationAct":1,"_cDtm":"2019-01-02T22:43:51.357420233Z","_vn":0,"_schVn":0},{"_Id":"4MNdNzNnQu3------81F0k--","definedBy":1,"drCnt":6,"name":"Reg D Limits","period":"P1M","statGroup":"Reg_D_Counter","violationAct":1,"_cDtm":"2019-01-02T22:43:51.357411233Z","_vn":0,"_schVn":0}],"componentName":"Savings_Limits_Personal","perTrnLimits":[{"_Id":"4MNdNzNmfko------81F7F--","name":"ACH Limit","_cDtm":"2019-01-02T22:43:51.357361933Z","_vn":0,"_schVn":0}],"restrictCr":false,"restrictCrFundExp":false,"restrictDr":false,"version":1,"_cDtm":"2019-11-15T17:33:29.596348125Z","_vn":0,"_flags":0,"_schVn":0,"_cLogRef":"4SSaQ1qEL2VkuV----1F----"}
             * _attch : posn_depLimit|posn_depInt|
             */

            private String _Id;
            private int acctGroup;
            private String acctNbr;
            private int assetClass;
            private double bal;
            private String nextPosnCalDtm;
            private String posnAcctNbr;
            private String posnName;
            private int posnNbr;
            private String tmZoneCode;
            private String _uLog;
            private String _uDtm;
            private int _vn;
            private int _flags;
            private int _schVn;
            private String _cLogRef;
            private String _uLogRef;
            private String _class;
            private AcctgSeg acctgSeg;
            private String ccyCode;
            private String fundExpDtm;
            private int glCat;
            private String glSetCode;
            private String openDtm;
            private String prodName;
            private SubBals subBals;
            private double availBal;
            private double authCrAmt;
            private double sweepAvailBal;
            private double authAvailBal;
            private int status;
            private double collectedBal;
            private double glBal;
            private String _cDtm;
            private PosnDepInt posn_depInt;
            private PosnDepLimit posn_depLimit;
            private String _attch;

            public String get_Id() {
                return _Id;
            }

            public void set_Id(String _Id) {
                this._Id = _Id;
            }

            public int getAcctGroup() {
                return acctGroup;
            }

            public void setAcctGroup(int acctGroup) {
                this.acctGroup = acctGroup;
            }

            public String getAcctNbr() {
                return acctNbr;
            }

            public void setAcctNbr(String acctNbr) {
                this.acctNbr = acctNbr;
            }

            public int getAssetClass() {
                return assetClass;
            }

            public void setAssetClass(int assetClass) {
                this.assetClass = assetClass;
            }

            public double getBal() {
                return bal;
            }

            public void setBal(double bal) {
                this.bal = bal;
            }

            public String getNextPosnCalDtm() {
                return nextPosnCalDtm;
            }

            public void setNextPosnCalDtm(String nextPosnCalDtm) {
                this.nextPosnCalDtm = nextPosnCalDtm;
            }

            public String getPosnAcctNbr() {
                return posnAcctNbr;
            }

            public void setPosnAcctNbr(String posnAcctNbr) {
                this.posnAcctNbr = posnAcctNbr;
            }

            public String getPosnName() {
                return posnName;
            }

            public void setPosnName(String posnName) {
                this.posnName = posnName;
            }

            public int getPosnNbr() {
                return posnNbr;
            }

            public void setPosnNbr(int posnNbr) {
                this.posnNbr = posnNbr;
            }

            public String getTmZoneCode() {
                return tmZoneCode;
            }

            public void setTmZoneCode(String tmZoneCode) {
                this.tmZoneCode = tmZoneCode;
            }

            public String get_uLog() {
                return _uLog;
            }

            public void set_uLog(String _uLog) {
                this._uLog = _uLog;
            }

            public String get_uDtm() {
                return _uDtm;
            }

            public void set_uDtm(String _uDtm) {
                this._uDtm = _uDtm;
            }

            public int get_vn() {
                return _vn;
            }

            public void set_vn(int _vn) {
                this._vn = _vn;
            }

            public int get_flags() {
                return _flags;
            }

            public void set_flags(int _flags) {
                this._flags = _flags;
            }

            public int get_schVn() {
                return _schVn;
            }

            public void set_schVn(int _schVn) {
                this._schVn = _schVn;
            }

            public String get_cLogRef() {
                return _cLogRef;
            }

            public void set_cLogRef(String _cLogRef) {
                this._cLogRef = _cLogRef;
            }

            public String get_uLogRef() {
                return _uLogRef;
            }

            public void set_uLogRef(String _uLogRef) {
                this._uLogRef = _uLogRef;
            }

            public String get_class() {
                return _class;
            }

            public void set_class(String _class) {
                this._class = _class;
            }

            public AcctgSeg getAcctgSeg() {
                return acctgSeg;
            }

            public void setAcctgSeg(AcctgSeg acctgSeg) {
                this.acctgSeg = acctgSeg;
            }

            public String getCcyCode() {
                return ccyCode;
            }

            public void setCcyCode(String ccyCode) {
                this.ccyCode = ccyCode;
            }

            public String getFundExpDtm() {
                return fundExpDtm;
            }

            public void setFundExpDtm(String fundExpDtm) {
                this.fundExpDtm = fundExpDtm;
            }

            public int getGlCat() {
                return glCat;
            }

            public void setGlCat(int glCat) {
                this.glCat = glCat;
            }

            public String getGlSetCode() {
                return glSetCode;
            }

            public void setGlSetCode(String glSetCode) {
                this.glSetCode = glSetCode;
            }

            public String getOpenDtm() {
                return openDtm;
            }

            public void setOpenDtm(String openDtm) {
                this.openDtm = openDtm;
            }

            public String getProdName() {
                return prodName;
            }

            public void setProdName(String prodName) {
                this.prodName = prodName;
            }

            public SubBals getSubBals() {
                return subBals;
            }

            public void setSubBals(SubBals subBals) {
                this.subBals = subBals;
            }

            public double getAvailBal() {
                return availBal;
            }

            public void setAvailBal(double availBal) {
                this.availBal = availBal;
            }

            public double getAuthCrAmt() {
                return authCrAmt;
            }

            public void setAuthCrAmt(double authCrAmt) {
                this.authCrAmt = authCrAmt;
            }

            public double getSweepAvailBal() {
                return sweepAvailBal;
            }

            public void setSweepAvailBal(double sweepAvailBal) {
                this.sweepAvailBal = sweepAvailBal;
            }

            public double getAuthAvailBal() {
                return authAvailBal;
            }

            public void setAuthAvailBal(double authAvailBal) {
                this.authAvailBal = authAvailBal;
            }

            public int getStatus() {
                return status;
            }

            public void setStatus(int status) {
                this.status = status;
            }

            public double getCollectedBal() {
                return collectedBal;
            }

            public void setCollectedBal(double collectedBal) {
                this.collectedBal = collectedBal;
            }

            public double getGlBal() {
                return glBal;
            }

            public void setGlBal(double glBal) {
                this.glBal = glBal;
            }

            public String get_cDtm() {
                return _cDtm;
            }

            public void set_cDtm(String _cDtm) {
                this._cDtm = _cDtm;
            }

            public PosnDepInt getPosn_depInt() {
                return posn_depInt;
            }

            public void setPosn_depInt(PosnDepInt posn_depInt) {
                this.posn_depInt = posn_depInt;
            }

            public PosnDepLimit getPosn_depLimit() {
                return posn_depLimit;
            }

            public void setPosn_depLimit(PosnDepLimit posn_depLimit) {
                this.posn_depLimit = posn_depLimit;
            }

            public String get_attch() {
                return _attch;
            }

            public void set_attch(String _attch) {
                this._attch = _attch;
            }

            @JsonIgnoreProperties(ignoreUnknown = true)
            public static class AcctgSeg {
                /**
                 * deptId : 350
                 * vertical : 01
                 */

                private String deptId;
                private String vertical;

                public String getDeptId() {
                    return deptId;
                }

                public void setDeptId(String deptId) {
                    this.deptId = deptId;
                }

                public String getVertical() {
                    return vertical;
                }

                public void setVertical(String vertical) {
                    this.vertical = vertical;
                }
            }

            @JsonIgnoreProperties(ignoreUnknown = true)
            public static class SubBals {
                /**
                 * dec2 : {"avlInt":0,"depFee":0,"negBal":0,"penalty":0,"recurInc":0,"wthFed":0,"wthNra":0,"wthState":0}
                 * dec5 : {"accrInt":0.59178,"negAccr":0}
                 */

                private Dec2 dec2;
                private Dec5 dec5;

                public Dec2 getDec2() {
                    return dec2;
                }

                public void setDec2(Dec2 dec2) {
                    this.dec2 = dec2;
                }

                public Dec5 getDec5() {
                    return dec5;
                }

                public void setDec5(Dec5 dec5) {
                    this.dec5 = dec5;
                }

                @JsonIgnoreProperties(ignoreUnknown = true)
                public static class Dec2 {
                    /**
                     * avlInt : 0.0
                     * depFee : 0.0
                     * negBal : 0.0
                     * penalty : 0.0
                     * recurInc : 0.0
                     * wthFed : 0.0
                     * wthNra : 0.0
                     * wthState : 0.0
                     */

                    private double avlInt;
                    private double depFee;
                    private double negBal;
                    private double penalty;
                    private double recurInc;
                    private double wthFed;
                    private double wthNra;
                    private double wthState;

                    public double getAvlInt() {
                        return avlInt;
                    }

                    public void setAvlInt(double avlInt) {
                        this.avlInt = avlInt;
                    }

                    public double getDepFee() {
                        return depFee;
                    }

                    public void setDepFee(double depFee) {
                        this.depFee = depFee;
                    }

                    public double getNegBal() {
                        return negBal;
                    }

                    public void setNegBal(double negBal) {
                        this.negBal = negBal;
                    }

                    public double getPenalty() {
                        return penalty;
                    }

                    public void setPenalty(double penalty) {
                        this.penalty = penalty;
                    }

                    public double getRecurInc() {
                        return recurInc;
                    }

                    public void setRecurInc(double recurInc) {
                        this.recurInc = recurInc;
                    }

                    public double getWthFed() {
                        return wthFed;
                    }

                    public void setWthFed(double wthFed) {
                        this.wthFed = wthFed;
                    }

                    public double getWthNra() {
                        return wthNra;
                    }

                    public void setWthNra(double wthNra) {
                        this.wthNra = wthNra;
                    }

                    public double getWthState() {
                        return wthState;
                    }

                    public void setWthState(double wthState) {
                        this.wthState = wthState;
                    }
                }

                @JsonIgnoreProperties(ignoreUnknown = true)
                public static class Dec5 {
                    /**
                     * accrInt : 0.59178
                     * negAccr : 0.0
                     */

                    private double accrInt;
                    private double negAccr;

                    public double getAccrInt() {
                        return accrInt;
                    }

                    public void setAccrInt(double accrInt) {
                        this.accrInt = accrInt;
                    }

                    public double getNegAccr() {
                        return negAccr;
                    }

                    public void setNegAccr(double negAccr) {
                        this.negAccr = negAccr;
                    }
                }
            }

            @JsonIgnoreProperties(ignoreUnknown = true)
            public static class PosnDepInt {
                /**
                 * _Id : 4SSaQ1qHOhooT----V1F-Co-
                 * accrCalcTm : 23:59:59
                 * accumToDtm : 2019-11-23T05:00:15.416314Z
                 * balOpt : 1
                 * calcMthd : 1
                 * componentName : Savings_Interest
                 * disbmtOpt : 1
                 * index : {"indexName":"Bank_Savings_Rate"}
                 * is1099Exempt : false
                 * isCompoundDly : true
                 * isWthFed : false
                 * isWthNra : false
                 * isWthState : false
                 * nextPostDtm : 2019-12-01T04:59:59Z
                 * nomRate : 1.6
                 * postFreq : 0MAE
                 * sumIntPd : 0.0
                 * version : 1
                 * _uLog : 4SalxX2yPS3S7---0F9F-DB-
                 * accrIntBal : 1.77542
                 * negAccrIntBal : 0.0
                 * daysNxtPost : 5
                 * apy : 1.042
                 * apye : 0.0
                 * _cDtm : 2019-11-15T17:33:29.596348125Z
                 * _uDtm : 2019-11-23T05:00:15.416314321Z
                 * _vn : 2
                 * _flags : 0
                 * _schVn : 0
                 * _cLogRef : 4SSaQ1qEL2VkuV----1F----
                 * _uLogRef : 4SalxX2ySVond-----9F----
                 */

                private String _Id;
                private String accrCalcTm;
                private String accumToDtm;
                private double balOpt;
                private double calcMthd;
                private String componentName;
                private double disbmtOpt;
                private Index index;
                private boolean is1099Exempt;
                private boolean isCompoundDly;
                private boolean isWthFed;
                private boolean isWthNra;
                private boolean isWthState;
                private String nextPostDtm;
                private double nomRate;
                private String postFreq;
                private double sumIntPd;
                private int version;
                private String _uLog;
                private double accrIntBal;
                private double negAccrIntBal;
                private double daysNxtPost;
                private double apy;
                private double apye;
                private String _cDtm;
                private String _uDtm;
                private int _vn;
                private int _flags;
                private int _schVn;
                private String _cLogRef;
                private String _uLogRef;

                public String get_Id() {
                    return _Id;
                }

                public void set_Id(String _Id) {
                    this._Id = _Id;
                }

                public String getAccrCalcTm() {
                    return accrCalcTm;
                }

                public void setAccrCalcTm(String accrCalcTm) {
                    this.accrCalcTm = accrCalcTm;
                }

                public String getAccumToDtm() {
                    return accumToDtm;
                }

                public void setAccumToDtm(String accumToDtm) {
                    this.accumToDtm = accumToDtm;
                }

                public double getBalOpt() {
                    return balOpt;
                }

                public void setBalOpt(double balOpt) {
                    this.balOpt = balOpt;
                }

                public double getCalcMthd() {
                    return calcMthd;
                }

                public void setCalcMthd(double calcMthd) {
                    this.calcMthd = calcMthd;
                }

                public String getComponentName() {
                    return componentName;
                }

                public void setComponentName(String componentName) {
                    this.componentName = componentName;
                }

                public double getDisbmtOpt() {
                    return disbmtOpt;
                }

                public void setDisbmtOpt(double disbmtOpt) {
                    this.disbmtOpt = disbmtOpt;
                }

                public Index getIndex() {
                    return index;
                }

                public void setIndex(Index index) {
                    this.index = index;
                }

                public boolean isIs1099Exempt() {
                    return is1099Exempt;
                }

                public void setIs1099Exempt(boolean is1099Exempt) {
                    this.is1099Exempt = is1099Exempt;
                }

                public boolean isIsCompoundDly() {
                    return isCompoundDly;
                }

                public void setIsCompoundDly(boolean isCompoundDly) {
                    this.isCompoundDly = isCompoundDly;
                }

                public boolean isIsWthFed() {
                    return isWthFed;
                }

                public void setIsWthFed(boolean isWthFed) {
                    this.isWthFed = isWthFed;
                }

                public boolean isIsWthNra() {
                    return isWthNra;
                }

                public void setIsWthNra(boolean isWthNra) {
                    this.isWthNra = isWthNra;
                }

                public boolean isIsWthState() {
                    return isWthState;
                }

                public void setIsWthState(boolean isWthState) {
                    this.isWthState = isWthState;
                }

                public String getNextPostDtm() {
                    return nextPostDtm;
                }

                public void setNextPostDtm(String nextPostDtm) {
                    this.nextPostDtm = nextPostDtm;
                }

                public double getNomRate() {
                    return nomRate;
                }

                public void setNomRate(double nomRate) {
                    this.nomRate = nomRate;
                }

                public String getPostFreq() {
                    return postFreq;
                }

                public void setPostFreq(String postFreq) {
                    this.postFreq = postFreq;
                }

                public double getSumIntPd() {
                    return sumIntPd;
                }

                public void setSumIntPd(double sumIntPd) {
                    this.sumIntPd = sumIntPd;
                }

                public int getVersion() {
                    return version;
                }

                public void setVersion(int version) {
                    this.version = version;
                }

                public String get_uLog() {
                    return _uLog;
                }

                public void set_uLog(String _uLog) {
                    this._uLog = _uLog;
                }

                public double getAccrIntBal() {
                    return accrIntBal;
                }

                public void setAccrIntBal(double accrIntBal) {
                    this.accrIntBal = accrIntBal;
                }

                public double getNegAccrIntBal() {
                    return negAccrIntBal;
                }

                public void setNegAccrIntBal(double negAccrIntBal) {
                    this.negAccrIntBal = negAccrIntBal;
                }

                public double getDaysNxtPost() {
                    return daysNxtPost;
                }

                public void setDaysNxtPost(double daysNxtPost) {
                    this.daysNxtPost = daysNxtPost;
                }

                public double getApy() {
                    return apy;
                }

                public void setApy(double apy) {
                    this.apy = apy;
                }

                public double getApye() {
                    return apye;
                }

                public void setApye(double apye) {
                    this.apye = apye;
                }

                public String get_cDtm() {
                    return _cDtm;
                }

                public void set_cDtm(String _cDtm) {
                    this._cDtm = _cDtm;
                }

                public String get_uDtm() {
                    return _uDtm;
                }

                public void set_uDtm(String _uDtm) {
                    this._uDtm = _uDtm;
                }

                public int get_vn() {
                    return _vn;
                }

                public void set_vn(int _vn) {
                    this._vn = _vn;
                }

                public int get_flags() {
                    return _flags;
                }

                public void set_flags(int _flags) {
                    this._flags = _flags;
                }

                public int get_schVn() {
                    return _schVn;
                }

                public void set_schVn(int _schVn) {
                    this._schVn = _schVn;
                }

                public String get_cLogRef() {
                    return _cLogRef;
                }

                public void set_cLogRef(String _cLogRef) {
                    this._cLogRef = _cLogRef;
                }

                public String get_uLogRef() {
                    return _uLogRef;
                }

                public void set_uLogRef(String _uLogRef) {
                    this._uLogRef = _uLogRef;
                }

                @JsonIgnoreProperties(ignoreUnknown = true)
                public static class Index {
                    /**
                     * indexName : Bank_Savings_Rate
                     */

                    private String indexName;

                    public String getIndexName() {
                        return indexName;
                    }

                    public void setIndexName(String indexName) {
                        this.indexName = indexName;
                    }
                }
            }

            @JsonIgnoreProperties(ignoreUnknown = true)
            public static class PosnDepLimit {
                /**
                 * _Id : 4SSaQ1qHOhooT----V1F-Co-
                 * accumTrnLimits : [{"_Id":"4MNdNzNnZgZ------81F0k--","crAmt":10000,"name":"RDC Limits Personal","period":"P1M","statGroup":"RDC_Limits","violationAct":1,"_cDtm":"2019-01-02T22:43:51.357420233Z","_vn":0,"_schVn":0},{"_Id":"4MNdNzNnQu3------81F0k--","definedBy":1,"drCnt":6,"name":"Reg D Limits","period":"P1M","statGroup":"Reg_D_Counter","violationAct":1,"_cDtm":"2019-01-02T22:43:51.357411233Z","_vn":0,"_schVn":0}]
                 * componentName : Savings_Limits_Personal
                 * perTrnLimits : [{"_Id":"4MNdNzNmfko------81F7F--","name":"ACH Limit","_cDtm":"2019-01-02T22:43:51.357361933Z","_vn":0,"_schVn":0}]
                 * restrictCr : false
                 * restrictCrFundExp : false
                 * restrictDr : false
                 * version : 1
                 * _cDtm : 2019-11-15T17:33:29.596348125Z
                 * _vn : 0
                 * _flags : 0
                 * _schVn : 0
                 * _cLogRef : 4SSaQ1qEL2VkuV----1F----
                 */

                private String _Id;
                private String componentName;
                private boolean restrictCr;
                private boolean restrictCrFundExp;
                private boolean restrictDr;
                private int version;
                private String _cDtm;
                private int _vn;
                private int _flags;
                private int _schVn;
                private String _cLogRef;
                private List<AccumTrnLimits> accumTrnLimits;
                private List<PerTrnLimits> perTrnLimits;

                public String get_Id() {
                    return _Id;
                }

                public void set_Id(String _Id) {
                    this._Id = _Id;
                }

                public String getComponentName() {
                    return componentName;
                }

                public void setComponentName(String componentName) {
                    this.componentName = componentName;
                }

                public boolean isRestrictCr() {
                    return restrictCr;
                }

                public void setRestrictCr(boolean restrictCr) {
                    this.restrictCr = restrictCr;
                }

                public boolean isRestrictCrFundExp() {
                    return restrictCrFundExp;
                }

                public void setRestrictCrFundExp(boolean restrictCrFundExp) {
                    this.restrictCrFundExp = restrictCrFundExp;
                }

                public boolean isRestrictDr() {
                    return restrictDr;
                }

                public void setRestrictDr(boolean restrictDr) {
                    this.restrictDr = restrictDr;
                }

                public int getVersion() {
                    return version;
                }

                public void setVersion(int version) {
                    this.version = version;
                }

                public String get_cDtm() {
                    return _cDtm;
                }

                public void set_cDtm(String _cDtm) {
                    this._cDtm = _cDtm;
                }

                public int get_vn() {
                    return _vn;
                }

                public void set_vn(int _vn) {
                    this._vn = _vn;
                }

                public int get_flags() {
                    return _flags;
                }

                public void set_flags(int _flags) {
                    this._flags = _flags;
                }

                public int get_schVn() {
                    return _schVn;
                }

                public void set_schVn(int _schVn) {
                    this._schVn = _schVn;
                }

                public String get_cLogRef() {
                    return _cLogRef;
                }

                public void set_cLogRef(String _cLogRef) {
                    this._cLogRef = _cLogRef;
                }

                public List<AccumTrnLimits> getAccumTrnLimits() {
                    return accumTrnLimits;
                }

                public void setAccumTrnLimits(List<AccumTrnLimits> accumTrnLimits) {
                    this.accumTrnLimits = accumTrnLimits;
                }

                public List<PerTrnLimits> getPerTrnLimits() {
                    return perTrnLimits;
                }

                public void setPerTrnLimits(List<PerTrnLimits> perTrnLimits) {
                    this.perTrnLimits = perTrnLimits;
                }

                @JsonIgnoreProperties(ignoreUnknown = true)
                public static class AccumTrnLimits {
                    /**
                     * _Id : 4MNdNzNnZgZ------81F0k--
                     * crAmt : 10000.0
                     * name : RDC Limits Personal
                     * period : P1M
                     * statGroup : RDC_Limits
                     * violationAct : 1
                     * _cDtm : 2019-01-02T22:43:51.357420233Z
                     * _vn : 0
                     * _schVn : 0
                     * definedBy : 1
                     * drCnt : 6
                     */

                    private String _Id;
                    private double crAmt;
                    private String name;
                    private String period;
                    private String statGroup;
                    private int violationAct;
                    private String _cDtm;
                    private int _vn;
                    private int _schVn;
                    private int definedBy;
                    private int drCnt;

                    public String get_Id() {
                        return _Id;
                    }

                    public void set_Id(String _Id) {
                        this._Id = _Id;
                    }

                    public double getCrAmt() {
                        return crAmt;
                    }

                    public void setCrAmt(double crAmt) {
                        this.crAmt = crAmt;
                    }

                    public String getName() {
                        return name;
                    }

                    public void setName(String name) {
                        this.name = name;
                    }

                    public String getPeriod() {
                        return period;
                    }

                    public void setPeriod(String period) {
                        this.period = period;
                    }

                    public String getStatGroup() {
                        return statGroup;
                    }

                    public void setStatGroup(String statGroup) {
                        this.statGroup = statGroup;
                    }

                    public int getViolationAct() {
                        return violationAct;
                    }

                    public void setViolationAct(int violationAct) {
                        this.violationAct = violationAct;
                    }

                    public String get_cDtm() {
                        return _cDtm;
                    }

                    public void set_cDtm(String _cDtm) {
                        this._cDtm = _cDtm;
                    }

                    public int get_vn() {
                        return _vn;
                    }

                    public void set_vn(int _vn) {
                        this._vn = _vn;
                    }

                    public int get_schVn() {
                        return _schVn;
                    }

                    public void set_schVn(int _schVn) {
                        this._schVn = _schVn;
                    }

                    public int getDefinedBy() {
                        return definedBy;
                    }

                    public void setDefinedBy(int definedBy) {
                        this.definedBy = definedBy;
                    }

                    public int getDrCnt() {
                        return drCnt;
                    }

                    public void setDrCnt(int drCnt) {
                        this.drCnt = drCnt;
                    }
                }

                @JsonIgnoreProperties(ignoreUnknown = true)
                public static class PerTrnLimits {
                    /**
                     * _Id : 4MNdNzNmfko------81F7F--
                     * name : ACH Limit
                     * _cDtm : 2019-01-02T22:43:51.357361933Z
                     * _vn : 0
                     * _schVn : 0
                     */

                    private String _Id;
                    private String name;
                    private String _cDtm;
                    private int _vn;
                    private int _schVn;

                    public String get_Id() {
                        return _Id;
                    }

                    public void set_Id(String _Id) {
                        this._Id = _Id;
                    }

                    public String getName() {
                        return name;
                    }

                    public void setName(String name) {
                        this.name = name;
                    }

                    public String get_cDtm() {
                        return _cDtm;
                    }

                    public void set_cDtm(String _cDtm) {
                        this._cDtm = _cDtm;
                    }

                    public int get_vn() {
                        return _vn;
                    }

                    public void set_vn(int _vn) {
                        this._vn = _vn;
                    }

                    public int get_schVn() {
                        return _schVn;
                    }

                    public void set_schVn(int _schVn) {
                        this._schVn = _schVn;
                    }
                }
            }
        }
    }
}
