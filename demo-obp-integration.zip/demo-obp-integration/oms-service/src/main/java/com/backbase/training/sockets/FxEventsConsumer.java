package com.backbase.training.sockets;

import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.activemq.ActiveMQConnectionFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.jms.*;

@Slf4j
@Component
public class FxEventsConsumer implements MessageListener {
    @Value("${finxact.activemq.address}")
    private String activeMqAddress = "";
    @Value("${finxact.activemq.topic}")
    private String activeMqTopic = "";
    private Connection connection;
    private Session session;
    private MessageConsumer consumer;
    private IQueueMessageProcessor messageProcessor;

    public void start() {
        try {
            ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory(activeMqAddress);
            connection = connectionFactory.createConnection();
            connection.start();
            session = connection.createSession(false, Session.CLIENT_ACKNOWLEDGE);
            Destination destination = session.createQueue(activeMqTopic);
            consumer = session.createConsumer(destination);
            consumer.setMessageListener(this);
        } catch (Exception e) {
            log.error("Exception when starting up FxEventsConsumer: " + e);
        }
    }

    @SneakyThrows
    @Override
    public void onMessage(Message message) {
        if (message instanceof TextMessage) {
            TextMessage textMessage = (TextMessage) message;
            String json = textMessage.getText();
            log.debug("Received a new message in the queue, JSON body is " + json);
            if (this.messageProcessor != null) {
                this.messageProcessor.onNewJsonMessage(json);
                message.acknowledge();
            }
        } else {
            log.warn("Received non-text message: " + message);
        }
    }

    public void setMessageListener(IQueueMessageProcessor messageProcessor) {
        this.messageProcessor = messageProcessor;
    }
}