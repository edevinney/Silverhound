package com.backbase.training.utils;

import com.backbase.presentation.accessgroup.rest.spec.v2.accessgroups.function.Permission;
import com.backbase.presentation.accessgroup.rest.spec.v2.accessgroups.function.Privilege;
import org.springframework.stereotype.Component;

import java.util.*;

import static com.backbase.training.utils.Constants.*;

@Component
public class PermissionSupplier {

    private List<Privilege> getPrivilegeList(String... privileges) {
        List<Privilege> privilegesList = new ArrayList<>();
        if (privileges.length > 0) {
            Arrays.stream(privileges).forEach(privilege -> privilegesList.add(new Privilege().withPrivilege(privilege)));
        }
        return privilegesList;
    }


    private Map<String, List<Privilege>> getPrivilegesMap() {
        Map<String, List<Privilege>> privilegesMap = new HashMap<>();
        privilegesMap.put(BB_FUNCTION_PRODUCT_SUMMARY, getPrivilegeList(PRIVILEGE_VIEW));
        privilegesMap.put(BB_FUNCTION_TRANSACTIONS, getPrivilegeList(PRIVILEGE_VIEW));
        privilegesMap.put(BB_FUNCTION_PAYMENTS_SEPA_CT, getPrivilegeList(PRIVILEGE_CREATE, PRIVILEGE_VIEW, PRIVILEGE_EDIT, PRIVILEGE_DELETE, PRIVILEGE_APPROVE, PRIVILEGE_CANCEL));
        privilegesMap.put(BB_FUNCTION_PAYMENTS_SEPA_CT_INTRA, getPrivilegeList(PRIVILEGE_CREATE, PRIVILEGE_VIEW, PRIVILEGE_EDIT, PRIVILEGE_DELETE, PRIVILEGE_APPROVE, PRIVILEGE_CANCEL));
        privilegesMap.put(BB_FUNCTION_PAYMENTS_INTRA, getPrivilegeList(PRIVILEGE_CREATE, PRIVILEGE_VIEW, PRIVILEGE_EDIT, PRIVILEGE_DELETE, PRIVILEGE_APPROVE, PRIVILEGE_CANCEL));
        privilegesMap.put(BB_FUNCTION_PAYMENTS_US_DOMESTIC_WIRE, getPrivilegeList(PRIVILEGE_CREATE, PRIVILEGE_VIEW, PRIVILEGE_EDIT, PRIVILEGE_DELETE, PRIVILEGE_APPROVE, PRIVILEGE_CANCEL));
        privilegesMap.put(BB_FUNCTION_PAYMENTS_US_DOMESTIC_WIRE_INTRA, getPrivilegeList(PRIVILEGE_CREATE, PRIVILEGE_VIEW, PRIVILEGE_EDIT, PRIVILEGE_DELETE, PRIVILEGE_APPROVE, PRIVILEGE_CANCEL));
        privilegesMap.put(BB_FUNCTION_PAYMENTS_US_FOREIGN_WIRE, getPrivilegeList(PRIVILEGE_CREATE, PRIVILEGE_VIEW, PRIVILEGE_EDIT, PRIVILEGE_DELETE, PRIVILEGE_APPROVE, PRIVILEGE_CANCEL));
        privilegesMap.put(BB_FUNCTION_PAYMENTS_US_FOREIGN_WIRE_INTRA, getPrivilegeList(PRIVILEGE_CREATE, PRIVILEGE_VIEW, PRIVILEGE_EDIT, PRIVILEGE_DELETE, PRIVILEGE_APPROVE, PRIVILEGE_CANCEL));
        privilegesMap.put(BB_FUNCTION_CONTACTS, getPrivilegeList(PRIVILEGE_CREATE, PRIVILEGE_VIEW, PRIVILEGE_EDIT, PRIVILEGE_DELETE, PRIVILEGE_APPROVE));
        return privilegesMap;
    }

    public List<Permission> getPermissionList() {
        List<Permission> permissionList = new ArrayList<>();
        Map<String, List<Privilege>> privilegesMap = getPrivilegesMap();
        privilegesMap.forEach((functionId, privilege) -> permissionList.add(new Permission().withFunctionId(functionId).withAssignedPrivileges(privilege)));
        return permissionList;
    }
}
