package com.backbase.training.dto.fx;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class BalanceRespLoanFX {


    private AcctBkBean acct_bk;
    private List<PosnLnDtlBean> posn_lnDtl;

    public AcctBkBean getAcct_bk() {
        return acct_bk;
    }

    public void setAcct_bk(AcctBkBean acct_bk) {
        this.acct_bk = acct_bk;
    }

    public List<PosnLnDtlBean> getPosn_lnDtl() {
        return posn_lnDtl;
    }

    public void setPosn_lnDtl(List<PosnLnDtlBean> posn_lnDtl) {
        this.posn_lnDtl = posn_lnDtl;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class AcctBkBean {
        private int acctGroup;
        private String acctNbr;
        private String acctTitle;
        private String desc;
        private String openDtm;
        private int _vn;
        private int _flags;
        private int _schVn;
        private String _cLogRef;
        private String _cLog;
        private String _class;
        private String baseCcy;
        private boolean isBrokered;
        private boolean isElectronicStmt;
        private boolean isPaperStmt;
        private boolean isWthFed;
        private boolean isWthNra;
        private boolean isWthState;
        private String tmZoneCode;
        private double aggBalILA;
        private double aggBalAsset;
        private String _cDtm;

        public int getAcctGroup() {
            return acctGroup;
        }

        public void setAcctGroup(int acctGroup) {
            this.acctGroup = acctGroup;
        }

        public String getAcctNbr() {
            return acctNbr;
        }

        public void setAcctNbr(String acctNbr) {
            this.acctNbr = acctNbr;
        }

        public String getAcctTitle() {
            return acctTitle;
        }

        public void setAcctTitle(String acctTitle) {
            this.acctTitle = acctTitle;
        }

        public String getDesc() {
            return desc;
        }

        public void setDesc(String desc) {
            this.desc = desc;
        }

        public String getOpenDtm() {
            return openDtm;
        }

        public void setOpenDtm(String openDtm) {
            this.openDtm = openDtm;
        }

        public int get_vn() {
            return _vn;
        }

        public void set_vn(int _vn) {
            this._vn = _vn;
        }

        public int get_flags() {
            return _flags;
        }

        public void set_flags(int _flags) {
            this._flags = _flags;
        }

        public int get_schVn() {
            return _schVn;
        }

        public void set_schVn(int _schVn) {
            this._schVn = _schVn;
        }

        public String get_cLogRef() {
            return _cLogRef;
        }

        public void set_cLogRef(String _cLogRef) {
            this._cLogRef = _cLogRef;
        }

        public String get_cLog() {
            return _cLog;
        }

        public void set_cLog(String _cLog) {
            this._cLog = _cLog;
        }

        public String get_class() {
            return _class;
        }

        public void set_class(String _class) {
            this._class = _class;
        }

        public String getBaseCcy() {
            return baseCcy;
        }

        public void setBaseCcy(String baseCcy) {
            this.baseCcy = baseCcy;
        }

        public boolean isIsBrokered() {
            return isBrokered;
        }

        public void setIsBrokered(boolean isBrokered) {
            this.isBrokered = isBrokered;
        }

        public boolean isIsElectronicStmt() {
            return isElectronicStmt;
        }

        public void setIsElectronicStmt(boolean isElectronicStmt) {
            this.isElectronicStmt = isElectronicStmt;
        }

        public boolean isIsPaperStmt() {
            return isPaperStmt;
        }

        public void setIsPaperStmt(boolean isPaperStmt) {
            this.isPaperStmt = isPaperStmt;
        }

        public boolean isIsWthFed() {
            return isWthFed;
        }

        public void setIsWthFed(boolean isWthFed) {
            this.isWthFed = isWthFed;
        }

        public boolean isIsWthNra() {
            return isWthNra;
        }

        public void setIsWthNra(boolean isWthNra) {
            this.isWthNra = isWthNra;
        }

        public boolean isIsWthState() {
            return isWthState;
        }

        public void setIsWthState(boolean isWthState) {
            this.isWthState = isWthState;
        }

        public String getTmZoneCode() {
            return tmZoneCode;
        }

        public void setTmZoneCode(String tmZoneCode) {
            this.tmZoneCode = tmZoneCode;
        }

        public double getAggBalILA() {
            return aggBalILA;
        }

        public void setAggBalILA(double aggBalILA) {
            this.aggBalILA = aggBalILA;
        }

        public double getAggBalAsset() {
            return aggBalAsset;
        }

        public void setAggBalAsset(double aggBalAsset) {
            this.aggBalAsset = aggBalAsset;
        }

        public String get_cDtm() {
            return _cDtm;
        }

        public void set_cDtm(String _cDtm) {
            this._cDtm = _cDtm;
        }
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class PosnLnDtlBean {
        private PosnLnBean posn_ln;

        public PosnLnBean getPosn_ln() {
            return posn_ln;
        }

        public void setPosn_ln(PosnLnBean posn_ln) {
            this.posn_ln = posn_ln;
        }

        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class PosnLnBean {
            private String _Id;
            private int acctGroup;
            private String acctNbr;
            private int assetClass;
            private double bal;
            private String nextPosnCalDtm;
            private String posnAcctNbr;
            private String posnName;
            private int posnNbr;
            private String tmZoneCode;
            private String _uLog;
            private String _uDtm;
            private int _vn;
            private int _flags;
            private int _schVn;
            private String _cLogRef;
            private String _uLogRef;
            private String _class;
            private AcctgSegBean acctgSeg;
            private String ccyCode;
            private double crLimit;
            private String firstDisbmtDtm;
            private int glCat;
            private String glSetCode;
            private String maturityDtm;
            private String openDtm;
            private String prodName;
            private SubBalsBean subBals;
            private double availBal;
            private double totBal;
            private int status;
            private String _cDtm;
            private PosnLnFeeBean posn_lnFee;
            private PosnLnIntBean posn_lnInt;
            private PosnLnRepayBean posn_lnRepay;
            private String _attch;

            public String get_Id() {
                return _Id;
            }

            public void set_Id(String _Id) {
                this._Id = _Id;
            }

            public int getAcctGroup() {
                return acctGroup;
            }

            public void setAcctGroup(int acctGroup) {
                this.acctGroup = acctGroup;
            }

            public String getAcctNbr() {
                return acctNbr;
            }

            public void setAcctNbr(String acctNbr) {
                this.acctNbr = acctNbr;
            }

            public int getAssetClass() {
                return assetClass;
            }

            public void setAssetClass(int assetClass) {
                this.assetClass = assetClass;
            }

            public double getBal() {
                return bal;
            }

            public void setBal(double bal) {
                this.bal = bal;
            }

            public String getNextPosnCalDtm() {
                return nextPosnCalDtm;
            }

            public void setNextPosnCalDtm(String nextPosnCalDtm) {
                this.nextPosnCalDtm = nextPosnCalDtm;
            }

            public String getPosnAcctNbr() {
                return posnAcctNbr;
            }

            public void setPosnAcctNbr(String posnAcctNbr) {
                this.posnAcctNbr = posnAcctNbr;
            }

            public String getPosnName() {
                return posnName;
            }

            public void setPosnName(String posnName) {
                this.posnName = posnName;
            }

            public int getPosnNbr() {
                return posnNbr;
            }

            public void setPosnNbr(int posnNbr) {
                this.posnNbr = posnNbr;
            }

            public String getTmZoneCode() {
                return tmZoneCode;
            }

            public void setTmZoneCode(String tmZoneCode) {
                this.tmZoneCode = tmZoneCode;
            }

            public String get_uLog() {
                return _uLog;
            }

            public void set_uLog(String _uLog) {
                this._uLog = _uLog;
            }

            public String get_uDtm() {
                return _uDtm;
            }

            public void set_uDtm(String _uDtm) {
                this._uDtm = _uDtm;
            }

            public int get_vn() {
                return _vn;
            }

            public void set_vn(int _vn) {
                this._vn = _vn;
            }

            public int get_flags() {
                return _flags;
            }

            public void set_flags(int _flags) {
                this._flags = _flags;
            }

            public int get_schVn() {
                return _schVn;
            }

            public void set_schVn(int _schVn) {
                this._schVn = _schVn;
            }

            public String get_cLogRef() {
                return _cLogRef;
            }

            public void set_cLogRef(String _cLogRef) {
                this._cLogRef = _cLogRef;
            }

            public String get_uLogRef() {
                return _uLogRef;
            }

            public void set_uLogRef(String _uLogRef) {
                this._uLogRef = _uLogRef;
            }

            public String get_class() {
                return _class;
            }

            public void set_class(String _class) {
                this._class = _class;
            }

            public AcctgSegBean getAcctgSeg() {
                return acctgSeg;
            }

            public void setAcctgSeg(AcctgSegBean acctgSeg) {
                this.acctgSeg = acctgSeg;
            }

            public String getCcyCode() {
                return ccyCode;
            }

            public void setCcyCode(String ccyCode) {
                this.ccyCode = ccyCode;
            }

            public double getCrLimit() {
                return crLimit;
            }

            public void setCrLimit(double crLimit) {
                this.crLimit = crLimit;
            }

            public String getFirstDisbmtDtm() {
                return firstDisbmtDtm;
            }

            public void setFirstDisbmtDtm(String firstDisbmtDtm) {
                this.firstDisbmtDtm = firstDisbmtDtm;
            }

            public int getGlCat() {
                return glCat;
            }

            public void setGlCat(int glCat) {
                this.glCat = glCat;
            }

            public String getGlSetCode() {
                return glSetCode;
            }

            public void setGlSetCode(String glSetCode) {
                this.glSetCode = glSetCode;
            }

            public String getMaturityDtm() {
                return maturityDtm;
            }

            public void setMaturityDtm(String maturityDtm) {
                this.maturityDtm = maturityDtm;
            }

            public String getOpenDtm() {
                return openDtm;
            }

            public void setOpenDtm(String openDtm) {
                this.openDtm = openDtm;
            }

            public String getProdName() {
                return prodName;
            }

            public void setProdName(String prodName) {
                this.prodName = prodName;
            }

            public SubBalsBean getSubBals() {
                return subBals;
            }

            public void setSubBals(SubBalsBean subBals) {
                this.subBals = subBals;
            }

            public double getAvailBal() {
                return availBal;
            }

            public void setAvailBal(double availBal) {
                this.availBal = availBal;
            }

            public double getTotBal() {
                return totBal;
            }

            public void setTotBal(double totBal) {
                this.totBal = totBal;
            }

            public int getStatus() {
                return status;
            }

            public void setStatus(int status) {
                this.status = status;
            }

            public String get_cDtm() {
                return _cDtm;
            }

            public void set_cDtm(String _cDtm) {
                this._cDtm = _cDtm;
            }

            public PosnLnFeeBean getPosn_lnFee() {
                return posn_lnFee;
            }

            public void setPosn_lnFee(PosnLnFeeBean posn_lnFee) {
                this.posn_lnFee = posn_lnFee;
            }

            public PosnLnIntBean getPosn_lnInt() {
                return posn_lnInt;
            }

            public void setPosn_lnInt(PosnLnIntBean posn_lnInt) {
                this.posn_lnInt = posn_lnInt;
            }

            public PosnLnRepayBean getPosn_lnRepay() {
                return posn_lnRepay;
            }

            public void setPosn_lnRepay(PosnLnRepayBean posn_lnRepay) {
                this.posn_lnRepay = posn_lnRepay;
            }

            public String get_attch() {
                return _attch;
            }

            public void set_attch(String _attch) {
                this._attch = _attch;
            }

            @JsonIgnoreProperties(ignoreUnknown = true)
            public static class AcctgSegBean {
                private String deptId;
                private String vertical;

                public String getDeptId() {
                    return deptId;
                }

                public void setDeptId(String deptId) {
                    this.deptId = deptId;
                }

                public String getVertical() {
                    return vertical;
                }

                public void setVertical(String vertical) {
                    this.vertical = vertical;
                }
            }

            @JsonIgnoreProperties(ignoreUnknown = true)
            public static class SubBalsBean {
                private Dec2Bean dec2;
                private Dec5Bean dec5;

                public Dec2Bean getDec2() {
                    return dec2;
                }

                public void setDec2(Dec2Bean dec2) {
                    this.dec2 = dec2;
                }

                public Dec5Bean getDec5() {
                    return dec5;
                }

                public void setDec5(Dec5Bean dec5) {
                    this.dec5 = dec5;
                }

                @JsonIgnoreProperties(ignoreUnknown = true)
                public static class Dec2Bean {
                    private int lateChrg;
                    private int lnFee;

                    public int getLateChrg() {
                        return lateChrg;
                    }

                    public void setLateChrg(int lateChrg) {
                        this.lateChrg = lateChrg;
                    }

                    public int getLnFee() {
                        return lnFee;
                    }

                    public void setLnFee(int lnFee) {
                        this.lnFee = lnFee;
                    }
                }

                @JsonIgnoreProperties(ignoreUnknown = true)
                public static class Dec5Bean {
                    private int accrInt;

                    public int getAccrInt() {
                        return accrInt;
                    }

                    public void setAccrInt(int accrInt) {
                        this.accrInt = accrInt;
                    }
                }
            }

            @JsonIgnoreProperties(ignoreUnknown = true)
            public static class PosnLnFeeBean {
                private String _Id;
                private String componentName;
                private FeeDtlBean feeDtl;
                private int version;
                private String _uLog;
                private String _cDtm;
                private String _uDtm;
                private int _vn;
                private int _flags;
                private int _schVn;
                private String _cLogRef;
                private String _uLogRef;

                public String get_Id() {
                    return _Id;
                }

                public void set_Id(String _Id) {
                    this._Id = _Id;
                }

                public String getComponentName() {
                    return componentName;
                }

                public void setComponentName(String componentName) {
                    this.componentName = componentName;
                }

                public FeeDtlBean getFeeDtl() {
                    return feeDtl;
                }

                public void setFeeDtl(FeeDtlBean feeDtl) {
                    this.feeDtl = feeDtl;
                }

                public int getVersion() {
                    return version;
                }

                public void setVersion(int version) {
                    this.version = version;
                }

                public String get_uLog() {
                    return _uLog;
                }

                public void set_uLog(String _uLog) {
                    this._uLog = _uLog;
                }

                public String get_cDtm() {
                    return _cDtm;
                }

                public void set_cDtm(String _cDtm) {
                    this._cDtm = _cDtm;
                }

                public String get_uDtm() {
                    return _uDtm;
                }

                public void set_uDtm(String _uDtm) {
                    this._uDtm = _uDtm;
                }

                public int get_vn() {
                    return _vn;
                }

                public void set_vn(int _vn) {
                    this._vn = _vn;
                }

                public int get_flags() {
                    return _flags;
                }

                public void set_flags(int _flags) {
                    this._flags = _flags;
                }

                public int get_schVn() {
                    return _schVn;
                }

                public void set_schVn(int _schVn) {
                    this._schVn = _schVn;
                }

                public String get_cLogRef() {
                    return _cLogRef;
                }

                public void set_cLogRef(String _cLogRef) {
                    this._cLogRef = _cLogRef;
                }

                public String get_uLogRef() {
                    return _uLogRef;
                }

                public void set_uLogRef(String _uLogRef) {
                    this._uLogRef = _uLogRef;
                }

                @JsonIgnoreProperties(ignoreUnknown = true)
                public static class FeeDtlBean {
                    private LateChargeBean late_charge;

                    public LateChargeBean getLate_charge() {
                        return late_charge;
                    }

                    public void setLate_charge(LateChargeBean late_charge) {
                        this.late_charge = late_charge;
                    }

                    @JsonIgnoreProperties(ignoreUnknown = true)
                    public static class LateChargeBean {
                    }
                }
            }

            @JsonIgnoreProperties(ignoreUnknown = true)
            public static class PosnLnIntBean {
                private String _Id;
                private String accrCalcTm;
                private String accumToDtm;
                private double apr;
                private double balOpt;
                private int calcMthd;
                private String componentName;
                private IndexBean index;
                private double nomRate;
                private int version;
                private String _uLog;
                private double accrIntBal;
                private String _cDtm;
                private String _uDtm;
                private int _vn;
                private int _flags;
                private int _schVn;
                private String _cLogRef;
                private String _uLogRef;

                public String get_Id() {
                    return _Id;
                }

                public void set_Id(String _Id) {
                    this._Id = _Id;
                }

                public String getAccrCalcTm() {
                    return accrCalcTm;
                }

                public void setAccrCalcTm(String accrCalcTm) {
                    this.accrCalcTm = accrCalcTm;
                }

                public String getAccumToDtm() {
                    return accumToDtm;
                }

                public void setAccumToDtm(String accumToDtm) {
                    this.accumToDtm = accumToDtm;
                }

                public double getApr() {
                    return apr;
                }

                public void setApr(double apr) {
                    this.apr = apr;
                }

                public double getBalOpt() {
                    return balOpt;
                }

                public void setBalOpt(double balOpt) {
                    this.balOpt = balOpt;
                }

                public int getCalcMthd() {
                    return calcMthd;
                }

                public void setCalcMthd(int calcMthd) {
                    this.calcMthd = calcMthd;
                }

                public String getComponentName() {
                    return componentName;
                }

                public void setComponentName(String componentName) {
                    this.componentName = componentName;
                }

                public IndexBean getIndex() {
                    return index;
                }

                public void setIndex(IndexBean index) {
                    this.index = index;
                }

                public double getNomRate() {
                    return nomRate;
                }

                public void setNomRate(double nomRate) {
                    this.nomRate = nomRate;
                }

                public int getVersion() {
                    return version;
                }

                public void setVersion(int version) {
                    this.version = version;
                }

                public String get_uLog() {
                    return _uLog;
                }

                public void set_uLog(String _uLog) {
                    this._uLog = _uLog;
                }

                public double getAccrIntBal() {
                    return accrIntBal;
                }

                public void setAccrIntBal(double accrIntBal) {
                    this.accrIntBal = accrIntBal;
                }

                public String get_cDtm() {
                    return _cDtm;
                }

                public void set_cDtm(String _cDtm) {
                    this._cDtm = _cDtm;
                }

                public String get_uDtm() {
                    return _uDtm;
                }

                public void set_uDtm(String _uDtm) {
                    this._uDtm = _uDtm;
                }

                public int get_vn() {
                    return _vn;
                }

                public void set_vn(int _vn) {
                    this._vn = _vn;
                }

                public int get_flags() {
                    return _flags;
                }

                public void set_flags(int _flags) {
                    this._flags = _flags;
                }

                public int get_schVn() {
                    return _schVn;
                }

                public void set_schVn(int _schVn) {
                    this._schVn = _schVn;
                }

                public String get_cLogRef() {
                    return _cLogRef;
                }

                public void set_cLogRef(String _cLogRef) {
                    this._cLogRef = _cLogRef;
                }

                public String get_uLogRef() {
                    return _uLogRef;
                }

                public void set_uLogRef(String _uLogRef) {
                    this._uLogRef = _uLogRef;
                }

                @JsonIgnoreProperties(ignoreUnknown = true)
                public static class IndexBean {
                    private String indexName;
                    private String nextReviewDtm;
                    private String reviewFreq;

                    public String getIndexName() {
                        return indexName;
                    }

                    public void setIndexName(String indexName) {
                        this.indexName = indexName;
                    }

                    public String getNextReviewDtm() {
                        return nextReviewDtm;
                    }

                    public void setNextReviewDtm(String nextReviewDtm) {
                        this.nextReviewDtm = nextReviewDtm;
                    }

                    public String getReviewFreq() {
                        return reviewFreq;
                    }

                    public void setReviewFreq(String reviewFreq) {
                        this.reviewFreq = reviewFreq;
                    }
                }
            }

            @JsonIgnoreProperties(ignoreUnknown = true)
            public static class PosnLnRepayBean {
                private String _Id;
                private String amortizeDur;
                private String componentName;
                private String dueDate;
                private double fixPmtAmt;
                private String gracePeriod;
                private int intMthd;
                private boolean isFixAmortize;
                private boolean isRevolving;
                private double minPmt;
                private String nextReceivableDtm;
                private double payoffVarianceAmt;
                private double pmtApplAdvance;
                private PmtApplMthdBean pmtApplMthd;
                private String pmtDur;
                private String pmtFreq;
                private String pmtOffset;
                private double prinBalBase;
                private double prinMthd;
                private String startDtm;
                private double toleranceAmt;
                private double totDisbmtAmt;
                private int version;
                private String _uLog;
                private double pastDueDays;
                private String _cDtm;
                private String _uDtm;
                private int _vn;
                private int _flags;
                private int _schVn;
                private String _cLogRef;
                private String _uLogRef;
                private List<PastDueBean> pastDue;

                public String get_Id() {
                    return _Id;
                }

                public void set_Id(String _Id) {
                    this._Id = _Id;
                }

                public String getAmortizeDur() {
                    return amortizeDur;
                }

                public void setAmortizeDur(String amortizeDur) {
                    this.amortizeDur = amortizeDur;
                }

                public String getComponentName() {
                    return componentName;
                }

                public void setComponentName(String componentName) {
                    this.componentName = componentName;
                }

                public String getDueDate() {
                    return dueDate;
                }

                public void setDueDate(String dueDate) {
                    this.dueDate = dueDate;
                }

                public double getFixPmtAmt() {
                    return fixPmtAmt;
                }

                public void setFixPmtAmt(double fixPmtAmt) {
                    this.fixPmtAmt = fixPmtAmt;
                }

                public String getGracePeriod() {
                    return gracePeriod;
                }

                public void setGracePeriod(String gracePeriod) {
                    this.gracePeriod = gracePeriod;
                }

                public int getIntMthd() {
                    return intMthd;
                }

                public void setIntMthd(int intMthd) {
                    this.intMthd = intMthd;
                }

                public boolean isIsFixAmortize() {
                    return isFixAmortize;
                }

                public void setIsFixAmortize(boolean isFixAmortize) {
                    this.isFixAmortize = isFixAmortize;
                }

                public boolean isIsRevolving() {
                    return isRevolving;
                }

                public void setIsRevolving(boolean isRevolving) {
                    this.isRevolving = isRevolving;
                }

                public double getMinPmt() {
                    return minPmt;
                }

                public void setMinPmt(double minPmt) {
                    this.minPmt = minPmt;
                }

                public String getNextReceivableDtm() {
                    return nextReceivableDtm;
                }

                public void setNextReceivableDtm(String nextReceivableDtm) {
                    this.nextReceivableDtm = nextReceivableDtm;
                }

                public double getPayoffVarianceAmt() {
                    return payoffVarianceAmt;
                }

                public void setPayoffVarianceAmt(double payoffVarianceAmt) {
                    this.payoffVarianceAmt = payoffVarianceAmt;
                }

                public double getPmtApplAdvance() {
                    return pmtApplAdvance;
                }

                public void setPmtApplAdvance(double pmtApplAdvance) {
                    this.pmtApplAdvance = pmtApplAdvance;
                }

                public PmtApplMthdBean getPmtApplMthd() {
                    return pmtApplMthd;
                }

                public void setPmtApplMthd(PmtApplMthdBean pmtApplMthd) {
                    this.pmtApplMthd = pmtApplMthd;
                }

                public String getPmtDur() {
                    return pmtDur;
                }

                public void setPmtDur(String pmtDur) {
                    this.pmtDur = pmtDur;
                }

                public String getPmtFreq() {
                    return pmtFreq;
                }

                public void setPmtFreq(String pmtFreq) {
                    this.pmtFreq = pmtFreq;
                }

                public String getPmtOffset() {
                    return pmtOffset;
                }

                public void setPmtOffset(String pmtOffset) {
                    this.pmtOffset = pmtOffset;
                }

                public double getPrinBalBase() {
                    return prinBalBase;
                }

                public void setPrinBalBase(double prinBalBase) {
                    this.prinBalBase = prinBalBase;
                }

                public double getPrinMthd() {
                    return prinMthd;
                }

                public void setPrinMthd(double prinMthd) {
                    this.prinMthd = prinMthd;
                }

                public String getStartDtm() {
                    return startDtm;
                }

                public void setStartDtm(String startDtm) {
                    this.startDtm = startDtm;
                }

                public double getToleranceAmt() {
                    return toleranceAmt;
                }

                public void setToleranceAmt(double toleranceAmt) {
                    this.toleranceAmt = toleranceAmt;
                }

                public double getTotDisbmtAmt() {
                    return totDisbmtAmt;
                }

                public void setTotDisbmtAmt(double totDisbmtAmt) {
                    this.totDisbmtAmt = totDisbmtAmt;
                }

                public int getVersion() {
                    return version;
                }

                public void setVersion(int version) {
                    this.version = version;
                }

                public String get_uLog() {
                    return _uLog;
                }

                public void set_uLog(String _uLog) {
                    this._uLog = _uLog;
                }

                public double getPastDueDays() {
                    return pastDueDays;
                }

                public void setPastDueDays(double pastDueDays) {
                    this.pastDueDays = pastDueDays;
                }

                public String get_cDtm() {
                    return _cDtm;
                }

                public void set_cDtm(String _cDtm) {
                    this._cDtm = _cDtm;
                }

                public String get_uDtm() {
                    return _uDtm;
                }

                public void set_uDtm(String _uDtm) {
                    this._uDtm = _uDtm;
                }

                public int get_vn() {
                    return _vn;
                }

                public void set_vn(int _vn) {
                    this._vn = _vn;
                }

                public int get_flags() {
                    return _flags;
                }

                public void set_flags(int _flags) {
                    this._flags = _flags;
                }

                public int get_schVn() {
                    return _schVn;
                }

                public void set_schVn(int _schVn) {
                    this._schVn = _schVn;
                }

                public String get_cLogRef() {
                    return _cLogRef;
                }

                public void set_cLogRef(String _cLogRef) {
                    this._cLogRef = _cLogRef;
                }

                public String get_uLogRef() {
                    return _uLogRef;
                }

                public void set_uLogRef(String _uLogRef) {
                    this._uLogRef = _uLogRef;
                }

                public List<PastDueBean> getPastDue() {
                    return pastDue;
                }

                public void setPastDue(List<PastDueBean> pastDue) {
                    this.pastDue = pastDue;
                }

                @JsonIgnoreProperties(ignoreUnknown = true)
                public static class PmtApplMthdBean {
                    private CurrentBean Current;
                    private PastBean Past;
                    private PriorityBean Priority;

                    public CurrentBean getCurrent() {
                        return Current;
                    }

                    public void setCurrent(CurrentBean Current) {
                        this.Current = Current;
                    }

                    public PastBean getPast() {
                        return Past;
                    }

                    public void setPast(PastBean Past) {
                        this.Past = Past;
                    }

                    public PriorityBean getPriority() {
                        return Priority;
                    }

                    public void setPriority(PriorityBean Priority) {
                        this.Priority = Priority;
                    }

                    @JsonIgnoreProperties(ignoreUnknown = true)
                    public static class CurrentBean {
                        private String direction;
                        private List<String> dueItemOrder;

                        public String getDirection() {
                            return direction;
                        }

                        public void setDirection(String direction) {
                            this.direction = direction;
                        }

                        public List<String> getDueItemOrder() {
                            return dueItemOrder;
                        }

                        public void setDueItemOrder(List<String> dueItemOrder) {
                            this.dueItemOrder = dueItemOrder;
                        }
                    }

                    @JsonIgnoreProperties(ignoreUnknown = true)
                    public static class PastBean {
                        private String direction;
                        private List<String> dueItemOrder;

                        public String getDirection() {
                            return direction;
                        }

                        public void setDirection(String direction) {
                            this.direction = direction;
                        }

                        public List<String> getDueItemOrder() {
                            return dueItemOrder;
                        }

                        public void setDueItemOrder(List<String> dueItemOrder) {
                            this.dueItemOrder = dueItemOrder;
                        }
                    }

                    @JsonIgnoreProperties(ignoreUnknown = true)
                    public static class PriorityBean {
                        private String direction;
                        private List<String> dueItemOrder;

                        public String getDirection() {
                            return direction;
                        }

                        public void setDirection(String direction) {
                            this.direction = direction;
                        }

                        public List<String> getDueItemOrder() {
                            return dueItemOrder;
                        }

                        public void setDueItemOrder(List<String> dueItemOrder) {
                            this.dueItemOrder = dueItemOrder;
                        }
                    }
                }

                @JsonIgnoreProperties(ignoreUnknown = true)
                public static class PastDueBean {
                    private String pastDueTerm;

                    public String getPastDueTerm() {
                        return pastDueTerm;
                    }

                    public void setPastDueTerm(String pastDueTerm) {
                        this.pastDueTerm = pastDueTerm;
                    }
                }
            }
        }
    }
}
