package com.backbase.training.api.controllers;

import com.backbase.onboarding.rest.spec.v1.onboarding.OnboardingApi;
import com.backbase.onboarding.rest.spec.v1.onboarding.OnboardingPostRequestBody;
import com.backbase.onboarding.rest.spec.v1.onboarding.OnboardingPostResponseBody;
import org.apache.camel.EndpointInject;
import org.apache.camel.ProducerTemplate;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import static com.backbase.training.utils.Constants.DIRECT_GET;

@RestController
public class OnBoardingRestController implements OnboardingApi {

    @EndpointInject(uri = DIRECT_GET)
    private ProducerTemplate omsRoute;


    @Override
    public OnboardingPostResponseBody postOnboarding(
            @Valid OnboardingPostRequestBody onboardingPostRequestBody,
            HttpServletRequest httpServletRequest,
            HttpServletResponse httpServletResponse) {
        return (OnboardingPostResponseBody) omsRoute.requestBody(onboardingPostRequestBody);
    }
}
