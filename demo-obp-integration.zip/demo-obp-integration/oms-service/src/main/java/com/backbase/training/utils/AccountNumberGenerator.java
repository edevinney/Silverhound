package com.backbase.training.utils;

import com.backbase.training.dto.fx.AccountGenerationDto;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.apache.http.HttpHost;
import org.apache.http.client.methods.RequestBuilder;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.apache.http.util.TextUtils;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Slf4j
@Component
public class AccountNumberGenerator {

    private final Configurator config;
    private final RequestDataSupplier requestDataSupplier;

    public AccountNumberGenerator(Configurator config, RequestDataSupplier requestDataSupplier) {
        this.config = config;
        this.requestDataSupplier = requestDataSupplier;
    }

    public String generateNewAccountNumber() throws IllegalStateException, IOException {
        log.debug("Starting FX account generator API call");
        HttpClientBuilder builder = HttpClientBuilder.create();
        if (config.useProxyForFinxact) {
            log.debug("Using proxy for AccountNumberGenerator to get token from Finxact");
            builder.setProxy(new HttpHost(config.finxactProxyHost, config.finxactProxyPortInt));
        }
        val httpClient = builder.build();
        val endpoint = requestDataSupplier.getAccountNumberGenerationUrl();
        val request = requestDataSupplier.setHeadersFxRequestBuilder(RequestBuilder.post().setUri(endpoint)).setEntity(new StringEntity("{}")).build();
        val response = httpClient.execute(request);
        log.debug("Finxact account number generator response status {}", response.getStatusLine().getStatusCode());
        int statusCode = response.getStatusLine().getStatusCode();
        String responseBody = EntityUtils.toString(response.getEntity());
        if (statusCode == 200) {
            AccountGenerationDto dto = Helper.Gson.fromJson(responseBody, AccountGenerationDto.class);
            String newAccountNumber = dto.getAcctNbr();
            if (TextUtils.isEmpty(newAccountNumber)) {
                log.error("Finxact account number generation failed to process response (200). Response body {}", responseBody);
            }
            return newAccountNumber;
        } else {

            log.error("Request to Finxact failed with status {} and body {}", responseBody);
        }

        throw new IllegalStateException("Finxact did not generate a valid account number");
    }
}
