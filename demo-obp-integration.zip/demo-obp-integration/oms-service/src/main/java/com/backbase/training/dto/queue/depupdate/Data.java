
package com.backbase.training.dto.queue.depupdate;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Data {

    @SerializedName("_Id")
    @Expose
    private String id;
    @SerializedName("_attch")
    @Expose
    private String attch;
    @SerializedName("_cDtm")
    @Expose
    private String cDtm;
    @SerializedName("_cLogRef")
    @Expose
    private String cLogRef;
    @SerializedName("_class")
    @Expose
    private String _class;
    @SerializedName("_flags")
    @Expose
    private int flags;
    @SerializedName("_schVn")
    @Expose
    private int schVn;
    @SerializedName("_uDtm")
    @Expose
    private String uDtm;
    @SerializedName("_uLog")
    @Expose
    private String uLog;
    @SerializedName("_uLogRef")
    @Expose
    private String uLogRef;
    @SerializedName("_vn")
    @Expose
    private int vn;
    @SerializedName("acctGroup")
    @Expose
    private int acctGroup;
    @SerializedName("acctNbr")
    @Expose
    private String acctNbr;
    @SerializedName("acctgSeg")
    @Expose
    private AcctgSeg acctgSeg;
    @SerializedName("assetClass")
    @Expose
    private int assetClass;
    @SerializedName("authCrAmt")
    @Expose
    private double authCrAmt;
    @SerializedName("bal")
    @Expose
    private double bal;
    @SerializedName("ccyCode")
    @Expose
    private String ccyCode;
    @SerializedName("collectedBal")
    @Expose
    private double collectedBal;
    @SerializedName("fundExpDtm")
    @Expose
    private String fundExpDtm;
    @SerializedName("glCat")
    @Expose
    private int glCat;
    @SerializedName("glSetCode")
    @Expose
    private String glSetCode;
    @SerializedName("nextPosnCalDtm")
    @Expose
    private String nextPosnCalDtm;
    @SerializedName("openDtm")
    @Expose
    private String openDtm;
    @SerializedName("posnAcctNbr")
    @Expose
    private String posnAcctNbr;
    @SerializedName("posnName")
    @Expose
    private String posnName;
    @SerializedName("posnNbr")
    @Expose
    private int posnNbr;
    @SerializedName("posn_depInt")
    @Expose
    private PosnDepInt posnDepInt;
    @SerializedName("posn_depLimit")
    @Expose
    private PosnDepLimit posnDepLimit;
    @SerializedName("posn_depNsf")
    @Expose
    private PosnDepNsf posnDepNsf;
    @SerializedName("prodName")
    @Expose
    private String prodName;
    @SerializedName("subBals")
    @Expose
    private SubBals subBals;
    @SerializedName("sweepAvailBal")
    @Expose
    private int sweepAvailBal;
    @SerializedName("tmZoneCode")
    @Expose
    private String tmZoneCode;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAttch() {
        return attch;
    }

    public void setAttch(String attch) {
        this.attch = attch;
    }

    public String getCDtm() {
        return cDtm;
    }

    public void setCDtm(String cDtm) {
        this.cDtm = cDtm;
    }

    public String getCLogRef() {
        return cLogRef;
    }

    public void setCLogRef(String cLogRef) {
        this.cLogRef = cLogRef;
    }

    public String getClass_() {
        return _class;
    }

    public void setClass_(String _class) {
        this._class = _class;
    }

    public int getFlags() {
        return flags;
    }

    public void setFlags(int flags) {
        this.flags = flags;
    }

    public int getSchVn() {
        return schVn;
    }

    public void setSchVn(int schVn) {
        this.schVn = schVn;
    }

    public String getUDtm() {
        return uDtm;
    }

    public void setUDtm(String uDtm) {
        this.uDtm = uDtm;
    }

    public String getULog() {
        return uLog;
    }

    public void setULog(String uLog) {
        this.uLog = uLog;
    }

    public String getULogRef() {
        return uLogRef;
    }

    public void setULogRef(String uLogRef) {
        this.uLogRef = uLogRef;
    }

    public int getVn() {
        return vn;
    }

    public void setVn(int vn) {
        this.vn = vn;
    }

    public int getAcctGroup() {
        return acctGroup;
    }

    public void setAcctGroup(int acctGroup) {
        this.acctGroup = acctGroup;
    }

    public String getAcctNbr() {
        return acctNbr;
    }

    public void setAcctNbr(String acctNbr) {
        this.acctNbr = acctNbr;
    }

    public AcctgSeg getAcctgSeg() {
        return acctgSeg;
    }

    public void setAcctgSeg(AcctgSeg acctgSeg) {
        this.acctgSeg = acctgSeg;
    }

    public int getAssetClass() {
        return assetClass;
    }

    public void setAssetClass(int assetClass) {
        this.assetClass = assetClass;
    }

    public double getAuthCrAmt() {
        return authCrAmt;
    }

    public void setAuthCrAmt(double authCrAmt) {
        this.authCrAmt = authCrAmt;
    }

    public double getBal() {
        return bal;
    }

    public void setBal(double bal) {
        this.bal = bal;
    }

    public String getCcyCode() {
        return ccyCode;
    }

    public void setCcyCode(String ccyCode) {
        this.ccyCode = ccyCode;
    }

    public double getCollectedBal() {
        return collectedBal;
    }

    public void setCollectedBal(double collectedBal) {
        this.collectedBal = collectedBal;
    }

    public String getFundExpDtm() {
        return fundExpDtm;
    }

    public void setFundExpDtm(String fundExpDtm) {
        this.fundExpDtm = fundExpDtm;
    }

    public int getGlCat() {
        return glCat;
    }

    public void setGlCat(int glCat) {
        this.glCat = glCat;
    }

    public String getGlSetCode() {
        return glSetCode;
    }

    public void setGlSetCode(String glSetCode) {
        this.glSetCode = glSetCode;
    }

    public String getNextPosnCalDtm() {
        return nextPosnCalDtm;
    }

    public void setNextPosnCalDtm(String nextPosnCalDtm) {
        this.nextPosnCalDtm = nextPosnCalDtm;
    }

    public String getOpenDtm() {
        return openDtm;
    }

    public void setOpenDtm(String openDtm) {
        this.openDtm = openDtm;
    }

    public String getPosnAcctNbr() {
        return posnAcctNbr;
    }

    public void setPosnAcctNbr(String posnAcctNbr) {
        this.posnAcctNbr = posnAcctNbr;
    }

    public String getPosnName() {
        return posnName;
    }

    public void setPosnName(String posnName) {
        this.posnName = posnName;
    }

    public int getPosnNbr() {
        return posnNbr;
    }

    public void setPosnNbr(int posnNbr) {
        this.posnNbr = posnNbr;
    }

    public PosnDepInt getPosnDepInt() {
        return posnDepInt;
    }

    public void setPosnDepInt(PosnDepInt posnDepInt) {
        this.posnDepInt = posnDepInt;
    }

    public PosnDepLimit getPosnDepLimit() {
        return posnDepLimit;
    }

    public void setPosnDepLimit(PosnDepLimit posnDepLimit) {
        this.posnDepLimit = posnDepLimit;
    }

    public PosnDepNsf getPosnDepNsf() {
        return posnDepNsf;
    }

    public void setPosnDepNsf(PosnDepNsf posnDepNsf) {
        this.posnDepNsf = posnDepNsf;
    }

    public String getProdName() {
        return prodName;
    }

    public void setProdName(String prodName) {
        this.prodName = prodName;
    }

    public SubBals getSubBals() {
        return subBals;
    }

    public void setSubBals(SubBals subBals) {
        this.subBals = subBals;
    }

    public int getSweepAvailBal() {
        return sweepAvailBal;
    }

    public void setSweepAvailBal(int sweepAvailBal) {
        this.sweepAvailBal = sweepAvailBal;
    }

    public String getTmZoneCode() {
        return tmZoneCode;
    }

    public void setTmZoneCode(String tmZoneCode) {
        this.tmZoneCode = tmZoneCode;
    }

}
