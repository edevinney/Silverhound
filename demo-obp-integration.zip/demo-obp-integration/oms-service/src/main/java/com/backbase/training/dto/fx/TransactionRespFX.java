package com.backbase.training.dto.fx;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class TransactionRespFX {

    private List<Data> data;

    public List<Data> getData() {
        return data;
    }

    public void setData(List<Data> data) {
        this.data = data;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Data {
        private Posn posn;
        private Trn trn;
        private TrnEntryX trnEntry;
        private TrnEntryAdd trnEntryAdd;

        public Posn getPosn() {
            return posn;
        }

        public void setPosn(Posn posn) {
            this.posn = posn;
        }

        public Trn getTrn() {
            return trn;
        }

        public void setTrn(Trn trn) {
            this.trn = trn;
        }

        public TrnEntryX getTrnEntry() {
            return trnEntry;
        }

        public void setTrnEntry(TrnEntryX trnEntry) {
            this.trnEntry = trnEntry;
        }

        public TrnEntryAdd getTrnEntryAdd() {
            return trnEntryAdd;
        }

        public void setTrnEntryAdd(TrnEntryAdd trnEntryAdd) {
            this.trnEntryAdd = trnEntryAdd;
        }

        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class Posn {
            /**
             * _Id : 4SXPd55H2f1Js----V1F-E7-
             * acctGroup : 1
             * acctNbr : 370710617864
             * assetClass : 1
             * bal : 100
             * nextPosnCalDtm : 2019-11-30T04:59:59Z
             * posnAcctNbr : 370710617864
             * posnName : LN
             * posnNbr : 1
             * tmZoneCode : usnyc
             * trnEntry : {"_Id":"4SXPd8vzMqgekV----1F-Go-","_Ix":0,"_cDtm":"2019-11-19T15:41:41.598838635Z"}
             * _asOfDtm : 2019-11-19T15:41:41.598838635Z
             * _uLog : 4SXPd8vzMqgekV--0V1F-EB-
             * _cDtm : 2019-11-19T15:41:40.568264368Z
             * _uDtm : 2019-11-19T15:41:41.598838635Z
             * _vn : 2
             * _flags : 0
             * _schVn : 0
             * _cLogRef : 4SXPd55ExvE9Z-----1F----
             * _uLogRef : 4SXPd8vxRpf-hF----1F----
             * _class : posn_ln
             */

            private String _Id;
            private int acctGroup;
            private String acctNbr;
            private int assetClass;
            private double bal;
            private String nextPosnCalDtm;
            private String posnAcctNbr;
            private String posnName;
            private int posnNbr;
            private String tmZoneCode;
            private TrnEntry trnEntry;
            private String _asOfDtm;
            private String _uLog;
            private String _cDtm;
            private String _uDtm;
            private int _vn;
            private int _flags;
            private int _schVn;
            private String _cLogRef;
            private String _uLogRef;
            private String _class;

            public String get_Id() {
                return _Id;
            }

            public void set_Id(String _Id) {
                this._Id = _Id;
            }

            public int getAcctGroup() {
                return acctGroup;
            }

            public void setAcctGroup(int acctGroup) {
                this.acctGroup = acctGroup;
            }

            public String getAcctNbr() {
                return acctNbr;
            }

            public void setAcctNbr(String acctNbr) {
                this.acctNbr = acctNbr;
            }

            public int getAssetClass() {
                return assetClass;
            }

            public void setAssetClass(int assetClass) {
                this.assetClass = assetClass;
            }

            public double getBal() {
                return bal;
            }

            public void setBal(double bal) {
                this.bal = bal;
            }

            public String getNextPosnCalDtm() {
                return nextPosnCalDtm;
            }

            public void setNextPosnCalDtm(String nextPosnCalDtm) {
                this.nextPosnCalDtm = nextPosnCalDtm;
            }

            public String getPosnAcctNbr() {
                return posnAcctNbr;
            }

            public void setPosnAcctNbr(String posnAcctNbr) {
                this.posnAcctNbr = posnAcctNbr;
            }

            public String getPosnName() {
                return posnName;
            }

            public void setPosnName(String posnName) {
                this.posnName = posnName;
            }

            public int getPosnNbr() {
                return posnNbr;
            }

            public void setPosnNbr(int posnNbr) {
                this.posnNbr = posnNbr;
            }

            public String getTmZoneCode() {
                return tmZoneCode;
            }

            public void setTmZoneCode(String tmZoneCode) {
                this.tmZoneCode = tmZoneCode;
            }

            public TrnEntry getTrnEntry() {
                return trnEntry;
            }

            public void setTrnEntry(TrnEntry trnEntry) {
                this.trnEntry = trnEntry;
            }

            public String get_asOfDtm() {
                return _asOfDtm;
            }

            public void set_asOfDtm(String _asOfDtm) {
                this._asOfDtm = _asOfDtm;
            }

            public String get_uLog() {
                return _uLog;
            }

            public void set_uLog(String _uLog) {
                this._uLog = _uLog;
            }

            public String get_cDtm() {
                return _cDtm;
            }

            public void set_cDtm(String _cDtm) {
                this._cDtm = _cDtm;
            }

            public String get_uDtm() {
                return _uDtm;
            }

            public void set_uDtm(String _uDtm) {
                this._uDtm = _uDtm;
            }

            public int get_vn() {
                return _vn;
            }

            public void set_vn(int _vn) {
                this._vn = _vn;
            }

            public int get_flags() {
                return _flags;
            }

            public void set_flags(int _flags) {
                this._flags = _flags;
            }

            public int get_schVn() {
                return _schVn;
            }

            public void set_schVn(int _schVn) {
                this._schVn = _schVn;
            }

            public String get_cLogRef() {
                return _cLogRef;
            }

            public void set_cLogRef(String _cLogRef) {
                this._cLogRef = _cLogRef;
            }

            public String get_uLogRef() {
                return _uLogRef;
            }

            public void set_uLogRef(String _uLogRef) {
                this._uLogRef = _uLogRef;
            }

            public String get_class() {
                return _class;
            }

            public void set_class(String _class) {
                this._class = _class;
            }

            @JsonIgnoreProperties(ignoreUnknown = true)
            public static class TrnEntry {
                /**
                 * _Id : 4SXPd8vzMqgekV----1F-Go-
                 * _Ix : 0
                 * _cDtm : 2019-11-19T15:41:41.598838635Z
                 */

                private String _Id;
                private int _Ix;
                private String _cDtm;

                public String get_Id() {
                    return _Id;
                }

                public void set_Id(String _Id) {
                    this._Id = _Id;
                }

                public int get_Ix() {
                    return _Ix;
                }

                public void set_Ix(int _Ix) {
                    this._Ix = _Ix;
                }

                public String get_cDtm() {
                    return _cDtm;
                }

                public void set_cDtm(String _cDtm) {
                    this._cDtm = _cDtm;
                }
            }
        }

        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class Trn {

            private String _Id;
            private String glJrnlDate;
            private int mode;
            private String _cDtm;
            private int _vn;
            private int _flags;
            private int _schVn;
            private String _cLogRef;

            public String get_Id() {
                return _Id;
            }

            public void set_Id(String _Id) {
                this._Id = _Id;
            }

            public String getGlJrnlDate() {
                return glJrnlDate;
            }

            public void setGlJrnlDate(String glJrnlDate) {
                this.glJrnlDate = glJrnlDate;
            }

            public int getMode() {
                return mode;
            }

            public void setMode(int mode) {
                this.mode = mode;
            }

            public String get_cDtm() {
                return _cDtm;
            }

            public void set_cDtm(String _cDtm) {
                this._cDtm = _cDtm;
            }

            public int get_vn() {
                return _vn;
            }

            public void set_vn(int _vn) {
                this._vn = _vn;
            }

            public int get_flags() {
                return _flags;
            }

            public void set_flags(int _flags) {
                this._flags = _flags;
            }

            public int get_schVn() {
                return _schVn;
            }

            public void set_schVn(int _schVn) {
                this._schVn = _schVn;
            }

            public String get_cLogRef() {
                return _cLogRef;
            }

            public void set_cLogRef(String _cLogRef) {
                this._cLogRef = _cLogRef;
            }
        }

        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class TrnEntryX {

            private String _Id;
            private String _Ix;
            private int acctGroup;
            private String acctNbr;
            private AcctgSeg acctgSeg;
            private int assetClass;
            private String ccyCode;
            private String glSetCode;
            private boolean isDr;
            private String posnAcctNbr;
            private String posnId;
            private int seqNbr;
            private double trnAmt;
            private String _cDtm;
            private int _vn;
            private int _flags;
            private int _schVn;
            private String _cLogRef;
            private String comment;

            public String getComment() {
                return comment;
            }

            public void setComment(String comment) {
                this.comment = comment;
            }

            public String get_Id() {
                return _Id;
            }

            public void set_Id(String _Id) {
                this._Id = _Id;
            }

            public String get_Ix() {
                return _Ix;
            }

            public void set_Ix(String _Ix) {
                this._Ix = _Ix;
            }

            public int getAcctGroup() {
                return acctGroup;
            }

            public void setAcctGroup(int acctGroup) {
                this.acctGroup = acctGroup;
            }

            public String getAcctNbr() {
                return acctNbr;
            }

            public void setAcctNbr(String acctNbr) {
                this.acctNbr = acctNbr;
            }

            public AcctgSeg getAcctgSeg() {
                return acctgSeg;
            }

            public void setAcctgSeg(AcctgSeg acctgSeg) {
                this.acctgSeg = acctgSeg;
            }

            public int getAssetClass() {
                return assetClass;
            }

            public void setAssetClass(int assetClass) {
                this.assetClass = assetClass;
            }

            public String getCcyCode() {
                return ccyCode;
            }

            public void setCcyCode(String ccyCode) {
                this.ccyCode = ccyCode;
            }

            public String getGlSetCode() {
                return glSetCode;
            }

            public void setGlSetCode(String glSetCode) {
                this.glSetCode = glSetCode;
            }

            public boolean getIsDr() {
                return isDr;
            }

            public void setIsDr(boolean dr) {
                isDr = dr;
            }

            public String getPosnAcctNbr() {
                return posnAcctNbr;
            }

            public void setPosnAcctNbr(String posnAcctNbr) {
                this.posnAcctNbr = posnAcctNbr;
            }

            public String getPosnId() {
                return posnId;
            }

            public void setPosnId(String posnId) {
                this.posnId = posnId;
            }

            public int getSeqNbr() {
                return seqNbr;
            }

            public void setSeqNbr(int seqNbr) {
                this.seqNbr = seqNbr;
            }

            public double getTrnAmt() {
                return trnAmt;
            }

            public void setTrnAmt(double trnAmt) {
                this.trnAmt = trnAmt;
            }

            public String get_cDtm() {
                return _cDtm;
            }

            public void set_cDtm(String _cDtm) {
                this._cDtm = _cDtm;
            }

            public int get_vn() {
                return _vn;
            }

            public void set_vn(int _vn) {
                this._vn = _vn;
            }

            public int get_flags() {
                return _flags;
            }

            public void set_flags(int _flags) {
                this._flags = _flags;
            }

            public int get_schVn() {
                return _schVn;
            }

            public void set_schVn(int _schVn) {
                this._schVn = _schVn;
            }

            public String get_cLogRef() {
                return _cLogRef;
            }

            public void set_cLogRef(String _cLogRef) {
                this._cLogRef = _cLogRef;
            }

            @JsonIgnoreProperties(ignoreUnknown = true)
            public static class AcctgSeg {
                String deptId;
                String vertical;

                public String getVertical() {
                    return vertical;
                }

                public void setVertical(String vertical) {
                    this.vertical = vertical;
                }

                public String getDeptId() {
                    return deptId;
                }

                public void setDeptId(String deptId) {
                    this.deptId = deptId;
                }
            }
        }

        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class TrnEntryAdd {
        }
    }
}


