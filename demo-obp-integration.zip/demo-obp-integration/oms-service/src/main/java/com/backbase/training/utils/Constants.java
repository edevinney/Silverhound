package com.backbase.training.utils;

import org.springframework.stereotype.Component;

@Component
public class Constants {

    public static final String DIRECT_GET = "direct:/oms/post";
    public static final String DIRECT_POST = "direct:/loan/post";

    public static final String BB_FUNCTION_CONTACTS = "1005";
    public static final String BB_FUNCTION_PAYMENTS_SEPA_CT = "1002";
    public static final String BB_FUNCTION_PAYMENTS_SEPA_CT_INTRA = "1043";
    public static final String BB_FUNCTION_PAYMENTS_INTRA = "1015";
    public static final String BB_FUNCTION_PAYMENTS_US_DOMESTIC_WIRE = "1017";
    public static final String BB_FUNCTION_PAYMENTS_US_FOREIGN_WIRE = "1018";
    public static final String BB_FUNCTION_PAYMENTS_US_DOMESTIC_WIRE_INTRA = "1044";
    public static final String BB_FUNCTION_PAYMENTS_US_FOREIGN_WIRE_INTRA = "1045";
    public static final String BB_FUNCTION_TRANSACTIONS = "1003";
    public static final String BB_FUNCTION_PRODUCT_SUMMARY = "1006";
    public static final String PRODUCER_COMPONENT = "http4";
    public static final String PRIVILEGE_VIEW = "view";
    public static final String PRIVILEGE_CREATE = "create";
    public static final String PRIVILEGE_EDIT = "edit";
    public static final String PRIVILEGE_DELETE = "delete";
    public static final String PRIVILEGE_APPROVE = "approve";
    public static final String PRIVILEGE_CANCEL = "cancel";
    public static final String LOG_SETTINGS = "log:INFO?showBody=true&showHeaders=true";
    /*
    mysql> select * from arrangement_state;
+----+-------------------+----------+----------------+
| id | external_state_id | state    | description    |
+----+-------------------+----------+----------------+
|  1 | Active            | Active   | Active state   |
|  2 | Inactive          | Inactive | Inactive state |
|  3 | Closed            | Closed   | Closed state   |
+----+-------------------+----------+----------------+
     */
    public static final int ARRANGEMENT_STATE_CLOSED = 3;


    public static final String CORE_PREFIX_OBP = "O-";
    public static final String CORE_PREFIX_FINXACT = "F-";
}
