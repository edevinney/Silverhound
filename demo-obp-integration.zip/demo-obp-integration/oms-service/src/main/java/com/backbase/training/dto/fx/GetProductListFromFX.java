package com.backbase.training.dto.fx;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@NoArgsConstructor
@Data
@Builder
@AllArgsConstructor
public class GetProductListFromFX {

    private double limit;
    private String next;
    private List<DataBean> data;

    @NoArgsConstructor
    @Data
    @Builder
    @AllArgsConstructor
    public static class DataBean {
        private String avlStartDtm;
        private String ccyCode;
        private String desc;
        private int glCat;
        private String glSetCode;
        private String ifxAcctType;
        private boolean isRegD;
        private String name;
        private String posnClass;
        private String prodGroup;
        private String prodSubType;
        private String prodType;
        private String _cDtm;
        private int _vn;
        private int _schVn;
        private String _cLog;
        private List<ComponentsBean> components;

        @NoArgsConstructor
        @Data
        @Builder
        @AllArgsConstructor
        public static class ComponentsBean {
            private String componentClass;
            private String componentName;
            private int version;
        }
    }
}
