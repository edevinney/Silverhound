package com.backbase.training.sockets;

import lombok.extern.slf4j.Slf4j;
import lombok.val;
import net.jodah.failsafe.Execution;
import net.jodah.failsafe.RetryPolicy;
import org.apache.commons.codec.binary.Hex;
import org.apache.http.util.TextUtils;
import org.java_websocket.client.WebSocketClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import sun.security.provider.certpath.SunCertPathBuilderException;
import sun.security.validator.ValidatorException;

import javax.net.ssl.SSLHandshakeException;
import java.io.IOException;
import java.math.BigInteger;
import java.net.*;
import java.security.PublicKey;
import java.security.cert.X509Certificate;
import java.time.Duration;
import java.time.temporal.ChronoUnit;
import java.util.Timer;
import java.util.TimerTask;

@Slf4j
@Component
public class FinxactEventManager implements IWebSocketEventsListener {
    @Autowired
    private SocketAuthApiClient authApiClient;
    private static final String HOSTNAME = "127.0.0.1";
    private static final int PORT = 8888;
    @Value("${finxact.use_proxy:false}")
    private Boolean useProxyForFinxact;
    @Value("${finxact.sockets.socket_endpoint:}")
    private String finxactSocketEndpoint;
    @Value("${finxact.sockets.topics:}")
    private String[] topics;
    @Autowired
    private FxEventsProducer eventsProducer;

    private Execution failsafeExecution = null;
    private RetryPolicy<Object> retryPolicy;

    @Autowired
    public FinxactEventManager() {
        retryPolicy = new RetryPolicy<>()
                .handleResult("disconnected")
                .handleResult("error")
                .withBackoff(5, 30, ChronoUnit.SECONDS)
                .handle(Exception.class)
                .withMaxRetries(5);
        retryPolicy.onRetriesExceeded(e -> log.error("Failed to connect to Finxact Event Hub. Max retries exceeded."));
        resetExecutionPolicy();
    }

    public void startup() throws IOException, URISyntaxException {
        startConnection();
    }

    public void startConnection() throws IOException, URISyntaxException {
        String topicsString = "";
        for (String topic : topics) {
            boolean addPlus = !TextUtils.isEmpty(topicsString);
            if (addPlus) {
                topicsString += URLEncoder.encode(",", "UTF-8");
            }
            String encodedTopic = URLEncoder.encode(topic, "UTF-8");
            topicsString += encodedTopic;
        }

        try {
            String token = authApiClient.getFinxactWebSocketAuthToken();
            String websocketAddress = finxactSocketEndpoint + "?authtoken=" + token + "&topicBindings=" + topicsString;
            log.debug("Connecting to Finxact Events Hub: " + websocketAddress);
            URI socketUri = new URI(websocketAddress);
            WebSocketClient client = new FinxactWebsocketClient(socketUri, this.eventsProducer, this);
            if (useProxyForFinxact) {
                client.setProxy(new Proxy(Proxy.Type.HTTP, new InetSocketAddress(HOSTNAME, PORT)));
            }
            client.connect();
        } catch (URISyntaxException e) {
            e.printStackTrace();
            throw e;
        } catch (SSLHandshakeException e) {
            log.warn("Starting connection to FX Events failed with SSL error {}", e);
            val cause = e.getCause();
            if (cause != null && cause instanceof ValidatorException) {
                val validatorException = (ValidatorException) cause;
                val certificate = validatorException.getErrorCertificate();
                val errorType = validatorException.getErrorCertificate();
                if (certificate != null) {
                    this.dumpCertificate(certificate);
                } else {
                    log.warn("Validator exception certificate is null");
                }
                log.warn("Validator exception type is {}", errorType);
                val innerCause = validatorException.getCause();
                if (innerCause != null && innerCause instanceof SunCertPathBuilderException) {
                    SunCertPathBuilderException certPathBuilderException = (SunCertPathBuilderException) innerCause;
                    if (certPathBuilderException != null) {
                        log.warn("SunCertPathBuilderException AdjacencyList is {}", certPathBuilderException.getAdjacencyList());
                    }
                }
            }
            if (failsafeExecution.canRetryFor("error")) {
                scheduleRetry(failsafeExecution.getWaitTime());
            }
        } catch (Exception e) {
            log.warn("Starting connection to FX Events failed {}", e);
            if (failsafeExecution.canRetryFor("error")) {
                scheduleRetry(failsafeExecution.getWaitTime());
            }
        }

    }

    private void dumpCertificate(X509Certificate t) {
        log.warn("Invalid certificate information below");
        log.warn("Invalid certificate version {} and serial number {}", t.getVersion(), t.getSerialNumber().toString(16));
        log.warn("Invalid certificate subject {} and issuer {}", t.getSubjectDN(), t.getIssuerDN());
        log.warn("Invalid certificate not before {} and not after {}", t.getNotBefore(), t.getNotAfter());
        log.warn("Invalid certificate signature alg {}", t.getSigAlgName());
        byte[] sig = t.getSignature();
        log.warn("Invalid certificate signature {}", new BigInteger(sig).toString(16));
        PublicKey pk = t.getPublicKey();
        byte[] pkenc = pk.getEncoded();
        log.warn("Invalid certificate public key {}", Hex.encodeHexString(pkenc));
    }

    @Override
    public void onDisconnected(int code, String reason, boolean remote) {
        log.warn("WebSocket was disconnected with code {} and reason [{}], isRemote: {}", code, reason, remote);

        if (failsafeExecution.canRetryFor("disconnected")) {
            scheduleRetry(failsafeExecution.getWaitTime());
        }
    }

    @Override
    public void onConnected() {
        resetExecutionPolicy();
    }

    private void resetExecutionPolicy() {
        if (failsafeExecution != null) {
            log.debug("FS Current execution is completed");
            failsafeExecution = null;
        }
        log.debug("FS Setting up a new execution");
        failsafeExecution = new Execution(retryPolicy);
    }

    private void scheduleRetry(Duration delay) {
        log.warn("Scheduling retry in {} ms", delay.toMillis());

        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                try {
                    startup();
                } catch (IOException | URISyntaxException e) {
                    e.printStackTrace();
                }
            }
        }, delay.toMillis());
    }
}
