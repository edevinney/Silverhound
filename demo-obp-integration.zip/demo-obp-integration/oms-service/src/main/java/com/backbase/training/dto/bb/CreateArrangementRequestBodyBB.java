package com.backbase.training.dto.bb;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@NoArgsConstructor
@Data
@Builder
@AllArgsConstructor
public class CreateArrangementRequestBodyBB {

    private String id;
    private String productId;
    private String name;
    private String alias;
    private double bookedBalance;
    private double availableBalance;
    private double creditLimit;
    private String IBAN;
    private String BBAN;
    private String currency;
    private boolean externalTransferAllowed;
    private boolean urgentTransferAllowed;
    private double accruedInterest;
    private String number;
    private double principalAmount;
    private double currentInvestmentValue;
    private String BIC;
    private String bankBranchCode;
    private List<String> legalEntityIds;
}
