package com.backbase.training.routes;

import com.backbase.onboarding.rest.spec.v1.onboarding.OnboardingPostRequestBody;
import com.backbase.onboarding.rest.spec.v1.onboarding.OnboardingPostResponseBody;
import com.backbase.pandp.arrangement.listener.client.v2.arrangement.PandpArrangementArrangementsClient;
import com.backbase.pandp.arrangement.listener.client.v2.products.PandpArrangementProductsClient;
import com.backbase.pandp.arrangement.query.listener.client.v2.products.PandpArrangementQueryProductsClient;
import com.backbase.pandp.arrangement.query.rest.spec.v2.products.ProductItemQ;
import com.backbase.pandp.arrangement.rest.spec.v2.arrangement.ArrangementsPostRequestBody;
import com.backbase.pandp.arrangement.rest.spec.v2.arrangement.ArrangementsPostResponseBody;
import com.backbase.pandp.arrangement.rest.spec.v2.products.ProductsPostRequestBody;
import com.backbase.presentation.accessgroup.event.spec.v1.DataGroupBase;
import com.backbase.presentation.accessgroup.listener.client.v2.accessgroups.datagroups.PresentationAccessgroupDataGroupsClient;
import com.backbase.presentation.accessgroup.listener.client.v2.accessgroups.functiongroups.PresentationAccessgroupFunctionGroupsClient;
import com.backbase.presentation.accessgroup.listener.client.v2.accessgroups.serviceagreements.PresentationAccessgroupServiceAgreementClient;
import com.backbase.presentation.accessgroup.listener.client.v2.accessgroups.users.PresentationAccessgroupUsersClient;
import com.backbase.presentation.accessgroup.rest.spec.v2.accessgroups.PresentationIdentifier;
import com.backbase.presentation.accessgroup.rest.spec.v2.accessgroups.datagroups.DataGroupsPostResponseBody;
import com.backbase.presentation.accessgroup.rest.spec.v2.accessgroups.functiongroups.FunctionGroupBase;
import com.backbase.presentation.accessgroup.rest.spec.v2.accessgroups.functiongroups.FunctionGroupsPostResponseBody;
import com.backbase.presentation.accessgroup.rest.spec.v2.accessgroups.serviceagreements.ServiceAgreementPutRequestBody;
import com.backbase.presentation.accessgroup.rest.spec.v2.accessgroups.serviceagreements.Status;
import com.backbase.presentation.accessgroup.rest.spec.v2.accessgroups.users.PresentationAssignUserPermissions;
import com.backbase.presentation.accessgroup.rest.spec.v2.accessgroups.users.PresentationFunctionGroupDataGroup;
import com.backbase.presentation.legalentity.listener.client.v2.legalentities.PresentationLegalentityLegalEntitiesClient;
import com.backbase.presentation.legalentity.rest.spec.v2.legalentities.MasterServiceAgreementGetResponseBody;
import com.backbase.training.dto.bb.CreateLegalEntityRequestBodyBB;
import com.backbase.training.dto.bb.CreateLegalEntityResponseBB;
import com.backbase.training.dto.bb.CreateUserRequestBodyBB;
import com.backbase.training.dto.bb.CreateUserResponseBodyBB;
import com.backbase.training.dto.fx.CreateCustomerRequestBodyFX;
import com.backbase.training.dto.fx.CreateCustomerResponseBodyFX;
import com.backbase.training.dto.fx.CreateSavingAccountRequestBodyFX;
import com.backbase.training.dto.fx.CreateSavingAccountResponseBodyFX;
import com.backbase.training.multicore.IBankCoreAccountInformation;
import com.backbase.training.multicore.SecondCoreConnector;
import com.backbase.training.obp.OBPApiService;
import com.backbase.training.obp.OBPUserMapper;
import com.backbase.training.services.BalanceService;
import com.backbase.training.utils.*;
import com.google.gson.JsonSyntaxException;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.apache.camel.Exchange;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.http.common.HttpOperationFailedException;
import org.apache.http.util.TextUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import javax.ws.rs.HttpMethod;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.*;

import static com.backbase.training.utils.Constants.*;


@Slf4j
@Component
public class OnBoardingRoute extends RouteBuilder {

    private String legalEntityExternalIdForBB = "";
    private String customerGroupIdForBB = "";
    private String xsrfToken = "";
    private String externalServiceAgreementId = "";
    private String userExternalId = "";
    private String fullName = "";
    private String accountNumber = "";
    private BigDecimal serviceBranchId;
    private BigDecimal rankId;
    private BigDecimal payGradeId;
    private BigDecimal statusId;

    private OnboardingPostRequestBody onBoardingWidgetRequestBody = new OnboardingPostRequestBody();
    private CreateSavingAccountResponseBodyFX createSavingAccountResponseBodyFX;
    private ResponseEntity<ArrangementsPostResponseBody> arrangementsPostResponseBodyResponseEntity;
    private ResponseEntity<FunctionGroupsPostResponseBody> functionGroupsPostResponseBodyResponseEntity;
    private ResponseEntity<DataGroupsPostResponseBody> dataGroupsPostResponseBodyResponseEntity;
    private ResponseEntity<MasterServiceAgreementGetResponseBody> masterServiceAgreementByExternalLegalEntity;

    private List<ArrangementsPostResponseBody> secondCoreCreatedAccounts;
    private final LogMessageHandler logMessageHandler;
    private final Configurator config;
    private final AccountNumberGenerator accountNumberGenerator;
    private final PandpArrangementArrangementsClient arrangementsClient;
    private final PandpArrangementQueryProductsClient pandpArrangementQueryProductsClient;
    private final PandpArrangementProductsClient pandpArrangementProductsClient;
    private final ProductSupplier productSupplier;
    private final RandomNumbersGenerator randomNumbersGenerator;
    private final UserExternalIdSupplier userExternalIdSupplier;
    private final PermissionSupplier permissionSupplier;
    private final PresentationAccessgroupFunctionGroupsClient functionGroupsClient;
    private final PresentationAccessgroupUsersClient accessGroupUsersClient;
    private final PresentationAccessgroupDataGroupsClient dataGroupsClient;
    private final PresentationLegalentityLegalEntitiesClient legalEntityClient;
    private final PresentationAccessgroupServiceAgreementClient serviceAgreementClient;
    private final BalanceService balanceService;
    private final RequestDataSupplier requestDataSupplier;

    @Autowired
    public OnBoardingRoute(
            LogMessageHandler logMessageHandler,
            PresentationAccessgroupUsersClient accessGroupUsersClient,
            PandpArrangementArrangementsClient arrangementsClient,
            PandpArrangementQueryProductsClient pandpArrangementQueryProductsClient,
            PandpArrangementProductsClient pandpArrangementProductsClient,
            ProductSupplier productSupplier,
            RandomNumbersGenerator randomNumbersGenerator,
            UserExternalIdSupplier userExternalIdSupplier,
            PermissionSupplier permissionSupplier,
            PresentationAccessgroupFunctionGroupsClient functionGroupsClient,
            PresentationAccessgroupDataGroupsClient dataGroupsClient,
            PresentationLegalentityLegalEntitiesClient legalEntityClient,
            PresentationAccessgroupServiceAgreementClient serviceAgreementClient,
            BalanceService balanceService,
            RequestDataSupplier requestDataSupplier,
            Configurator config,
            AccountNumberGenerator accountNumberGenerator) {
        this.logMessageHandler = logMessageHandler;
        this.accessGroupUsersClient = accessGroupUsersClient;
        this.arrangementsClient = arrangementsClient;
        this.pandpArrangementQueryProductsClient = pandpArrangementQueryProductsClient;
        this.pandpArrangementProductsClient = pandpArrangementProductsClient;
        this.productSupplier = productSupplier;
        this.randomNumbersGenerator = randomNumbersGenerator;
        this.userExternalIdSupplier = userExternalIdSupplier;
        this.permissionSupplier = permissionSupplier;
        this.functionGroupsClient = functionGroupsClient;
        this.dataGroupsClient = dataGroupsClient;
        this.legalEntityClient = legalEntityClient;
        this.serviceAgreementClient = serviceAgreementClient;
        this.balanceService = balanceService;
        this.requestDataSupplier = requestDataSupplier;
        this.config = config;
        this.accountNumberGenerator = accountNumberGenerator;
    }

    public void configure() {

        if (config.useProxyForFinxact) {
            getContext().setGlobalOptions(new HashMap<String, String>() {{
                put("http.proxyHost", config.finxactProxyHost);
                put("http.proxyPort", config.finxactProxyPort);
            }});
        }
        restConfiguration().producerComponent(PRODUCER_COMPONENT);

        onException(HttpOperationFailedException.class)
                .process(exchange -> {
                    final val e = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, HttpOperationFailedException.class);
                    final val responseBody = e.getResponseBody();
                    log.info(responseBody);
                });


        from(DIRECT_GET)
                .id("create_customer_fx")
                .process(exchange -> {
                    onBoardingWidgetRequestBody = exchange.getIn().getBody(OnboardingPostRequestBody.class);
                    log.info("===> received incoming request with this body: " + logMessageHandler.toStringClassInSignature(onBoardingWidgetRequestBody));
                    fullName = onBoardingWidgetRequestBody.getFirstName() + " " + onBoardingWidgetRequestBody.getLastName();
                    serviceBranchId = onBoardingWidgetRequestBody.getServiceBranchId();
                    rankId = onBoardingWidgetRequestBody.getRankId();
                    payGradeId = onBoardingWidgetRequestBody.getPayGradeId();
                    statusId = onBoardingWidgetRequestBody.getStatusId();
                    requestDataSupplier.setHeadersFxRoute(exchange, HttpMethod.POST);
                    if (isPersonUSSvcMember()) {
                        exchange.getOut().setBody(Helper.Gson.toJson(buildCustomerUSSvcMember()));
                    } else {
                        exchange.getOut().setBody(Helper.Gson.toJson(buildCustomer()));
                    }
                    log.info("===> calling this url " + requestDataSupplier.getCustomerUrl());
                })
                .to(LOG_SETTINGS)
                .to(requestDataSupplier.getCustomerUrl())
                .process(exchange -> {
                    try {
                        CreateCustomerResponseBodyFX customerResponse = Helper.Gson.fromJson(exchange.getIn().getBody(String.class), CreateCustomerResponseBodyFX.class);
                        legalEntityExternalIdForBB = customerResponse.getCustomer().getCustomerId();
                        customerGroupIdForBB = customerResponse.getCustomer().getCustomerGroup();
                    } catch (JsonSyntaxException e) {
                        e.printStackTrace();
                    }
                })
                .to("direct:create_account_fx");


        from("direct:create_account_fx")
                .id("create_account_fx")
                .process(exchange -> {
                    requestDataSupplier.setHeadersFxRoute(exchange, HttpMethod.POST);
                    accountNumber = accountNumberGenerator.generateNewAccountNumber();
                    balanceService.getIgnoredArrangements().put(accountNumber, accountNumber);
                    exchange.getOut().setBody(Helper.Gson.toJson(buildCreateSavingAccountBody()));
                    log.info("===> calling this url " + requestDataSupplier.getAccountUrl());
                })
                .to(LOG_SETTINGS)
                .to(requestDataSupplier.getAccountUrl())
                .process(exchange -> createSavingAccountResponseBodyFX = Helper.Gson.fromJson(exchange.getIn().getBody(String.class), CreateSavingAccountResponseBodyFX.class))
                .to("direct:create_legal_entity_bb");


        from("direct:create_legal_entity_bb")
                .id("create_legal_entity_bb")
                .process(exchange -> {
                    setHeadersBB(exchange);
                    CreateLegalEntityRequestBodyBB build = CreateLegalEntityRequestBodyBB.builder()
                            .externalId(legalEntityExternalIdForBB)
                            .parentExternalId("MegaBank")
                            .name(fullName)
                            .type("CUSTOMER").build();
                    exchange.getOut().setBody(Helper.Gson.toJson(build));
                    log.info("===> calling this url " + "http://localhost:8086/legalentity-integration-service/v2/legalentities");
                })
                .to(LOG_SETTINGS)
                .to("http://localhost:8086/legalentity-integration-service/v2/legalentities")
                .process(exchange -> Helper.Gson.fromJson(exchange.getIn().getBody(String.class), CreateLegalEntityResponseBB.class))
                .to("direct:generate_new_user_id");

        from("direct:generate_new_user_id")
                .id("generate_new_user_id")
                .process(exchange -> {
                    setHeadersBB(exchange);
                    userExternalId = userExternalIdSupplier.getUserExternalId();
                    if (TextUtils.isEmpty(userExternalId)) {
                        log.info("The user id generation failed, verify the list of available user ids");
                    }
                    exchange.getOut().setBody(userExternalId);
                })
                .choice()
                .when().simple("${in.body} == null || ${in.body.trim()} == ''")
                .to("direct:response_to_front_failed")
                .otherwise()
                .to("direct:create_user_bb");


        from("direct:create_user_bb")
                .id("create_user_bb")
                .process(exchange -> {
                    setHeadersBB(exchange);
                    userExternalId = exchange.getIn().getBody().toString();
                    log.info("===> create_user_bb: onboarding user with userid = " + userExternalId);
                    CreateUserRequestBodyBB build = CreateUserRequestBodyBB.builder()
                            .externalId(userExternalId)
                            .fullName(fullName)
                            .legalEntityExternalId(legalEntityExternalIdForBB).build();
                    exchange.getOut().setBody(Helper.Gson.toJson(build));
                    log.info("===> calling this url " + "http://localhost:8086/user-integration-service/v2/users");
                })
                .to(LOG_SETTINGS)
                .to("http://localhost:8086/user-integration-service/v2/users")
                .process(exchange -> Helper.Gson.fromJson(exchange.getIn().getBody(String.class), CreateUserResponseBodyBB.class))
                .to("direct:create_product_bb");


        from("direct:create_product_bb")
                .id("create_product_bb")
                .process(exchange -> {
                    ResponseEntity<? extends List<ProductItemQ>> products = pandpArrangementQueryProductsClient.getProducts();
                    String acctNumber = createSavingAccountResponseBodyFX.getAcctPartyRels().get(0).getAcctNbr();

                    if (products.getBody() != null) {
                        List<ProductItemQ> body = products.getBody();
                        boolean onceCreated = false;

                        if (body.isEmpty()) {
                            createProduct(acctNumber);
                            onceCreated = true;
                        }

                        for (ProductItemQ productItemQ : body) {

                            if (productItemQ.getExternalProductKindId().equals("kind2")) {
                                onceCreated = true;
                                break;
                            }
                        }

                        if (!onceCreated) {
                            createProduct(acctNumber);
                        }
                    }
                })
                .to("direct:create_arrangement_bb");


        from("direct:create_arrangement_bb")
                .id("create_arrangement_bb")
                .process(exchange -> arrangementsPostResponseBodyResponseEntity = arrangementsClient.postArrangements(getArrangementsPostRequestBody(createSavingAccountResponseBodyFX)))
                .to("direct:secondcore_migrate");


        from("direct:secondcore_migrate")
                .id("secondcore_migrate")
                .process(exchange -> secondCoreCreatedAccounts = migrateAccountsFromSecondCore())
                .to("direct:get_service_agreement_details_bb");


        from("direct:get_service_agreement_details_bb")
                .id("get_service_agreement_details_bb")
                .process(exchange -> masterServiceAgreementByExternalLegalEntity = legalEntityClient.getMasterServiceAgreementByExternalLegalEntity(legalEntityExternalIdForBB))
                .to("direct:set_master_service_agreement_bb");


        from("direct:set_master_service_agreement_bb")
                .id("set_master_service_agreement_bb")
                .process(exchange -> serviceAgreementClient.putServiceAgreementItem(getServiceAgreementPutRequestBody(), Objects.requireNonNull(masterServiceAgreementByExternalLegalEntity.getBody()).getId()))
                .to("direct:create_data_group_for_msa_bb");


        from("direct:create_data_group_for_msa_bb")
                .id("create_data_group_for_msa_bb")
                .process(exchange -> dataGroupsPostResponseBodyResponseEntity = dataGroupsClient.postDataGroups(buildDataGroupBasePostRequestBody()))
                .to("direct:create_function_group_for_msa_bb");


        from("direct:create_function_group_for_msa_bb")
                .id("create_function_group_for_msa_bb")
                .process(exchange -> functionGroupsPostResponseBodyResponseEntity = functionGroupsClient.postFunctionGroups(buildFunctionGroupBasePostRequestBody()))
                .to("direct:assign_permission_bb");


        from("direct:assign_permission_bb")
                .id("assign_permission_bb")
                .process(exchange -> accessGroupUsersClient.putAssignUserPermissions(getPresentationAssignUserPermissions()))
                .to("direct:response_to_front");


        from("direct:authorisation_bb")
                .id("authorisation_bb")
                .process(exchange -> {
                    exchange.getOut().setHeader(Exchange.CONTENT_TYPE, "application/json");
                    exchange.getOut().setBody("{\"username\": \"admin\", \"password\": \"admin\"}");
                    log.info("===> calling this url " + "http://localhost:8080/gateway/api/auth/login");
                })
                .to(LOG_SETTINGS)
                .to("http://localhost:8080/gateway/api/auth/login")
                .process(exchange -> {
                    if (xsrfToken != null && exchange.getIn().getHeader("Set-Cookie", String.class) != null) {
                        xsrfToken = exchange.getIn().getHeader("Set-Cookie", String.class).substring(11, 47);
                    }
                });


        from("direct:response_to_front")
                .id("response_to_front")
                .process(exchange -> {
                    log.info(exchange.getIn().getBody(String.class));
                    exchange.getOut().setBody(new OnboardingPostResponseBody().withStatus("ok").withUserExternalId(userExternalId));
                    balanceService.getIgnoredArrangements().remove(accountNumber);
                });

        from("direct:response_to_front_failed")
                .id("response_to_front_failed")
                .process(exchange -> {
                    log.info(exchange.getIn().getBody(String.class));
                    exchange.getOut().setBody(new OnboardingPostResponseBody().withStatus("failed").withUserExternalId("N/A"));
                });
    }

    private ServiceAgreementPutRequestBody getServiceAgreementPutRequestBody() {
        return new ServiceAgreementPutRequestBody()
                .withName(fullName)
                .withDescription("Master Service Agreement")
                .withStatus(Status.ENABLED)
                .withExternalId(externalServiceAgreementId = "serviceAgreementId_" + randomNumbersGenerator.getTenDigitRandomNumberFromUUID());
    }

    private void createProduct(String acctNumber) {
        pandpArrangementProductsClient.postProducts(new ProductsPostRequestBody()
                .withExternalProductId(acctNumber)
                .withExternalProductTypeId(acctNumber)
                .withExternalProductKindId("kind2")
                .withProductKindName("Savings Account")
                .withProductTypeName("Savings Account"));
    }

    private List<PresentationAssignUserPermissions> getPresentationAssignUserPermissions() {
        return Collections.singletonList(
                new PresentationAssignUserPermissions()
                        .withExternalServiceAgreementId(externalServiceAgreementId)
                        .withExternalUserId(userExternalId)
                        .withFunctionGroupDataGroups(
                                Collections.singletonList(
                                        new PresentationFunctionGroupDataGroup()
                                                .withDataGroupIdentifiers(
                                                        Collections.singletonList(
                                                                new PresentationIdentifier()
                                                                        .withIdIdentifier(Objects.requireNonNull(dataGroupsPostResponseBodyResponseEntity.getBody()).getId())
                                                        )
                                                )
                                                .withFunctionGroupIdentifier(
                                                        new PresentationIdentifier()
                                                                .withIdIdentifier(Objects.requireNonNull(functionGroupsPostResponseBodyResponseEntity.getBody()).getId())
                                                )
                                )
                        )
        );
    }

    private DataGroupBase buildDataGroupBasePostRequestBody() {
        List<String> accountIds = new ArrayList<>();
        accountIds.add((arrangementsPostResponseBodyResponseEntity.getBody()).getId());
        secondCoreCreatedAccounts.forEach(acc -> {
            accountIds.add(acc.getId());
        });

        return new DataGroupBase()
                .withName("data_group_" + randomNumbersGenerator.getTenDigitRandomNumberFromUUID())
                .withDescription("data_group_description")
                .withExternalServiceAgreementId(externalServiceAgreementId)
                .withType("ARRANGEMENTS")
                .withItems(accountIds);
    }

    private FunctionGroupBase buildFunctionGroupBasePostRequestBody() {
        return new FunctionGroupBase()
                .withName("Viewer")
                .withDescription("This profile will control viewing")
                .withServiceAgreementId(Objects.requireNonNull(masterServiceAgreementByExternalLegalEntity.getBody()).getId())
                .withPermissions(permissionSupplier.getPermissionList());
    }

    private ArrangementsPostRequestBody getArrangementsPostRequestBody(CreateSavingAccountResponseBodyFX createSavingAccountResponseBodyFX) {
        String productId = productSupplier.getProductId(pandpArrangementQueryProductsClient, "kind2");
        String newSavingsNumber = createSavingAccountResponseBodyFX.getCreatedAccounts().get(0).getAcct_bk().getAcctNbr();
        String BBAN = newSavingsNumber;

        return new ArrangementsPostRequestBody()
                .withExternalArrangementId(newSavingsNumber)
                .withLegalEntityIds(Collections.singleton(createSavingAccountResponseBodyFX.getAcctPartyRels().get(0).getCustId()))
                .withProductId(productId)
                .withExternalProductId(createSavingAccountResponseBodyFX.getAcctPartyRels().get(0).getAcctNbr())
                .withName("Savings Account")
                .withAlias("SA")
                .withBookedBalance(BigDecimal.valueOf(0))
                .withAvailableBalance(BigDecimal.valueOf(0))
                .withIBAN(null)
                .withBBAN(BBAN)
                .withCurrency("USD")
                .withDebitAccount(true)
                .withCreditAccount(true)
                .withExternalTransferAllowed(true)
                .withUrgentTransferAllowed(false)
                .withAccruedInterest(BigDecimal.valueOf(0))
                .withPrincipalAmount(BigDecimal.valueOf(0))
                .withCurrentInvestmentValue(BigDecimal.valueOf(0));
    }

    private void setHeadersBB(Exchange exchange) {
        exchange.getOut().setHeaders(exchange.getIn().getHeaders());
        exchange.getOut().setHeader("X-XSRF-TOKEN", xsrfToken);
        exchange.getOut().setHeader(Exchange.HTTP_METHOD, "POST");
    }

    private boolean isPersonUSSvcMember() {
        return serviceBranchId != null && rankId != null && payGradeId != null && statusId != null;
    }

    private CreateCustomerRequestBodyFX buildCustomerUSSvcMember() {
        CreateCustomerRequestBodyFX createCustomerRequestBodyFX = buildCustomer();
        CreateCustomerRequestBodyFX.PartyPersonBean party_person = createCustomerRequestBodyFX.getParty_person();
        party_person.setParty_personUSSvcMember(
                CreateCustomerRequestBodyFX.PartyPersonBean.PartyPersonUSSvcMemberBean.builder()
                        .status(statusId.intValue())
                        .svcBranch(serviceBranchId.intValue())
                        .rank(rankId.intValue())
                        .payGrade(payGradeId.intValue())
                        .build());
        createCustomerRequestBodyFX.setParty_person(party_person);
        return createCustomerRequestBodyFX;
    }

    private CreateCustomerRequestBodyFX buildCustomer() {
        return CreateCustomerRequestBodyFX.builder()
                .party_person(
                        CreateCustomerRequestBodyFX.PartyPersonBean.builder()
                                .birthDate(onBoardingWidgetRequestBody.getDateOfBirth())
                                .firstName(onBoardingWidgetRequestBody.getFirstName())
                                .lastName(onBoardingWidgetRequestBody.getLastName())
                                .emails(
                                        Collections.singletonList(
                                                CreateCustomerRequestBodyFX.PartyPersonBean.EmailsBean.builder()
                                                        .emailType(1)
                                                        .data(onBoardingWidgetRequestBody.getEmail())
                                                        .build()
                                        )
                                )
                                .tin(onBoardingWidgetRequestBody.getSsn())
                                .build()
                )
                .addresses(
                        Collections.singletonList(
                                CreateCustomerRequestBodyFX.AddressesBean.builder()
                                        .street(onBoardingWidgetRequestBody.getAddress().getAddress())
                                        .region(onBoardingWidgetRequestBody.getAddress().getState())
                                        .city(onBoardingWidgetRequestBody.getAddress().getCity())
                                        .postCode(onBoardingWidgetRequestBody.getAddress().getZip())
                                        .addrType(1)
                                        .cntry("US")
                                        .build()
                        )
                )
                .customer(
                        CreateCustomerRequestBodyFX.CustomerBean.builder()
                                .customerGroup("2")
                                .customerId(randomNumbersGenerator.getTenDigitRandomNumberFromUUID())
                                .build()
                ).build();
    }

    private List<ArrangementsPostResponseBody> migrateAccountsFromSecondCore() {
        List<ArrangementsPostResponseBody> secondCoreAccounts = new ArrayList<>();
        try {
            SecondCoreConnector coreConnector = new SecondCoreConnector(new OBPUserMapper(), new OBPApiService());
            List<IBankCoreAccountInformation> existingOldAccounts = coreConnector.FetchCoreAccountsForUserWithKey(onBoardingWidgetRequestBody.getSsn(), userExternalId);
            existingOldAccounts.forEach(oldAccount -> {
                ResponseEntity<ArrangementsPostResponseBody> response = arrangementsClient.postArrangements(createRegisterOldAccountBody(oldAccount));
                if (response != null && response.getStatusCode().is2xxSuccessful()) {
                    secondCoreAccounts.add(response.getBody());
                }
            });
        }
        catch (Exception e){
            log.error(e.getMessage());
        }
        return secondCoreAccounts;
    }

    private ArrangementsPostRequestBody createRegisterOldAccountBody(IBankCoreAccountInformation accountInformation) {
        String productId = productSupplier.getProductId(pandpArrangementQueryProductsClient, "kind2");
        String newAccountNumber = accountInformation.getAccountNumber();
        Float balance = accountInformation.getBalance();
        return new ArrangementsPostRequestBody()
                .withExternalArrangementId(Constants.CORE_PREFIX_OBP + newAccountNumber)
                .withLegalEntityIds(Collections.singleton(createSavingAccountResponseBodyFX.getAcctPartyRels().get(0).getCustId()))
                .withProductId(productId)
                .withExternalProductId(productId)
                .withName(accountInformation.getName())
                .withAlias("SA")
                .withBookedBalance(BigDecimal.valueOf(balance))
                .withAvailableBalance(BigDecimal.valueOf(balance))
                .withIBAN(null)
                .withBBAN(newAccountNumber)
                .withCurrency(accountInformation.getCurrency())
                .withDebitAccount(true)
                .withCreditAccount(true)
                .withBankBranchCode(accountInformation.getBranchCode())
                .withExternalTransferAllowed(true)
                .withUrgentTransferAllowed(false)
                .withAccruedInterest(BigDecimal.valueOf(0))
                .withPrincipalAmount(BigDecimal.valueOf(balance))
                .withCurrentInvestmentValue(BigDecimal.valueOf(0));
    }


    private CreateSavingAccountRequestBodyFX buildCreateSavingAccountBody() {
        String pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
        String date = simpleDateFormat.format(new Date());

        return CreateSavingAccountRequestBodyFX.builder()
                .customer(
                        CreateSavingAccountRequestBodyFX.CustomerBean.builder()
                                .customerId(legalEntityExternalIdForBB)
                                .customerGroup(customerGroupIdForBB)
                                .build()
                )
                .newAccounts(
                        Collections.singletonList(
                                CreateSavingAccountRequestBodyFX.NewAccountsBean.builder()
                                        .Acct(
                                                CreateSavingAccountRequestBodyFX.NewAccountsBean.AcctBean.builder()
                                                        .acct_bk(
                                                                CreateSavingAccountRequestBodyFX.NewAccountsBean.AcctBean.AcctBkBean.builder()
                                                                        .acctNbr(accountNumber)
                                                                        .acctTitle(fullName)
                                                                        .desc("Personal Education Savings")
                                                                        .acctGroup(requestDataSupplier.getAccountGroup())
                                                                        .isBrokered(false)
                                                                        .openDtm(date)
                                                                        .stmtFreq("0MAE")
                                                                        .tmZoneCode("usnyc")
                                                                        .acctType("Single")
                                                                        .build()
                                                        )
                                                        .posn_depDtl(
                                                                Collections.singletonList(
                                                                        CreateSavingAccountRequestBodyFX.NewAccountsBean.AcctBean.PosnDepDtlBean.builder()
                                                                                .prodName("P2001")
                                                                                .posn_dep(CreateSavingAccountRequestBodyFX.NewAccountsBean.AcctBean.PosnDepDtlBean.PosnDepBean.builder()
                                                                                        .ccyCode("USD")
                                                                                        .acctgSeg(
                                                                                                CreateSavingAccountRequestBodyFX.NewAccountsBean.AcctBean.PosnDepDtlBean.PosnDepBean.AcctgSegBean.builder()
                                                                                                        .deptId("350")
                                                                                                        .vertical("01")
                                                                                                        .build()
                                                                                        ).build())
                                                                                .build())
                                                        )
                                                        .build())
                                        .acctPartyRel(
                                                CreateSavingAccountRequestBodyFX.NewAccountsBean.AcctPartyRelBean.builder()
                                                        .partyRelDesc("Primary")
                                                        .relType("1")
                                                        .build()
                                        )
                                        .build()))
                .build();
    }
}
