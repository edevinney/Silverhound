package com.backbase.training.dto.bb;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@NoArgsConstructor
@Data
@Builder
@AllArgsConstructor
public class CreateFunctionGroupForMasterServiceAgreementRequestBodyBB {

    private String name;
    private String description;
    private String externalServiceAgreementId;
    private List<PermissionsBean> permissions;

    @NoArgsConstructor
    @Data
    @Builder
    @AllArgsConstructor
    public static class PermissionsBean {
        private String functionId;
        private List<AssignedPrivilegesBean> assignedPrivileges;

        @NoArgsConstructor
        @Data
        @Builder
        @AllArgsConstructor
        public static class AssignedPrivilegesBean {
            private String privilege;
        }
    }
}
