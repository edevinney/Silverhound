
package com.backbase.training.obp.models;

@lombok.Data
public class AccountRouting {
    private String scheme;
    private String address;
}