package com.backbase.training.dto.fx;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@NoArgsConstructor
@Data
@Builder
@AllArgsConstructor
public class CreateSavingAccountRequestBodyFX {

    private CustomerBean customer;
    private List<NewAccountsBean> newAccounts;

    @NoArgsConstructor
    @Data
    @Builder
    @AllArgsConstructor
    public static class CustomerBean {
        private String customerId;
        private String customerGroup;
    }

    @NoArgsConstructor
    @Data
    @Builder
    @AllArgsConstructor
    public static class NewAccountsBean {
        private AcctBean Acct;
        private AcctPartyRelBean acctPartyRel;

        @NoArgsConstructor
        @Data
        @Builder
        @AllArgsConstructor
        public static class AcctBean {
            private AcctBkBean acct_bk;
            private List<PosnDepDtlBean> posn_depDtl;

            @NoArgsConstructor
            @Data
            @Builder
            @AllArgsConstructor
            public static class AcctBkBean {
                private String acctNbr;
                private String desc;
                private int acctGroup;
                private String openDtm;
                private String acctTitle;
                private boolean isBrokered;
                private String tmZoneCode;
                private String stmtFreq;
                private String acctType;
            }

            @NoArgsConstructor
            @Data
            @Builder
            @AllArgsConstructor
            public static class PosnDepDtlBean {
                private String prodName;
                private PosnDepBean posn_dep;

                @NoArgsConstructor
                @Data
                @Builder
                @AllArgsConstructor
                public static class PosnDepBean {
                    private String ccyCode;
                    private AcctgSegBean acctgSeg;

                    @NoArgsConstructor
                    @Data
                    @Builder
                    @AllArgsConstructor
                    public static class AcctgSegBean {
                        private String deptId;
                        private String vertical;
                    }
                }
            }
        }

        @NoArgsConstructor
        @Data
        @Builder
        @AllArgsConstructor
        public static class AcctPartyRelBean {
            private String relType;
            private String partyRelDesc;
        }
    }
}
