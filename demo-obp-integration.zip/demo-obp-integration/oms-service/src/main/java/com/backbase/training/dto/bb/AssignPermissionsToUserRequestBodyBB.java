package com.backbase.training.dto.bb;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@NoArgsConstructor
@Data
@Builder
@AllArgsConstructor
public class AssignPermissionsToUserRequestBodyBB {

    private String externalServiceAgreementId;
    private String externalUserId;
    private List<FunctionGroupDataGroupsBean> functionGroupDataGroups;

    @NoArgsConstructor
    @Data
    @Builder
    @AllArgsConstructor
    public static class FunctionGroupDataGroupsBean {
        private FunctionGroupIdentifierBean functionGroupIdentifier;
        private List<DataGroupIdentifiersBean> dataGroupIdentifiers;

        @NoArgsConstructor
        @Data
        @Builder
        @AllArgsConstructor
        public static class FunctionGroupIdentifierBean {
            private String idIdentifier;
        }

        @NoArgsConstructor
        @Data
        @Builder
        @AllArgsConstructor
        public static class DataGroupIdentifiersBean {
            private String idIdentifier;
        }
    }
}
