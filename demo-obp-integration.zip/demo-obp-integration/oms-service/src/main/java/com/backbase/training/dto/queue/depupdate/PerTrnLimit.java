
package com.backbase.training.dto.queue.depupdate;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class PerTrnLimit {

    @SerializedName("_Id")
    @Expose
    private String id;
    @SerializedName("_cDtm")
    @Expose
    private String cDtm;
    @SerializedName("_schVn")
    @Expose
    private int schVn;
    @SerializedName("_vn")
    @Expose
    private int vn;
    @SerializedName("name")
    @Expose
    private String name;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCDtm() {
        return cDtm;
    }

    public void setCDtm(String cDtm) {
        this.cDtm = cDtm;
    }

    public int getSchVn() {
        return schVn;
    }

    public void setSchVn(int schVn) {
        this.schVn = schVn;
    }

    public int getVn() {
        return vn;
    }

    public void setVn(int vn) {
        this.vn = vn;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
