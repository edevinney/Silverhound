
package com.backbase.training.dto.queue.lnupdate;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Dec5 {

    @SerializedName("accrInt")
    @Expose
    private double accrInt;

    public double getAccrInt() {
        return accrInt;
    }

    public void setAccrInt(double accrInt) {
        this.accrInt = accrInt;
    }

}