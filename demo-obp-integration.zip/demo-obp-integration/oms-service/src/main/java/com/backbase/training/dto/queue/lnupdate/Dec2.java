
package com.backbase.training.dto.queue.lnupdate;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Dec2 {

    @SerializedName("lateChrg")
    @Expose
    private double lateChrg;
    @SerializedName("lnFee")
    @Expose
    private double lnFee;

    public double getLateChrg() {
        return lateChrg;
    }

    public void setLateChrg(double lateChrg) {
        this.lateChrg = lateChrg;
    }

    public double getLnFee() {
        return lnFee;
    }

    public void setLnFee(int lnFee) {
        this.lnFee = lnFee;
    }

}
