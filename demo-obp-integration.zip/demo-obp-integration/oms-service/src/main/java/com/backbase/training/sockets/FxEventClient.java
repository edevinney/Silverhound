package com.backbase.training.sockets;

public  class FxEventClient{
    public String user_id;
    public String connection_id;
}
