package com.backbase.training.dto.queue.lnupdate;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class SubBals {

    @SerializedName("dec2")
    @Expose
    private Dec2 dec2;
    @SerializedName("dec5")
    @Expose
    private Dec5 dec5;

    public Dec2 getDec2() {
        return dec2;
    }

    public void setDec2(Dec2 dec2) {
        this.dec2 = dec2;
    }

    public Dec5 getDec5() {
        return dec5;
    }

    public void setDec5(Dec5 dec5) {
        this.dec5 = dec5;
    }

}