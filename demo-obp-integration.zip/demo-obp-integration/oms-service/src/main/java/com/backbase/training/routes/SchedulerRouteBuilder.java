package com.backbase.training.routes;

import com.backbase.training.services.BalanceService;
import com.backbase.training.services.TransactionService;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.ZoneId;

@Component
public class SchedulerRouteBuilder extends RouteBuilder {

    private String retrieveTransactionInterval = "10000";
    private String retrieveBalanceInterval = "10000";

    private final TransactionService transactionService;
    private final BalanceService balanceService;

    @Autowired
    public SchedulerRouteBuilder(TransactionService transactionService, BalanceService balanceService) {
        this.transactionService = transactionService;
        this.balanceService = balanceService;
    }

    @Override
    public void configure() {

//        from("scheduler://retrieveTransaction?timeUnit=MILLISECONDS&initialDelay=0&delay=" + retrieveTransactionInterval)
//                .id("transaction_scheduler")
//                .log(LoggingLevel.INFO, "===> Update transactions STARTED at {}", LocalDateTime.now().atZone(ZoneId.systemDefault()).toString())
//                .bean(transactionService, "retrieveTransaction")
//                .log(LoggingLevel.INFO, "===> Update transactions FINISHED at {}", LocalDateTime.now().atZone(ZoneId.systemDefault()).toString());
//
//        from("scheduler://retrieveBalance?timeUnit=MILLISECONDS&initialDelay=0&delay=" + retrieveBalanceInterval)
//                .id("balance_scheduler")
//                .log(LoggingLevel.INFO, "===> Update balances STARTED at {}", LocalDateTime.now().atZone(ZoneId.systemDefault()).toString())
//                .bean(balanceService, "updateAllBalances")
//                .log(LoggingLevel.INFO, "===> Update balances FINISHED at {}", LocalDateTime.now().atZone(ZoneId.systemDefault()).toString());
    }
}
