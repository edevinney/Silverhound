package com.backbase.training.dto.bb;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
@Builder
@AllArgsConstructor
public class CreateProductRequestBodyBB {

    private String id;
    private String productKindId;
    private String productKindName;
    private String productTypeId;
    private String productTypeName;
}
