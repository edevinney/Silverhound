package com.backbase.training.routes;

import com.backbase.loan_type.rest.spec.v1.loan.types.LoantypesGetResponseBody;
import com.backbase.training.dto.fx.GetProductListFromFX;
import com.backbase.training.utils.*;
import groovy.util.logging.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.http.common.HttpOperationFailedException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.ws.rs.HttpMethod;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

import static com.backbase.training.utils.Constants.*;

@Slf4j
@Component
public class LoanTypeRoute extends RouteBuilder {

    public static final String DIRECT_POST = "direct:/loan_type/post";

    private ConcurrentHashMap<String, String> productListFromFX = new ConcurrentHashMap<>();
    private GetProductListFromFX getProductListFromFX;

    @Value("${finxact.product.type}")
    private String productType = "";

    private final Configurator config;
    private final BodyAndHeadersRequestSupplier bodyAndHeadersRequestSupplier;
    private final RequestDataSupplier requestDataSupplier;

    public LoanTypeRoute(
            BodyAndHeadersRequestSupplier bodyAndHeadersRequestSupplier,
            RequestDataSupplier requestDataSupplier, Configurator config) {
        this.bodyAndHeadersRequestSupplier = bodyAndHeadersRequestSupplier;
        this.requestDataSupplier = requestDataSupplier;
        this.config = config;
    }

    @Override
    public void configure() {
        //TODO: move presets to utility class
        restConfiguration().producerComponent(PRODUCER_COMPONENT);
        if (config.useProxyForFinxact) {
            getContext().setGlobalOptions(new HashMap<String, String>() {{
                put("http.proxyHost", config.finxactProxyHost);
                put("http.proxyPort", config.finxactProxyPort);
            }});
        }

        onException(HttpOperationFailedException.class)
                .process(exchange -> {
                    final HttpOperationFailedException e = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, HttpOperationFailedException.class);
                    final String responseBody = e.getResponseBody();
                    log.info(responseBody);
                });


        from(DIRECT_POST)
                .id("request_to_finxact_to_get_loan_type")
                .log(LoggingLevel.INFO, "===> Update product type STARTED at {}", LocalDateTime.now().atZone(ZoneId.systemDefault()).toString())
                .process(exchange -> {
                    String currentDate = getCurrentDateInStringFormat();
                    bodyAndHeadersRequestSupplier.setHeadersFX(exchange, HttpMethod.GET);
                    exchange.getOut().setHeader("productType", productType);
                    exchange.getOut().setHeader("currentDate", currentDate);
                    log.info("===> calling this url "
                            .concat(requestDataSupplier.getProductTypes())
                            .concat("?prodType=")
                            .concat(productType)
                            .concat("&filter.q=avlStartDtm<'")
                            .concat(currentDate)
                            .concat("'and(avlEndDtm is null or avlEndDtm>='")
                            .concat(currentDate)
                            .concat("')")
                    );
                })
                .to("log:INFO?showBody=true&showHeaders=true")
                .routingSlip(simple(requestDataSupplier.getProductTypes().concat("?prodType=${header.productType}&filter.q=avlStartDtm<'${header.currentDate}'and(avlEndDtm is null or avlEndDtm>='${header.currentDate}')")))
                .process(exchange -> {
                    getProductListFromFX = Helper.Gson.fromJson(exchange.getIn().getBody(String.class), GetProductListFromFX.class);
                    List<GetProductListFromFX.DataBean> productList = getProductListFromFX.getData();
                    if (!productList.isEmpty()) {
                        productList.forEach(dataBean -> productListFromFX.put(dataBean.getName(), dataBean.getDesc()));
                    }
                })
                .to("direct:response_to_front_loan_type");


        from("direct:response_to_front_loan_type")
                .id("response_to_front_loan_type")
                .process(exchange -> {
                    List<LoantypesGetResponseBody> responseBodyList = new ArrayList<>();
                    if (!productListFromFX.isEmpty()) {
                        productListFromFX.forEach((loanId, loanDescription) ->
                                responseBodyList.add(new LoantypesGetResponseBody().withId(loanId).withTitle(loanDescription))
                        );
                    }
                    productListFromFX.clear();
                    exchange.getOut().setBody(responseBodyList);
                })
                .log(LoggingLevel.INFO, "===> Update product type FINISHED at {}", LocalDateTime.now().atZone(ZoneId.systemDefault()).toString());
    }

    private String getCurrentDateInStringFormat() {
        return new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'").format(new Date());
    }
}
