package com.backbase.training.sockets;

import com.backbase.pandp.arrangement.listener.client.v2.arrangement.PandpArrangementArrangementsClient;
import com.backbase.pandp.arrangement.listener.client.v2.arrangementstate.PandpArrangementArrangementStateClient;
import com.backbase.pandp.arrangement.query.listener.client.v2.arrangements.GetArrangementsQueryParameters;
import com.backbase.pandp.arrangement.query.listener.client.v2.arrangements.PandpArrangementQueryArrangementsClient;
import com.backbase.pandp.arrangement.query.rest.spec.v2.arrangements.ArrangementItemQ;
import com.backbase.pandp.arrangement.query.rest.spec.v2.arrangements.ArrangementsPageQ;
import com.backbase.pandp.arrangement.rest.spec.v2.arrangement.ArrangementsPutRequestBody;
import com.backbase.presentation.transaction.listener.client.v2.transactions.PresentationTransactionTransactionsClient;
import com.backbase.presentation.transaction.rest.spec.v2.transactions.TransactionsPostRequestBody;
import com.backbase.rest.spec.common.types.Currency;
import com.backbase.training.dto.queue.acct.AcctCreateMsg;
import com.backbase.training.dto.queue.acctupdate.AcctUpdate;
import com.backbase.training.dto.queue.depupdate.DepBalanceUpdate;
import com.backbase.training.dto.queue.lnupdate.LoanBalanceUpdate;
import com.backbase.training.dto.queue.trn.TrnCreateMsg;
import com.backbase.training.dto.queue.trn.TrnEntry;
import com.backbase.training.utils.Constants;
import com.backbase.training.utils.Helper;
import com.google.gson.Gson;
import lombok.extern.slf4j.Slf4j;
import lombok.var;
import org.apache.http.util.TextUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.MathContext;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Component
public class FinxactQueueProcessor implements IQueueMessageProcessor {
    @Value("${finxact.use_proxy}")
    private Boolean useProxyForFinxact = false;
    @Value("${finxact.sockets.socket_endpoint}")
    private String finxactSocketEndpoint = "";
    @Value("${finxact.sockets.topics:}")
    private String[] topics;
    @Autowired
    private FxEventsConsumer eventsConsumer;

    private final PresentationTransactionTransactionsClient transactionsClient;
    private final PandpArrangementQueryArrangementsClient arrangementsClient;
    private final PandpArrangementArrangementsClient arrangementsUpdateClient;

    @Autowired
    public FinxactQueueProcessor(PresentationTransactionTransactionsClient transactionsClient,
                                 PandpArrangementQueryArrangementsClient arrangementsClient,
                                 PandpArrangementArrangementsClient arrangementsUpdateClient) {
        this.transactionsClient = transactionsClient;
        this.arrangementsClient = arrangementsClient;
        this.arrangementsUpdateClient = arrangementsUpdateClient;
    }

    public void startup() {
        eventsConsumer.setMessageListener(this);
        eventsConsumer.start();
        log.debug("FinxactQueueProcessor started and ready");
    }

    @Override
    public void onNewJsonMessage(String json) {
        //deserialize
        FxEventBase overview = FxEventBase.fromJson(json);
        if (overview != null) {
            //filter
            if ("model.v1.trn.create".equals(overview.event)) {
                this.processTransactionEvent(json, overview);
            } else if ("model.v1.acct_bk.create".equals(overview.event)) {
                this.processAccountCreateEvent(json, overview);
            } else if ("model.v1.acct_bk.update".equals(overview.event)) {
                this.processAccountUpdateEvent(json, overview);
            } else if ("model.v1.posn_dep.update".equals(overview.event)) {
                this.processDepBalanceUpdate(json, overview);
            } else if ("model.v1.posn_ln.update".equals(overview.event)) {
                this.processLoanBalanceUpdate(json, overview);
            } else if ("core.v1.acct_bk.Closed".equals(overview.event)) {
                this.handleClosedAccount(json, overview);
            }
        }
    }

    private void handleClosedAccount(String json, FxEventBase overview) {
    }

    private void processDepBalanceUpdate(String json, FxEventBase overview) {
        DepBalanceUpdate savingsUpdate = Helper.Gson.fromJson(json, DepBalanceUpdate.class);
        String accountNumber = savingsUpdate.getMsg().getData().getAcctNbr();
        Double newBalance = savingsUpdate.getMsg().getData().getBal();
        this.updateAccountBalance(accountNumber, newBalance);
    }

    private void processLoanBalanceUpdate(String json, FxEventBase overview) {
        LoanBalanceUpdate loanBalanceUpdate = Helper.Gson.fromJson(json, LoanBalanceUpdate.class);
        String accountNumber = loanBalanceUpdate.getMsg().getData().getAcctNbr();
        Double newBalance = loanBalanceUpdate.getMsg().getData().getBal();
        this.updateAccountBalance(accountNumber, newBalance);
        /*
            Loan:
            New message received from FX: {"id":"648fa4d4-9ae7-4cb1-9699-2047ef6ddbe4","event":"model.v1.posn_ln.update","client":{"user_id":"BB_Integration_Client","connection_id":"0d4d7809-45a5-43c9-9848-e1f54c42761a"},"msg":{"correlationID":"4TcWVucFPjGdF-----1F----","eventKey":"model.v1.posn_ln.update","eventDtm":"2020-01-15T18:04:28.724483546Z","resourceURI":"","version":0,"data":{"_Id":"4TcT0-C1IYHPqV---V9F-E7-","_attch":"posn_lnFee|posn_lnRepay|posn_lnInt|","_cDtm":"2020-01-15T17:00:21.930159668Z","_cLogRef":"4TcT0-C-RjgAS-----9F----","_class":"posn_ln","_flags":0,"_schVn":0,"_uDtm":"2020-01-15T18:04:28.724483546Z","_uLog":"4TcWVucGSSe6R---0V1F-EB-","_uLogRef":"4TcWVucFPjGdF-----1F----","_vn":4,"acctGroup":1,"acctNbr":"952461384590","acctgSeg":{"deptId":"350","vertical":"01"},"assetClass":1,"bal":987.67,"ccyCode":"USD","crLimit":1000,"firstDisbmtDtm":"2020-01-15T17:00:23.495908Z","glCat":1,"glSetCode":"loansGlSet","maturityDtm":"2020-07-15T03:59:59Z","nextPosnCalDtm":"2020-01-31T04:59:59Z","openDtm":"2020-01-15T17:00:21.930159Z","posnAcctNbr":"952461384590","posnName":"LOC","posnNbr":1,"prodName":"LOC","subBals":{"dec2":{"lateChrg":0,"lnFee":0},"dec5":{"accrInt":0}},"tmZoneCode":"usnyc"},"journal":{"blist":["4TcT3aoUlcTV3-----DF----",3,988.67],"plist":["_uLogRef","_vn","bal"]}}}
            Savings
            New message received from FX: {"id":"2057382d-68ea-4c31-a97d-6628796f3c07","event":"model.v1.posn_dep.update","client":{"user_id":"BB_Integration_Client","connection_id":"0d4d7809-45a5-43c9-9848-e1f54c42761a"},"msg":{"correlationID":"4TcWVucFPjGdF-----1F----","eventKey":"model.v1.posn_dep.update","eventDtm":"2020-01-15T18:04:28.724483546Z","resourceURI":"","version":0,"data":{"_Id":"4TNvd5sNDOXLFV---V5F-Co-","_attch":"posn_depLimit|posn_depInt|","_cDtm":"2020-01-03T01:18:16.847694232Z","_cLogRef":"4TNvd5sMDWeQC-----5F----","_class":"posn_dep","_flags":0,"_schVn":0,"_uDtm":"2020-01-15T18:04:28.724483546Z","_uLog":"4TcWVucGSSe6R---0-1F-Cs-","_uLogRef":"4TcWVucFPjGdF-----1F----","_vn":4,"acctGroup":1,"acctNbr":"645203194781","acctgSeg":{"deptId":"350","vertical":"01"},"assetClass":1,"authCrAmt":0,"bal":987.67,"ccyCode":"USD","collectedBal":0,"fundExpDtm":"2020-02-02T04:59:59Z","glCat":2,"glSetCode":"PerSavless100k","nextPosnCalDtm":"2020-02-01T04:59:59Z","openDtm":"2020-01-03T01:18:16Z","posnAcctNbr":"645203194781","posnName":"P200101","posnNbr":1,"posn_depInt":{"_Id":"4TNvd5sNDOXLFV---V5F-Co-","_cDtm":"2020-01-03T01:18:16.847694232Z","_cLogRef":"4TNvd5sMDWeQC-----5F----","_flags":0,"_schVn":0,"_uDtm":"2020-01-03T01:18:16.847694232Z","_uLog":"4TNvd5sNDOXLFV--1F5F-DB-","_uLogRef":"4TNvd5sMDWeQC-----5F----","_vn":1,"accrCalcTm":"23:59:59","accrIntBal":0,"accumToDtm":"2020-01-03T01:18:16.847694Z","apy":1.042,"apye":0,"balOpt":1,"calcMthd":1,"componentName":"Savings_Interest","daysNxtPost":16,"disbmtOpt":1,"index":{"indexName":"Bank_Savings_Rate"},"is1099Exempt":false,"isCompoundDly":true,"isWthFed":false,"isWthNra":false,"isWthState":false,"negAccrIntBal":0,"nextPostDtm":"2020-02-01T04:59:59Z","nomRate":1.6,"postFreq":"0MAE","sumIntPd":0,"version":1},"posn_depLimit":{"_Id":"4TNvd5sNDOXLFV---V5F-Co-","_cDtm":"2020-01-03T01:18:16.847694232Z","_cLogRef":"4TNvd5sMDWeQC-----5F----","_flags":0,"_schVn":0,"_vn":0,"accumTrnLimits":[{"_Id":"4MNdNzNnZgZ------81F0k--","_cDtm":"2019-01-02T22:43:51.357420233Z","_schVn":0,"_vn":0,"crAmt":10000,"name":"RDC Limits Personal","period":"P1M","statGroup":"RDC_Limits","violationAct":1},{"_Id":"4MNdNzNnQu3------81F0k--","_cDtm":"2019-01-02T22:43:51.357411233Z","_schVn":0,"_vn":0,"definedBy":1,"drCnt":6,"name":"Reg D Limits","period":"P1M","statGroup":"Reg_D_Counter","violationAct":1}],"componentName":"Savings_Limits_Personal","perTrnLimits":[{"_Id":"4MNdNzNmfko------81F7F--","_cDtm":"2019-01-02T22:43:51.357361933Z","_schVn":0,"_vn":0,"name":"ACH Limit"}],"restrictCr":false,"restrictCrFundExp":false,"restrictDr":false,"version":1},"posn_depNsf":{"_Id":"4TNvd5sNDOXLFV---V5F-Co-","_cDtm":"2020-01-03T01:18:16.847694232Z","isOptIn":false},"prodName":"P2001","subBals":{"dec2":{"avlInt":0,"depFee":0,"negBal":0,"penalty":0,"recurInc":0,"wthFed":0,"wthNra":0,"wthState":0},"dec5":{"accrInt":0,"negAccr":0}},"sweepAvailBal":0,"tmZoneCode":"usnyc"},"journal":{"blist":["4TcT3aoUlcTV3-----DF----",3,988.67],"plist":["_uLogRef","_vn","bal"]}}}
         */
    }

    private void updateAccountBalance(String accountNumber, Double balance) {
        BigDecimal newBalance = new BigDecimal(balance, MathContext.DECIMAL64);
        String[] externalId = new String[]{accountNumber};
        ResponseEntity<ArrangementsPageQ> response = arrangementsClient.getArrangements(new GetArrangementsQueryParameters().withExternalArrangementIds(externalId));
        if (response.getStatusCode().is2xxSuccessful()) {
            if (response.getBody().getArrangements().size() == 0) {
                log.warn("Cannot find an arrangement by external Id " + accountNumber + " to update");
            } else {
                var arrangement = response.getBody().getArrangements().get(0);
                if (newBalance.compareTo(arrangement.getAvailableBalance()) == 0) {
                    log.warn("Skipping balance sync for " + arrangement.getExternalArrangementId() + ", reason: same balance " + newBalance.toString());
                } else {
                    updateArrangementBalanceInBackbase(arrangement, newBalance);
                }
            }
        }
    }

    private static ArrangementsPutRequestBody convertToUpdateArrangement(ArrangementItemQ arrangement) {
        ArrangementsPutRequestBody requestBody = new ArrangementsPutRequestBody();
        requestBody.setId(arrangement.getId());
        requestBody.setBookedBalance(arrangement.getBookedBalance());
        requestBody.setAvailableBalance(arrangement.getAvailableBalance());
        requestBody.setProductId(arrangement.getProduct().getId());
        requestBody.setCurrency("USD");
        requestBody.setAlias(arrangement.getAlias());
        requestBody.setName(arrangement.getName());
        requestBody.setBankAlias(arrangement.getBankAlias());
        requestBody.setBBAN(arrangement.getBBAN());
        String existingIBAN = arrangement.getIBAN();
        if (existingIBAN != null && !existingIBAN.isEmpty())
            requestBody.setIBAN(existingIBAN);
        requestBody.setExternalTransferAllowed(arrangement.getExternalTransferAllowed());
        requestBody.setUrgentTransferAllowed(arrangement.getUrgentTransferAllowed());
        requestBody.setAccruedInterest(arrangement.getAccruedInterest());
        requestBody.setPrincipalAmount(arrangement.getPrincipalAmount());
        requestBody.setCurrentInvestmentValue(arrangement.getCurrentInvestmentValue());
        requestBody.setCreditAccount(arrangement.getCreditAccount());
        requestBody.setDebitAccount(arrangement.getDebitAccount());
        return requestBody;
    }

    private void updateArrangementBalanceInBackbase(ArrangementItemQ arrangementItemQ, BigDecimal newBalance) {
        BigDecimal currentBalance = arrangementItemQ.getAvailableBalance();
        var arrangement = convertToUpdateArrangement(arrangementItemQ);
        arrangement.setBookedBalance(newBalance);
        arrangement.setAvailableBalance(newBalance);
        var response = arrangementsUpdateClient.putArrangements(arrangement, arrangementItemQ.getId());
        if (response.getStatusCode().is2xxSuccessful()) {
            log.info("===> Balance for this arrangement " + arrangementItemQ.getExternalArrangementId() + " was updated from " + currentBalance.toString() + " to " + newBalance);
        } else {
            log.warn("The balance for arrangement " + arrangementItemQ.getExternalArrangementId() + " was not updated, status code: " + response.getStatusCodeValue());
        }
    }

    private void processAccountUpdateEvent(String json, FxEventBase overview) {
        AcctUpdate acctCreate = Helper.Gson.fromJson(json, AcctUpdate.class);
        String accountNumber = acctCreate.getMsg().getData().getAcctNbr();
        var accountCloseDate = acctCreate.getMsg().getData().getCloseDtm();
        var closeReason = acctCreate.getMsg().getData().getCloseReason();
        if (closeReason > 0 && !TextUtils.isEmpty(accountCloseDate)) {
            //account closed - let's close it in BB
            String[] externalId = new String[]{accountNumber};
            ResponseEntity<ArrangementsPageQ> response = arrangementsClient.getArrangements(new GetArrangementsQueryParameters().withExternalArrangementIds(externalId));
            if (response.getStatusCode().is2xxSuccessful()) {
                if (response.getBody().getArrangements().size() == 0) {
                    log.warn("Cannot find an arrangement by external Id " + accountNumber + " to close");
                } else {
                    var arrangement = response.getBody().getArrangements().get(0);
                    var arrangementUpdate = convertToUpdateArrangement(arrangement);
                    arrangementUpdate.setStateId(Constants.ARRANGEMENT_STATE_CLOSED);
                    arrangementsUpdateClient.putArrangements(arrangementUpdate, arrangement.getId());
                    log.info("===> Closed this arrangement in BB " + arrangement.getExternalArrangementId());
                }
            }
        }
        // example when closing an account (closed)
        /*
            {"id":"7e881cd8-7736-4fcf-aebe-9f8b9a2342d9","event":"model.v1.acct_bk.update","client":{"user_id":"BB_Integration_Client","connection_id":"05061ea8-1956-4c94-9668-dc116d44bcbe"},"msg":{"correlationID":"4Tdl9Imyk07eF-----DF----","eventKey":"model.v1.acct_bk.update","eventDtm":"2020-01-16T18:24:01.273590125Z","resourceURI":"","version":0,"data":{"_cDtm":"2020-01-02T23:28:52.294982438Z","_cLog":"4TNpf-025mPMX-----DF--V-","_cLogRef":"4TNpf-016OiXTV----DF----","_class":"acct_bk","_flags":0,"_schVn":0,"_uDtm":"2020-01-16T18:24:01.273590125Z","_uLog":"4Tdl9ImzwLquvV---kDF--V-","_uLogRef":"4Tdl9Imyk07eF-----DF----","_vn":1,"acctGroup":1,"acctNbr":"462454658874","acctTitle":"Alex Sorokoletov2020","baseCcy":"USD","closeDtm":"2020-01-16T18:24:01.273590125Z","closeReason":5,"desc":"Personal Education Savings","isBrokered":false,"isElectronicStmt":true,"isPaperStmt":false,"isWthFed":false,"isWthNra":false,"isWthState":false,"nextStmtDtm":"2020-02-01T04:59:59Z","openDtm":"2020-01-02T23:28:52Z","stmtFreq":"0MAE","tmZoneCode":"usnyc"},"journal":{"blist":[null,null],"plist":["closeDtm","closeReason"]}}}

            {"id":"32637616-e9dd-4af5-ad72-c3d5f4b8e424","event":"model.v1.acct_bk.update","client":{"user_id":"BB_Integration_Client","connection_id":"d40d5311-336c-40f8-9dae-93f1e4fa839e"},"msg":{"correlationID":"4Tdlqg0EzZ46RV----1F----","eventKey":"model.v1.acct_bk.update","eventDtm":"2020-01-16T18:36:43.690166315Z","resourceURI":"","version":0,"data":{"_cDtm":"2020-01-02T23:59:20.955193286Z","_cLog":"4TNrKRIbWwOczV----DF--V-","_cLogRef":"4TNrKRIa5NgVD-----DF----","_class":"acct_bk","_flags":0,"_schVn":0,"_uDtm":"2020-01-16T18:36:43.690166315Z","_uLog":"4Tdlqg0Ge1h1E----k1F--V-","_uLogRef":"4Tdlqg0EzZ46RV----1F----","_vn":1,"acctGroup":1,"acctNbr":"750755282324","acctTitle":"Alex Sorokoletov2020","baseCcy":"USD","closeDtm":"2020-01-16T18:36:43.690166315Z","closeReason":1,"desc":"Personal Education Savings","isBrokered":false,"isElectronicStmt":true,"isPaperStmt":false,"isWthFed":false,"isWthNra":false,"isWthState":false,"nextStmtDtm":"2020-02-01T04:59:59Z","openDtm":"2020-01-02T23:59:20Z","stmtFreq":"0MAE","tmZoneCode":"usnyc"},"journal":{"blist":[null,null],"plist":["closeDtm","closeReason"]}}}
         */
    }

    private void processAccountCreateEvent(String json, FxEventBase overview) {
        AcctCreateMsg acctCreate = Helper.Gson.fromJson(json, AcctCreateMsg.class);
        String newAccontNumber = acctCreate.getMsg().getData().getAcctNbr();
        String newAccountTitle = acctCreate.getMsg().getData().getAcctTitle();
        //noop since we onboard accounts using our API. This is for future (when accounts created outside of the system)
    }

    private void processTransactionEvent(String json, FxEventBase overview) {
        TrnCreateMsg trnCreate = Helper.Gson.fromJson(json, TrnCreateMsg.class);
        String transactionId = trnCreate.getMsg().getData().getId();
        Double amount = trnCreate.getMsg().getData().getEntries().get(0).getTrnAmt();
        List<String> accounts = trnCreate.getMsg().getData().getEntries().parallelStream()
                .map(t -> t.getPosnAcctNbr())
                .collect(Collectors.toList());
        String[] externalIds = accounts.toArray(new String[0]);
        ResponseEntity<ArrangementsPageQ> response = arrangementsClient.getArrangements(new GetArrangementsQueryParameters().withExternalArrangementIds(externalIds));
        if (response.getStatusCode().is2xxSuccessful()) {
            List<ArrangementItemQ> arrangements = response.getBody().getArrangements();
            List<TransactionsPostRequestBody> transactions = new ArrayList<TransactionsPostRequestBody>();
            for (TrnEntry trnEntry : trnCreate.getMsg().getData().getEntries()) {
                String accountNumber = trnEntry.getPosnAcctNbr();
                Optional<ArrangementItemQ> arrangementItem = arrangements.parallelStream().filter(a -> accountNumber.equals(a.getExternalArrangementId())).findAny();
                if (arrangementItem.isPresent()) {
                    try {
                        transactions.add(this.mapTransactionEntryToTransaction(trnEntry, arrangementItem.get()));
                    } catch (ParseException e) {
                        log.error("Error mapping FX transaction to BB {}", e);
                    }
                } else {
                    log.warn("Could not locate 1 account in BB for that transaction - ignoring");
                }
            }
            if (transactions.size() > 0) {
                var response2 = transactionsClient.postTransactions(transactions);
                boolean success = response2.getStatusCode().is2xxSuccessful();
                if (success) {
                    log.info("Posted  transactions to BB: " + transactions.size());
                } else {
                    log.warn("Posting transactions to BB failed", response2.getStatusCodeValue());
                }
            }
        } else {
            log.warn("Could not locate accounts in BB for that transaction - ignoring");
        }
    }

    private TransactionsPostRequestBody mapTransactionEntryToTransaction(TrnEntry entry, ArrangementItemQ arrangement) throws ParseException {
        String dt = entry.getCDtm().substring(0, 19) + "Z";
        TimeZone tz = TimeZone.getTimeZone("UTC");
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
        df.setTimeZone(tz);
        Date date = df.parse(dt);

        TransactionsPostRequestBody trn = new TransactionsPostRequestBody();
        BigDecimal amt = new BigDecimal(entry.getTrnAmt());
        com.backbase.rest.spec.common.types.Currency amount = new Currency();
        amount.setAmount(amt);
        amount.setCurrencyCode("USD");
        String description = entry.getComment();
        description = description == null ? "-" : description;

        trn.withArrangementId(arrangement.getId())
                .withExternalArrangementId(arrangement.getExternalArrangementId())
                .withExternalId(entry.getId().concat(arrangement.getExternalArrangementId()))
                .withDescription(description)
                .withType("SEPA CT")
                .withTypeGroup("Payment")
                .withTransactionAmountCurrency(amount)
                .withBookingDate(date)
                .withInstructedAmountCurrency(amount)
                .withCreditDebitIndicator(creditDebitIndicator(entry));
        return trn;
    }

    private TransactionsPostRequestBody.CreditDebitIndicator creditDebitIndicator(TrnEntry entry) {
        if (entry.isIsDr()) {
            return TransactionsPostRequestBody.CreditDebitIndicator.DBIT;
        } else {
            return TransactionsPostRequestBody.CreditDebitIndicator.CRDT;
        }
    }
}
