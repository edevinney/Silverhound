package com.backbase.service.auth.configuration;

import java.util.HashMap;
import java.util.Map;

/**
 * Base class for LDAP properties.
 *
 * @author Davor Sauer
 */
public class BaseLdapFilterProperties {

    /**
     * The base search path for the query.
     */
    private String base;

    /**
     * The filter format string
     */
    private String filter;

    /**
     * LDAP attribute which we want to obtain.
     */
    private String attribute;

    /**
     * Map value of {@link #attribute} to another value.
     */
    private Map<String, String> mapAttributeValue = new HashMap<>();

    public String getBase() {
        return base;
    }

    public void setBase(String base) {
        this.base = base;
    }

    public String getFilter() {
        return filter;
    }

    public void setFilter(String filter) {
        this.filter = filter;
    }

    public String getAttribute() {
        return attribute;
    }

    public void setAttribute(String attribute) {
        this.attribute = attribute;
    }

    public Map<String, String> getMapAttributeValue() {
        return mapAttributeValue;
    }

}
