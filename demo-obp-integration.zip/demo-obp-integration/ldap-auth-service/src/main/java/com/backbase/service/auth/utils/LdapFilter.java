package com.backbase.service.auth.utils;

import com.backbase.buildingblocks.logging.api.Logger;
import com.backbase.buildingblocks.logging.api.LoggerFactory;
import com.backbase.service.auth.configuration.LdapProperties;
import org.springframework.ldap.core.AttributesMapper;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.query.LdapQuery;
import org.springframework.ldap.query.LdapQueryBuilder;
import org.springframework.util.StringUtils;

import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import static com.backbase.service.auth.logging.Warnings.LDAP_QUERY_LOOKUP;

/**
 * LDAP filter for querying data based on given criteria.
 *
 * @see LdapProperties
 */
public class LdapFilter {

    private static final Logger logger = LoggerFactory.getLogger(LdapFilter.class);

    private LdapTemplate ldapTemplate;

    private Map<String, String> mapAttributeValue;

    /**
     * Create filter which will be executed on {@code ldapTemplate},
     * and map result regarding given mapping {@code mapAttributeValue}.
     *
     * @param ldapTemplate      Used LDAP template on which {@link LdapQuery} will be execute.
     * @param mapAttributeValue Mapping used to transform expected data from LDAP into given {@code mapAttributeValue}
     */
    public LdapFilter(LdapTemplate ldapTemplate, Map<String, String> mapAttributeValue) {
        this.ldapTemplate = ldapTemplate;
        this.mapAttributeValue = mapAttributeValue;
    }

    /**
     * Execute LDAP query.
     *
     * @param base          the base search path for the query
     * @param filter        the filter format string
     * @param filterValue   the parameters that will be used for building the final filter
     * @param attributeName the LDAP attribute which will be collected to return,
     *                      and which values will be replaced based on {@link #mapAttributeValue}.
     * @return {@code Set}
     */
    public Set<String> query(String base, String filter, String filterValue, String attributeName) {
        return query(base, filter, filterValue, attributeName, true);
    }

    /**
     * Execute LDAP query.
     *
     * @param base          the base search path for the query
     * @param filter        the filter format string
     * @param filterValue   the parameters that will be used for building the final filter
     * @param attributeName the LDAP attribute which will be collected to return,
     *                      and which values will be replaced based on {@link #mapAttributeValue}.
     * @param required      define if LDAP data must exist or not. If LDAP data doesn't exists, empty Set will be returned.
     * @return {@code Set}
     */
    public Set<String> query(String base, String filter, String filterValue, String attributeName, boolean required) {
        if (StringUtils.isEmpty(filter)) {
            throw new IllegalArgumentException("LDAP query filter field can't be empty");
        }

        if (StringUtils.isEmpty(filterValue) || StringUtils.isEmpty(attributeName)) {
            return Collections.EMPTY_SET;
        }

        LdapQuery query = createQuery(base, filter, filterValue);
        List<String> queryResult;
        try {
            queryResult = ldapTemplate.search(query, new AttributesMapper<String>() {
                @Override
                public String mapFromAttributes(Attributes attributes) throws NamingException {
                    return getAttributeValue(attributes, attributeName);
                }
            });
        } catch (RuntimeException e) {
            if (required) {
                throw e;
            } else {
                logger.warn(LDAP_QUERY_LOOKUP, new Object[] {base, filter, filterValue});
                queryResult = Collections.emptyList();
            }
        }

        if (queryResult == null || queryResult.isEmpty()) {
            return Collections.emptySet();
        }

        return queryResult.stream().filter(value -> StringUtils.hasText(value)).collect(Collectors.toSet());
    }


    private LdapQuery createQuery(String base, String filter, String filterValue) {
        logger.trace("Creating LDAP query with base:'{}', filter:'{}', filterValue:'{}'", base, filter, filterValue);
        LdapQueryBuilder queryBuilder = LdapQueryBuilder.query();
        if (StringUtils.hasText(base)) {
            queryBuilder.base(base);
        }

        return queryBuilder.filter(filter, filterValue);
    }

    /**
     * Get the {@code attributeName} value, and convert the value if it exists in {@link #mapAttributeValue}.
     *
     * @param attributes    LDAP object attributes.
     * @param attributeName the name of the attribute for which we want to get the value.
     * @return {@code String}
     * @throws NamingException
     */
    private String getAttributeValue(Attributes attributes, String attributeName) throws NamingException {
        if (attributes == null) {
            return null;
        }

        Attribute attribute = attributes.get(attributeName);
        Object attributeValue = attribute.get();

        if (attributeValue == null) {
            return null;
        }

        String value = attributeValue.toString();
        if (StringUtils.isEmpty(value)) {
            return null;
        }

        if (mapAttributeValue != null && mapAttributeValue.containsKey(value)) {
            String newValue = mapAttributeValue.get(value);
            logger.trace("Mapping LDAP value '{}' to '{}'", value, newValue);
            return newValue;
        } else {
            return value;
        }
    }
}
