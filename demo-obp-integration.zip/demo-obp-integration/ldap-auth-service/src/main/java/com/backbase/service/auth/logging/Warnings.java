package com.backbase.service.auth.logging;

import com.backbase.buildingblocks.logging.api.LogEventBuilder;
import com.backbase.buildingblocks.logging.api.WarnLogEvent;

public final class Warnings {

    private Warnings() { }

    public static final WarnLogEvent CANNOT_USE_LDAP =
            LogEventBuilder.warn(1,
                    "Can't use LDAP for authentication",
                    "Check the LDAP configuration for Authentication service with LDAP");


    public static final WarnLogEvent CANNOT_CREATE_LDAP_CONTEXT =
            LogEventBuilder.warn(2,
                    "Can't create LDAP context. LDAP url: {}, ldif: {}",
                    "Check the LDAP configuration for Authentication service with LDAP");

    public static final WarnLogEvent CANNOT_READ_MANIFEST =
            LogEventBuilder.warn(3,
                    "Can't read MANIFEST file to get build information",
                    "MANIFEST.MF is not available");

    public static final WarnLogEvent LDAP_QUERY_LOOKUP =
            LogEventBuilder.warn(4,
                    "Can't perform LDAP query with base: {}, filter: {}, filterValue: {}",
                    "Verify LDAP configuration");

}