package com.backbase.service.auth.impl;

import com.backbase.buildingblocks.jwt.external.ExternalJwtTenantMapper;
import org.springframework.security.core.Authentication;

import javax.servlet.http.HttpServletRequest;
import java.util.Optional;

/**
 * Map tenant ID from the given {@link Authentication}.
 */
public class ExternalJwtTenantMapperImpl implements ExternalJwtTenantMapper {

    @Override
    public Optional<String> tenantId(Authentication authentication, HttpServletRequest request) {
        return Optional.ofNullable(authentication)
                .map(Authentication::getPrincipal)
                .filter(CustomUserDetails.class::isInstance)
                .map(CustomUserDetails.class::cast)
                .map(CustomUserDetails::getTenantId);
    }
}
