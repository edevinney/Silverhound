package com.backbase.service.auth.impl;

import com.backbase.buildingblocks.jwt.external.ExternalJwtMapper;
import com.backbase.buildingblocks.jwt.external.token.ExternalJwt;
import com.backbase.buildingblocks.jwt.external.token.ExternalJwtClaimsSet;
import org.springframework.security.core.Authentication;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.StringJoiner;

/**
 * Map {@link CustomUserDetails} to the {@link ExternalJwt}.
 *
 * <ol>
 * <li>It will map user groups {@link CustomUserDetails#getGroups()}
 * to {@link ExternalJwt} under {@link #GROUP_CLAIM} claim name.</li>
 * <li>It will transform user groups to ROLEs and add them to External JWT</li>
 * </ol>
 *
 */
public class CustomExternalJwtMapper implements ExternalJwtMapper {

    /**
     * Custom JWT claim for demo purposes
     */
    private static final String DEMO_CLAIM = "demo";

    /**
     * External JWT claim for the user groups.
     */
    private static final String GROUP_CLAIM = "grp";


    /**
     * Prefix used to define groups as roles.
     */
    private static final String GROUP_PREFIX = "ROLE_group_";

    @Override
    public Optional<ExternalJwtClaimsSet> claimSet(Authentication authentication) {
        if (authentication == null || !(authentication.getPrincipal() instanceof CustomUserDetails)) {
            return Optional.empty();
        }

        Map<String, Object> additionalClaims = getGroupClaims((CustomUserDetails) authentication.getPrincipal());

        // Put demo claim to the External JWT
        additionalClaims.put(DEMO_CLAIM, "dummy_value");

        ExternalJwtClaimsSet claimsSet = new ExternalJwtClaimsSet(additionalClaims);

        return Optional.of(claimsSet);
    }

    @Override
    public void updateAuthorities(Set<String> authorities, Authentication authentication) {
        if (authorities != null && authentication != null && authentication.getPrincipal() instanceof CustomUserDetails) {
            CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
            Collection<String> groupRoles = getGroupClaim(userDetails.getGroups(), GROUP_PREFIX);
            authorities.addAll(groupRoles);
        }
    }

    private Map<String, Object> getGroupClaims(CustomUserDetails userDetails) {
        Map<String, Object> claims = new HashMap<>();
        Collection<String> groups = getGroupClaim(userDetails.getGroups(), "");

        if (!groups.isEmpty()) {
            claims.put(GROUP_CLAIM, groups);
        }

        return claims;
    }

    /**
     * Get list of the groups prepared to store them into the Json Web Token claims.
     *
     * @param groups the groups which will be converted to string, together with the group roles.
     * @param prefix the prefix which will be added to the group name.
     * @return {@link Collection<String>}
     */
    private Collection<String> getGroupClaim(Collection<CustomUserGroup> groups, String prefix) {
        if (groups == null || groups.isEmpty()) {
            return Collections.EMPTY_LIST;
        }

        Collection<String> tokenGroups = new ArrayList<>();
        for (CustomUserGroup userGroup : groups) {
            StringBuilder group = new StringBuilder(prefix);
            group.append(userGroup.getName());
            group.append("(");
            group.append(inlineGroupRoles(userGroup.getRoles()));
            group.append(")");

            tokenGroups.add(group.toString());
        }

        return tokenGroups;
    }

    private String inlineGroupRoles(Collection<String> roles) {
        StringJoiner groupRoles = new StringJoiner(",");
        roles.forEach(role -> groupRoles.add(role));

        return groupRoles.toString();
    }

}
