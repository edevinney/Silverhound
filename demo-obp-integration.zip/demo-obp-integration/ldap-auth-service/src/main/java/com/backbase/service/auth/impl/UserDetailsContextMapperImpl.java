package com.backbase.service.auth.impl;

import com.backbase.service.auth.configuration.BaseLdapFilterProperties;
import com.backbase.service.auth.configuration.LdapUserFilterProperties;
import com.backbase.service.auth.utils.LdapFilter;
import org.springframework.ldap.core.DirContextAdapter;
import org.springframework.ldap.core.DirContextOperations;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.ldap.userdetails.UserDetailsContextMapper;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Mapper used to map additional information from LDAP into {@link UserDetails} by using {@link CustomUserDetails}.
 */
public class UserDetailsContextMapperImpl implements UserDetailsContextMapper {

    private LdapTemplate ldapTemplate;
    private LdapUserFilterProperties userFilterProperties;

    public UserDetailsContextMapperImpl(LdapTemplate ldapTemplate, LdapUserFilterProperties userFilterProperties) {
        this.ldapTemplate = ldapTemplate;
        this.userFilterProperties = userFilterProperties;
    }

    @Override
    public UserDetails mapUserFromContext(DirContextOperations ctx, String username, Collection<? extends GrantedAuthority> authorities) {
        Collection<GrantedAuthority> grantedAuthorities = getAuthorities(username);
        grantedAuthorities.addAll(authorities);

        Collection<CustomUserGroup> userGroups = getUserGroups(username);

        String tenantIDs = getTenantId(username);

        return new CustomUserDetails(username, grantedAuthorities, userGroups, tenantIDs);
    }

    @Override
    public void mapUserToContext(UserDetails user, DirContextAdapter ctx) {
        // There is not mapping back to the LDAP
    }

    /**
     * Get authorities (roles) from LDAP for the given {@code username}.
     * @param username
     * @return {@link Collection< GrantedAuthority >}
     */
    private Collection<GrantedAuthority> getAuthorities(String username) {
        Collection<GrantedAuthority> grantedAuthorities = new ArrayList<>();

        Set<String> userRoles = getUserRoles(username);
        userRoles.forEach(userRole -> grantedAuthorities.add(new SimpleGrantedAuthority(userRole)));

        return grantedAuthorities;
    }

    /**
     * Get user roles from LDAP for the given {code username}.
     * @param username
     * @return {@link Set<String>}
     */
    private Set<String> getUserRoles(String username) {
        return getFilterData(userFilterProperties.getRoles(), username, true);
    }

    private Collection<CustomUserGroup> getUserGroups(String username) {
        Collection<CustomUserGroup> groups = new HashSet<>();

        for (String groupName : getFilterData(userFilterProperties.getGroups(), username, true)) {
            Set<String> groupRoles = getGroupRoles(groupName);
            groups.add(new CustomUserGroup(groupName, groupRoles));
        }

        return groups;
    }

    /**
     * Get group roles from LDAP for the given {@code groupName}.
     * @param groupName
     * @return {@link Set<String>}
     */
    private Set<String> getGroupRoles(String groupName) {
        return getFilterData(userFilterProperties.getGroups().getRoles(), groupName, true);
    }

    private String getTenantId(String username) {
        Set<String> filterData = getFilterData(userFilterProperties.getTenant(), username, false);
        return filterData.stream().findFirst().orElse(null);
    }



    /**
     * Get filtered data from LDAP.
     * @param properties
     * @param filterValue
     * @return {@link Set<String>}
     */
    private Set<String> getFilterData(BaseLdapFilterProperties properties, String filterValue, boolean required) {
        if (properties == null) {
            return Collections.EMPTY_SET;
        }

        String filter = properties.getFilter();
        String attribute = properties.getAttribute();
        String base = properties.getBase();
        Map<String, String> mapAttributeValue = properties.getMapAttributeValue();

        LdapFilter dataFilter = new LdapFilter(ldapTemplate, mapAttributeValue);
        return dataFilter.query(base, filter, filterValue, attribute, required);
    }
}
