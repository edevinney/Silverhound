package com.backbase.service.auth.configuration;

import org.springframework.boot.context.properties.NestedConfigurationProperty;

/**
 * Setup LDAP properties to query user groups and group roles.
 *
 * @author Davor Sauer
 */
public class LdapUserGroupsFilterProperties extends BaseLdapFilterProperties {

    /**
     * Group roles.
     */
    @NestedConfigurationProperty
    private BaseLdapFilterProperties roles;

    public BaseLdapFilterProperties getRoles() {
        return roles;
    }

    public void setRoles(BaseLdapFilterProperties roles) {
        this.roles = roles;
    }
}
