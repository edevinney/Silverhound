package com.backbase.service.auth.configuration;

import org.springframework.boot.context.properties.NestedConfigurationProperty;

/**
 * Setup LDAP properties how to query user.
 *
 * @author Davor Sauer
 */
public class LdapUserFilterProperties extends BaseLdapFilterProperties {

    /**
     * User tenant ID.
     */
    @NestedConfigurationProperty
    private BaseLdapFilterProperties tenant;

    /**
     * User roles.
     */
    @NestedConfigurationProperty
    private BaseLdapFilterProperties roles;

    /**
     * User groups.
     */
    @NestedConfigurationProperty
    private LdapUserGroupsFilterProperties groups;

    public BaseLdapFilterProperties getTenant() {
        return tenant;
    }

    public void setTenant(BaseLdapFilterProperties tenant) {
        this.tenant = tenant;
    }

    public BaseLdapFilterProperties getRoles() {
        return roles;
    }

    public void setRoles(BaseLdapFilterProperties roles) {
        this.roles = roles;
    }

    public LdapUserGroupsFilterProperties getGroups() {
        return groups;
    }

    public void setGroups(LdapUserGroupsFilterProperties groups) {
        this.groups = groups;
    }
}
