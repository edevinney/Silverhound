package com.backbase.service.auth.impl;

import com.backbase.buildingblocks.authentication.core.AuthenticationHandler;
import com.backbase.buildingblocks.jwt.external.ExternalJwtProducer;
import com.backbase.buildingblocks.logging.api.Logger;
import com.backbase.buildingblocks.logging.api.LoggerFactory;
import org.springframework.security.core.Authentication;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import static com.backbase.service.auth.utils.RedirectUtils.redirect;

/**
 * Handling successful login and logout.
 */
public class LdapAuthenticationHandler implements AuthenticationHandler {

    private static final Logger logger = LoggerFactory.getLogger(LdapAuthenticationHandler.class);

    private ExternalJwtProducer producer;

    public LdapAuthenticationHandler(ExternalJwtProducer producer) {
        this.producer = producer;
    }

    @Override
    public void onSuccessfulLogin(HttpServletRequest request, HttpServletResponse response, Authentication authentication) {
        redirect(request, response);
    }

    @Override
    public void onSuccessfulLogout(HttpServletRequest request, HttpServletResponse response, Authentication authentication) {
        redirect(request, response);
    }

}
