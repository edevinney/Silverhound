package com.backbase.service.auth.logging;

import com.backbase.buildingblocks.logging.api.ErrorLogEvent;
import com.backbase.buildingblocks.logging.api.LogEventBuilder;

public final class Errors {

    private Errors() {  }

    public static final ErrorLogEvent REDIRECT_COOKIE =
            LogEventBuilder.error(1,
                    "Can't redirect to '{}'",
                    "Check is redirect URL valid");

    public static final ErrorLogEvent DECODING_REDIRECT_COOKIE =
            LogEventBuilder.error(2,
                    "Can't decode redirect cookie '{}' with value: {}",
                    "Check the origin of redirect cookie value.");

    public static final ErrorLogEvent UNKNOWN_LDAP_URL =
            LogEventBuilder.error(3,
                    "URL address for LDAP server is not provided.",
                    "Check application configuration");

    public static final ErrorLogEvent UNKNOWN_LDAP_LDIF =
            LogEventBuilder.error(4,
                    "Problem loading LDAP ldif file: {}",
                    "Check application configuration and/or is LDIF file valid.");

    public static final ErrorLogEvent LOADING_PROPERTY =
            LogEventBuilder.error(5,
                    "Can't load property: {}={}",
                    "Check application configuration");

}




