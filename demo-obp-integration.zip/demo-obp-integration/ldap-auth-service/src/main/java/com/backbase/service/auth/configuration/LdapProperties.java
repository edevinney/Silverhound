package com.backbase.service.auth.configuration;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Setup properties for the LDAP connection.
 *
 * @author Davor Sauer
 */
@ConfigurationProperties(prefix = "auth.ldap")
public class LdapProperties {

    /**
     * The URL of the target LDAP server.
     */
    private String url;

    /**
     * Principal to use for authentication against the LDAP server.
     */
    private String userDn;

    /**
     * Authentication password
     */
    private String password;

    /**
     * Set the base suffix from which all operations should origin
     */
    private String base;

    /**
     * Location of LDAP ldif file.
     * LDAP Server {@link #url} has a precedence over {@link #ldif} file.
     */
    private String ldif;

    /**
     * Embedded LDAP server port.
     * If the value of the property is 0 (default value), then the random port number will be assigned.
     */
    private int port = 0;

    /**
     * User details.
     */
    private LdapUserFilterProperties user;

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getUserDn() {
        return userDn;
    }

    public void setUserDn(String userDn) {
        this.userDn = userDn;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getBase() {
        return base;
    }

    public void setBase(String base) {
        this.base = base;
    }

    public String getLdif() {
        return ldif;
    }

    public void setLdif(String ldif) {
        this.ldif = ldif;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public LdapUserFilterProperties getUser() {
        return user;
    }

    public void setUser(LdapUserFilterProperties user) {
        this.user = user;
    }
}
