package com.backbase.service.auth;

import com.backbase.buildingblocks.authentication.core.AuthSecurityConfiguration;
import com.backbase.buildingblocks.logging.api.Logger;
import com.backbase.buildingblocks.logging.api.LoggerFactory;
import com.backbase.service.auth.logging.Warnings;
import com.backbase.service.auth.configuration.LdapProperties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.ldap.core.support.LdapContextSource;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.ldap.userdetails.UserDetailsContextMapper;

/**
 * Spring security configuration
 */
@Configuration
@EnableWebSecurity
public class SecurityConfiguration extends AuthSecurityConfiguration {

    private static final Logger logger = LoggerFactory.getLogger(SecurityConfiguration.class);

    private LdapProperties ldapProperties;
    private UserDetailsContextMapper userDetailsContextMapper;
    private LdapContextSource ldapContextSource;

    @Autowired
    public SecurityConfiguration(LdapProperties ldapProperties,
                                 UserDetailsContextMapper userDetailsContextMapper,
                                 LdapContextSource ldapContextSource) {
        this.ldapProperties = ldapProperties;
        this.userDetailsContextMapper = userDetailsContextMapper;
        this.ldapContextSource = ldapContextSource;
    }

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        if (!canConfigureLdapAuthentication()) {
            logger.warn(Warnings.CANNOT_USE_LDAP);
            return;
        }

        auth.ldapAuthentication()
                .userDnPatterns(ldapProperties.getUser().getFilter())
                .userDetailsContextMapper(userDetailsContextMapper)
                .contextSource(ldapContextSource);
    }

    private boolean canConfigureLdapAuthentication() {
        return ldapProperties != null
                && ldapProperties.getUser() != null
                && ldapProperties.getUser().getFilter() != null
                && userDetailsContextMapper != null
                && ldapContextSource != null;
    }

}