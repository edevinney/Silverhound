package com.backbase.service.auth.impl;

import java.util.Collection;

/**
 * Define the user group and roles for that group.
 *
 * @see CustomUserDetails
 * @see UserDetailsContextMapperImpl
 */
public class CustomUserGroup {

    /**
     * Name of the group.
     */
    private String name;

    /**
     * User tenant ID.
     */
    private String tenantId;

    /**
     * Assigned roles to this group.
     */
    private Collection<String> roles;

    /**
     * Create group with given {@code name} and assign {@code roles} to that group.
     *
     * @param name  user name
     * @param roles user roles
     */
    public CustomUserGroup(String name, Collection<String> roles) {
        this.name = name;
        this.roles = roles;
    }

    /**
     * Get name of this group.
     *
     * @return {@code String}
     */
    public String getName() {
        return name;
    }

    /**
     * Get assigned roles to this group.
     *
     * @return {@code Collection}
     */
    public Collection<String> getRoles() {
        return roles;
    }

    public String getTenantId() {
        return tenantId;
    }
}
