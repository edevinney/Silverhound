package com.backbase.service.auth.utils;

import ch.qos.logback.classic.Level;
import com.backbase.buildingblocks.logging.api.Logger;
import com.backbase.buildingblocks.logging.api.LoggerFactory;
import com.backbase.buildingblocks.logging.impl.LoggerFactoryUtils;
import com.backbase.service.auth.logging.Errors;
import org.springframework.ldap.core.support.LdapContextSource;
import org.springframework.security.ldap.DefaultSpringSecurityContextSource;
import org.springframework.security.ldap.server.ApacheDSContainer;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.net.ServerSocket;
import java.util.Random;
import java.util.function.Function;

/**
 * LDAP Utility class.
 */
public final class LdapUtils {

    private static final Logger logger = LoggerFactory.getLogger(LdapUtils.class);

    private static final int DEFAULT_PORT = 33389;

    private static final Function<Integer, String> EMBEDDED_LDAP_URL = port -> "ldap://127.0.0.1" + ":" + port;

    private LdapUtils() {
    }

    /**
     * Create {@link LdapContextSource} connected to the {@code url}.
     *
     * @param url      then URL or the remote LDAP server
     * @param base     the base suffix from which all operations should origin.
     * @param userDn   the user distinguished name (principal) to use for getting authenticated contexts
     * @param password the password (credentials) to use for getting authenticated contexts
     * @return {@link LdapContextSource}
     */
    public static LdapContextSource ldapContextSource(String url, String base, String userDn, String password) {
        if (StringUtils.isEmpty(url)) {
            logger.error(Errors.UNKNOWN_LDAP_URL);
            return null;
        }

        logger.info("Starting embedded LDAP server: {}", url);
        LdapContextSource contextSource = new DefaultSpringSecurityContextSource(url);

        if (userDn != null) {
            contextSource.setUserDn(userDn);
            contextSource.setPassword(password);
        }

        contextSource.setBase(base);

        return contextSource;
    }

    /**
     * Create {@link LdapContextSource} from {@code ldif} file.
     *
     * @param ldif the location of LDAP file.
     * @param base the base suffix from which all operations should origin.
     * @param port embedded LDAP server port
     * @return {@link LdapContextSource}
     * @throws Exception if embedded LDAP can't be started
     */
    public static LdapContextSource ldifContextSource(String ldif, String base, int port) throws Exception {
        try {
            //If the value of the property is 0 (default value), then the random port number should be assigned
            final int ldapPort = (port == 0) ? getRandomFreePort() : port;

            ApacheDSContainer apacheDsContainer = new ApacheDSContainer(base, ldif);
            apacheDsContainer.getService().setShutdownHookEnabled(true);
            apacheDsContainer.setPort(ldapPort);
            apacheDsContainer.afterPropertiesSet();
            LoggerFactoryUtils.setLevel("org.apache.directory.server.ldap.LdapProtocolHandler", Level.ERROR);

            String url = EMBEDDED_LDAP_URL.apply(ldapPort);

            logger.info("Starting embedded LDAP server: {}", url);
            return ldapContextSource(url, base, null, null);
        } catch (Exception e) {
            logger.error(Errors.UNKNOWN_LDAP_LDIF, new Object[]{ldif}, e);
            return null;
        }
    }

    private static int getRandomFreePort() {
        final int min = 49152;
        final int max = 65535;

        Random random = new Random();
        for (int i = 0; i < 20; i++) {
            int port = random.nextInt((max - min) + 1) + min;
            if (isPortAvailable(port)) {
                return port;
            }
        }

        return DEFAULT_PORT;
    }

    private static boolean isPortAvailable(int port) {
        try (ServerSocket socket = new ServerSocket(port)) {
            return true;
        } catch (IOException e) {
            return false;
        }
    }

}
