package com.backbase.service.auth.utils;

import com.backbase.buildingblocks.logging.api.Logger;
import com.backbase.buildingblocks.logging.api.LoggerFactory;
import com.backbase.service.auth.logging.Errors;
import org.springframework.util.StringUtils;
import org.springframework.web.util.UriUtils;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Objects;
import java.util.Optional;

import static com.backbase.service.auth.logging.Errors.REDIRECT_COOKIE;

/**
 * Utility class for handling redirect to the specified URL.
 */
public final class RedirectUtils {

    private static final Logger logger = LoggerFactory.getLogger(RedirectUtils.class);

    private static final String REDIRECT_URL_COOKIE_NAME = "redirectUrl";

    private static final Cookie EXPIRED_REDIRECT_URL_COOKIE;

    static {
        EXPIRED_REDIRECT_URL_COOKIE = new Cookie(REDIRECT_URL_COOKIE_NAME, "");
        EXPIRED_REDIRECT_URL_COOKIE.setMaxAge(0);
        EXPIRED_REDIRECT_URL_COOKIE.setPath("/");
    }

    private RedirectUtils() {

    }

    /**
     * Redirect request to the URL defined in {@link #REDIRECT_URL_COOKIE_NAME} http cookie.
     *
     * @param request
     * @param response
     */
    public static void redirect(HttpServletRequest request, HttpServletResponse response) {
        String url = null;
        try {
            Optional<String> redirectURL = getRedirectUrl(request);
            if (!redirectURL.isPresent()) {
                return;
            }

            url = redirectURL.get();
            response.addCookie(EXPIRED_REDIRECT_URL_COOKIE);
            response.sendRedirect(url);
        } catch (IOException e) {
            logger.error(REDIRECT_COOKIE, new Object[]{url}, e);
        }
    }

    /**
     * Get redirect URL from cookie {@link #REDIRECT_URL_COOKIE_NAME}
     *
     * @param request
     * @return
     */
    public static Optional<String> getRedirectUrl(HttpServletRequest request) {
        Cookie[] cookies = request.getCookies();
        if (cookies == null || cookies.length == 0) {
            return Optional.empty();
        }

        for (Cookie cookie : request.getCookies()) {
            if (REDIRECT_URL_COOKIE_NAME.equals(cookie.getName())) {
                String value = cookie.getValue();
                String decodedValue;
                try {
                    decodedValue = UriUtils.decode(value, "UTF-8");
                } catch (UnsupportedEncodingException e) {
                    logger.error(Errors.DECODING_REDIRECT_COOKIE, new Object[] {REDIRECT_URL_COOKIE_NAME, value}, e);
                    return Optional.empty();
                }

                if (Objects.equals(value, decodedValue)) {
                    logger.debug("Redirect cookie '{}' = {}", REDIRECT_URL_COOKIE_NAME, value);
                    return Optional.ofNullable(fixUrlPrefix(value));
                } else {
                    logger.debug("Redirect by '{}' cookie: {}, using decoded value: {}", REDIRECT_URL_COOKIE_NAME, value, decodedValue);
                    return Optional.ofNullable(fixUrlPrefix(decodedValue));
                }
            }
        }

        return Optional.empty();
    }



    private static String fixUrlPrefix(String url) {
        if (!StringUtils.hasText(url)) {
            return null;
        }

        if (!url.startsWith("/")) {
            return '/' + url;
        }

        return url;
    }

}
