package com.backbase.service.auth.impl;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.Collections;

/**
 * Custom implementation of {@link UserDetails} which contains the {@link CustomUserGroup}.
 *
 * @see CustomUserGroup
 * @see UserDetailsContextMapperImpl
 */
public class CustomUserDetails implements UserDetails {

    private String userName;

    private Collection<? extends GrantedAuthority> authorities;

    private Collection<CustomUserGroup> groups;

    private String tenantId;

    private boolean accountNonExpired = true;

    private boolean accountNonLocked = true;

    private boolean credentialsNonExpired = true;

    private boolean enabled = true;

    public CustomUserDetails(String userName, Collection<? extends GrantedAuthority> authorities) {
        this.userName = userName;
        this.authorities = Collections.unmodifiableCollection(authorities);
    }

    public CustomUserDetails(String userName, Collection<? extends GrantedAuthority> authorities, Collection<CustomUserGroup> groups, String tenantId) {
        this.userName = userName;
        this.authorities = Collections.unmodifiableCollection(authorities);
        this.groups = Collections.unmodifiableCollection(groups);
        this.tenantId = tenantId;
    }

    public CustomUserDetails(String userName, Collection<? extends GrantedAuthority> authorities, Collection<CustomUserGroup> groups, String tenantId, boolean accountNonExpired, boolean accountNonLocked, boolean credentialsNonExpired, boolean enabled) {
        this(userName, authorities, groups, tenantId);
        this.accountNonExpired = accountNonExpired;
        this.accountNonLocked = accountNonLocked;
        this.credentialsNonExpired = credentialsNonExpired;
        this.enabled = enabled;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return authorities;
    }

    /**
     * Get user groups.
     * @return {@code Collection}
     */
    public Collection<CustomUserGroup> getGroups() {
        return groups;
    }

    /**
     * Always return {@code null}, because password is never used
     *
     * @return {@code null}
     */
    @Override
    public String getPassword() {
        return null;
    }

    @Override
    public String getUsername() {
        return userName;
    }

    @Override
    public boolean isAccountNonExpired() {
        return accountNonExpired;
    }

    @Override
    public boolean isAccountNonLocked() {
        return accountNonLocked;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return credentialsNonExpired;
    }

    @Override
    public boolean isEnabled() {
        return enabled;
    }

    public String getTenantId() {
        return tenantId;
    }
}
