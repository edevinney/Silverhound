package com.backbase.service.auth;

import com.backbase.buildingblocks.authentication.core.AuthenticationHandler;
import com.backbase.buildingblocks.jwt.external.ExternalJwtConsumerConfiguration;
import com.backbase.buildingblocks.jwt.external.ExternalJwtMapper;
import com.backbase.buildingblocks.jwt.external.ExternalJwtProducer;
import com.backbase.buildingblocks.jwt.external.ExternalJwtProducerConfiguration;
import com.backbase.buildingblocks.jwt.external.ExternalJwtTenantMapper;
import com.backbase.buildingblocks.logging.api.Logger;
import com.backbase.buildingblocks.logging.api.LoggerFactory;
import com.backbase.service.auth.configuration.LdapProperties;
import com.backbase.service.auth.impl.CustomExternalJwtMapper;
import com.backbase.service.auth.impl.ExternalJwtTenantMapperImpl;
import com.backbase.service.auth.impl.LdapAuthenticationHandler;
import com.backbase.service.auth.impl.UserDetailsContextMapperImpl;
import com.backbase.service.auth.logging.Warnings;
import com.backbase.service.auth.utils.LdapUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.env.PropertySourcesLoader;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.MutablePropertySources;
import org.springframework.core.env.PropertySource;
import org.springframework.core.io.UrlResource;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.core.support.LdapContextSource;
import org.springframework.security.ldap.userdetails.UserDetailsContextMapper;
import org.springframework.util.StringUtils;

import javax.annotation.PostConstruct;
import javax.servlet.ServletContext;
import java.io.IOException;
import java.io.InputStream;
import java.util.jar.Attributes;
import java.util.jar.Manifest;

import static com.backbase.service.auth.logging.Errors.LOADING_PROPERTY;
import static com.backbase.service.auth.logging.Warnings.CANNOT_READ_MANIFEST;

/**
 * Application bean configuration.
 */
@Configuration
@EnableConfigurationProperties({LdapProperties.class})
@Import({ExternalJwtConsumerConfiguration.class, ExternalJwtProducerConfiguration.class})
public class AppConfiguration implements ApplicationContextAware {

    private static final Logger logger = LoggerFactory.getLogger(AppConfiguration.class);

    @Autowired
    private ServletContext servletContext;

    @Bean
    public AuthenticationHandler authenticationHandler(ExternalJwtProducer externalJwtProducer) {
        return new LdapAuthenticationHandler(externalJwtProducer);
    }

    @Bean
    public ExternalJwtMapper externalJwtMapper() {
        return new CustomExternalJwtMapper();
    }

    @Bean
    public LdapContextSource ldapContextSource(LdapProperties properties) throws Exception {
        if (StringUtils.hasText(properties.getUrl())) {
            return LdapUtils.ldapContextSource(properties.getUrl(), properties.getBase(), properties.getUserDn(),
                    properties.getPassword());
        } else if (StringUtils.hasText(properties.getLdif())) {
            return LdapUtils.ldifContextSource(properties.getLdif(), properties.getBase(), properties.getPort());
        }

        logger.warn(Warnings.CANNOT_CREATE_LDAP_CONTEXT, properties.getUrl(), properties.getLdif());
        return null;
    }

    @Bean
    public LdapTemplate ldapTemplate(LdapContextSource ldapContextSource) {
        if (ldapContextSource == null) {
            return null;
        }
        return new LdapTemplate(ldapContextSource);
    }

    @Bean
    public UserDetailsContextMapper userDetailsContextMapper(LdapTemplate ldapTemplate, LdapProperties ldapProperties) {
        if (ldapTemplate == null) {
            return null;
        }
        return new UserDetailsContextMapperImpl(ldapTemplate, ldapProperties.getUser());
    }

    @Bean
    public ExternalJwtTenantMapper externalJwtTenantMapper() {
        return new ExternalJwtTenantMapperImpl();
    }

    @PostConstruct
    public void postConstruct() {
        try {
            InputStream is = servletContext.getResourceAsStream("/META-INF/MANIFEST.MF");
            if (is == null) {
                is = Thread.currentThread().getContextClassLoader().getResourceAsStream("/META-INF/MANIFEST.MF");
            }
            if (is != null) {
                Manifest manifest = new Manifest(is);
                Attributes attributes = manifest.getMainAttributes();
                String build = attributes.getValue("Build");
                String buildTime = attributes.getValue("Build-Time");

                logger.info("Build: {} ({})", build, buildTime);
            }
        } catch (IOException e) {
            logger.warn(CANNOT_READ_MANIFEST, e);
        }
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        final String[] properties = {"auth.springConfigLocation", "AUTH_SPRING_CONFIG_LOCATION"};
        ConfigurableEnvironment environment = (ConfigurableEnvironment) applicationContext.getEnvironment();
        for (String property : properties) {
            String springConfigLocation = environment.getProperty(property);
            if (StringUtils.isEmpty(springConfigLocation)) {
                continue;
            }

            PropertySourcesLoader propertySourcesLoader = new PropertySourcesLoader();
            PropertySource<?> propertySource = null;
            try {
                propertySource = propertySourcesLoader.load(new UrlResource(springConfigLocation));
            } catch (IOException e) {
                logger.error(LOADING_PROPERTY, new Object[]{property, springConfigLocation}, e);
            }

            MutablePropertySources sources = environment.getPropertySources();
            sources.addFirst(propertySource);
        }
    }
}